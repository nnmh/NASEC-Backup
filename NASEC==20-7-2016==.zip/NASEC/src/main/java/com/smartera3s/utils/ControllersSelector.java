package com.smartera3s.utils;

import java.util.HashMap;
import java.util.Map;

import com.smartera3s.nasec.controllers.ClinicController;
import com.smartera3s.nasec.controllers.InvestigationController;
import com.smartera3s.nasec.controllers.LoginController;
import com.smartera3s.nasec.controllers.NurseController;
import com.smartera3s.nasec.controllers.OperationController;
import com.smartera3s.nasec.controllers.PatientSearchController;
import com.smartera3s.nasec.controllers.RegisterationController;
import com.smartera3s.nasec.controllers.UIController;
import com.smartera3s.nasec.controllers.VisitController;
import com.vaadin.data.Container;

public class ControllersSelector {

    private static Map<Class<?>, UIController> cachedController = new HashMap<Class<?>, UIController>();

    public static UIController get(Class<?> type) {
        UIController NewController = null;
        if (type != null && cachedController.containsKey(type)) {
            NewController = cachedController.get(type);
            return NewController;

        } else {
            if (type.getName().equals(
                    "com.smartera3s.nasec.controllers.ClinicController")) {
                NewController = new ClinicController();
                put(type, NewController);
                return NewController;
            } else if (type.getName().equals(
                    "com.smartera3s.nasec.controllers.VisitController")) {
                //// NewController = new VisitController(new Navigator());
                // put(type,NewController);
                // return NewController;
            } else if (type.getName().equals(
                    "com.smartera3s.nasec.controllers.OperationController")) {
                NewController = new OperationController();
                put(type, NewController);
                return NewController;
            } else if (type.getName().equals(
                    "com.smartera3s.nasec.controllers.RegisterationController")) {
                NewController = new RegisterationController();
                put(type, NewController);
                return NewController;
            } else if (type.getName().equals(
                    "com.smartera3s.nasec.controllers.PatientSearchController")) {
                NewController = new PatientSearchController();
                put(type, NewController);
                return NewController;
            } else if (type.getName().equals(
                    "com.smartera3s.nasec.controllers.LoginController")) {
                // NewController = new LoginController();
                // put(type,NewController);
                // return NewController;
            } else if (type.getName().equals(
                    "com.smartera3s.nasec.controllers.NurseController")) {
                NewController = new NurseController();
                put(type, NewController);
                return NewController;
            } else if (type.getName().equals(
                    "com.smartera3s.nasec.controllers.InvestigationController")) {
                NewController = new InvestigationController();
                put(type, NewController);
                return NewController;
            } else if (type.getName().equals(
                    "com.smartera3s.nasec.controllers.PatientSearchController")) {
                NewController = new PatientSearchController(NewController);
                put(type, NewController);
                return NewController;
            }
        }
        return NewController;

    }

    public static boolean put(Class<?> Name, UIController controller) {
        cachedController.put(Name, controller);
        return true;
    }
}
