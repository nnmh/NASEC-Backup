package com.smartera3s.utils;

import java.util.HashMap;
import java.util.Map;

import com.vaadin.addon.jpacontainer.JPAContainer;
import com.vaadin.addon.jpacontainer.JPAContainerFactory;
import com.vaadin.data.Container;

public class LOV {
	private static Map<Class<?>, Container> cachedLOV = new HashMap<Class<?>, Container>();
	
	public static Container get(Class<?> type){
		Container lov=cachedLOV.get(type);
		if(lov == null){
			lov=load(type);
		}
		return lov;
	}
	private static Container load(Class<?> type) {
		JPAContainer<?> container = JPAContainerFactory.makeReadOnly(type, "NASEC");
		return container;
	}
	public static boolean put(Class<?> type, Container lov){
		cachedLOV.put(type, lov);
		return true;
	}
	
}
