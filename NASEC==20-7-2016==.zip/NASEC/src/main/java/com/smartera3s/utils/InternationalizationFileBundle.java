package com.smartera3s.utils;

import static com.smartera3s.nasec.controllers.LoginController.USER_NAME;

import java.util.Locale;
import java.util.ResourceBundle;

import com.vaadin.ui.UI;

public class InternationalizationFileBundle {
	private static String CAPTIONS_Path = "com.smartera3s.internationalization.componentsCaptions.captions";
	private static String MSGS_Path = "com.smartera3s.internationalization.uiMessages.msgs";

	public static ResourceBundle CAPTIONS = ResourceBundle.getBundle(CAPTIONS_Path, UI.getCurrent().getLocale());
	public static ResourceBundle MSGS = ResourceBundle.getBundle(MSGS_Path, UI.getCurrent().getLocale());

	public static void changeLocale(Locale newLocal) {
		CAPTIONS = ResourceBundle.getBundle(CAPTIONS_Path, newLocal);
		MSGS = ResourceBundle.getBundle(MSGS_Path, newLocal);
	}
	public static String getBundleValue(ResourceBundle propertyBundle, String key){
		String bundleValue=null;
		try {
			bundleValue= propertyBundle.getString(key);
		} catch (Exception e) {
			// TODO: handle exception
		}finally {
			if(bundleValue == null || bundleValue.trim().equals("")){
				bundleValue = "<"+key+">";
			}
		}
		return bundleValue;
	}
}
