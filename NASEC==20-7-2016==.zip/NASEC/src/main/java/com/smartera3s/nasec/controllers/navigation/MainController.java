package com.smartera3s.nasec.controllers.navigation;

import static com.smartera3s.utils.InternationalizationFileBundle.*;

import com.mysql.cj.api.Session;

import static com.smartera3s.nasec.controllers.LoginController.SUBMIT;

import com.smartera3s.NASECUI;
import com.smartera3s.nasec.controllers.LoginController;
import com.smartera3s.nasec.controllers.UIController;
import com.smartera3s.nasec.listeners.LoginListener;
import com.smartera3s.nasec.screens.LoginScreen;
import com.smartera3s.nasec.screens.templateLayouts.HomeScreen;
import com.smartera3s.nasec.screens.templateLayouts.MainScreen;
import com.smartera3s.nasec.model.SysContext;
import com.smartera3s.nasec.model.entities.UserEntity;
import com.smartera3s.nasec.services.LoginService;
import com.smartera3s.utils.InternationalizationFileBundle;
import com.vaadin.data.fieldgroup.FieldGroup.CommitException;
import com.vaadin.data.util.BeanItem;
import com.vaadin.server.VaadinService;
import com.vaadin.server.VaadinSession;
import com.vaadin.ui.Component;
import com.vaadin.ui.CustomComponent;
import com.vaadin.ui.Notification;
import com.vaadin.ui.Notification.Type;
import com.vaadin.ui.UI;

public class MainController implements UIController {

	private LoginController loginController = new LoginController(this);
	private HomeController homeController = new HomeController();;
	private NASECUI app;
	private MainScreen mainScreen;

	public MainController(NASECUI ui) {
	    this.app = ui;
		mainScreen = new MainScreen();
		refreshView();
	}

	private void refreshView(){
		SysContext sysContext = (SysContext)VaadinService.getCurrentRequest().getWrappedSession().getAttribute(SysContext.class.getName());
		UserEntity currentUser = sysContext.getCurrentLoggedInUser();
		CustomComponent newView = null;
		if (currentUser == null || 
				currentUser.getUsername() == null || 
				currentUser.getUsername().trim().equals("")) 
		{
                    newView = loginController.getView();
                    mainScreen.setCurrentView(newView);
            } else {
//                  newView = homeController.getView();
                    app.showMainView();
            }
	}
	// Controllers Common function
	@Override
	public CustomComponent getView() {
		return mainScreen;
	}

	@Override
	public void setNotification(String msg) {
		if(msg != null && msg.equals("LoginSuccess")){
			refreshView();
		}
		
	}
}
