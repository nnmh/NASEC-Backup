package com.smartera3s.nasec.screens.reg;

import static com.smartera3s.nasec.controllers.PatientSearchController.CONTACT_TYPE;
import static com.smartera3s.nasec.controllers.RegisterationController.DOB;
import static com.smartera3s.nasec.controllers.RegisterationController.FISRT_NAME;
import static com.smartera3s.nasec.controllers.RegisterationController.GENDER;
import static com.smartera3s.nasec.controllers.RegisterationController.LAST_NAME;
import static com.smartera3s.nasec.controllers.RegisterationController.PAYMENT;
import static com.smartera3s.nasec.controllers.RegisterationController.PRIMARY_CONTACT;
import static com.smartera3s.nasec.controllers.RegisterationController.SECOND_NAME;
import static com.smartera3s.utils.InternationalizationFileBundle.CAPTIONS;
import static com.smartera3s.utils.InternationalizationFileBundle.MSGS;
import static com.smartera3s.utils.InternationalizationFileBundle.getBundleValue;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;

import com.smartera3s.nasec.listeners.RegisterationScreenListener;
import com.smartera3s.nasec.model.Gender;
import com.smartera3s.nasec.model.PaymentType;
import com.smartera3s.nasec.model.entities.Contact_Entity;
import com.smartera3s.nasec.model.entities.Patient_Entity;
import com.smartera3s.nasec.services.RegisterationService;
import com.vaadin.data.fieldgroup.BeanFieldGroup;
import com.vaadin.data.fieldgroup.PropertyId;
import com.vaadin.data.util.BeanItem;
import com.vaadin.data.util.BeanItemContainer;
import com.vaadin.server.FileResource;
import com.vaadin.ui.AbstractOrderedLayout;
import com.vaadin.ui.CssLayout;
import com.vaadin.ui.DateField;
import com.vaadin.ui.HorizontalLayout;
import com.vaadin.ui.Image;
import com.vaadin.ui.Label;
import com.vaadin.ui.Layout;
import com.vaadin.ui.OptionGroup;
import com.vaadin.ui.TextField;
import com.vaadin.ui.Upload;
import com.vaadin.ui.VerticalLayout;
import com.vaadin.ui.Upload.FailedEvent;
import com.vaadin.ui.Upload.SucceededEvent;
import com.vaadin.ui.themes.ValoTheme;

@SuppressWarnings("serial")
public class RegisterationSubScreen extends CssLayout
		implements Upload.SucceededListener, Upload.FailedListener, Upload.Receiver {

        private File file; // File to write to.
        private Image myLocalImage;
        private Upload profilePictureUpload;

	// String
	@PropertyId("profile_pic")
	private TextField profilePic;

	// Text Fields
	@PropertyId("first_name")
	private TextField firstName;
	@PropertyId("second_name")
	private TextField secondName;
	@PropertyId("last_name")
	private TextField lastName;
	@PropertyId("value")
	private TextField primaryContact;

	// Labels
	@PropertyId("title")
	private Label title;
	@PropertyId("patientID")
	private Label patientID;

	// Option Group
	@PropertyId("gender")
	private OptionGroup gender;
	@PropertyId("payment_method")
	private OptionGroup paymentType;

	// date Fields
	@PropertyId("dob")
	private DateField dob;

	// Layouts

	private Layout layoutFields;
	private Layout layoutNameInputs;
	private Layout layoutInputs;
	private Layout layoutOptionInputs;
	private Layout layout;
	private Layout Imagelayout;

	/// Ahmed add it
	private Layout layoutmain;
	private Layout layoutmainFields;

	private BeanFieldGroup<Patient_Entity> PatientfieldGroup;
	private BeanFieldGroup<Contact_Entity> ContactfieldGroup;
	private BeanItem<Patient_Entity> patientItem;
	private BeanItem<Contact_Entity> contactItem;

	private RegisterationService Service;

	public RegisterationSubScreen(BeanItem<Patient_Entity> patientItem, BeanItem<Contact_Entity> contactItem,
			RegisterationScreenListener listener) {
		this.patientItem = patientItem;
		this.contactItem = contactItem;
		addLayouts();
		addPatientFieldGroup(patientItem);
		addContactFieldGroup(contactItem);

		profilePictureUpload.setReceiver(this);
		profilePictureUpload.addFailedListener(this);
		profilePictureUpload.addSucceededListener(this);
		setSizeUndefined();
	}

	private void addLayouts() {

		layoutmain = new VerticalLayout();
		layoutmain.setSizeUndefined();
		layoutmain.setStyleName("SubScreen-style");

		layoutmainFields = new HorizontalLayout();
		layoutmainFields.setSizeUndefined();
		layoutmainFields.setStyleName("SubScreen-pad");

		layoutFields = new VerticalLayout();
		layoutFields.setSizeUndefined();

		Imagelayout = new VerticalLayout();
		Imagelayout.setSizeUndefined();
		// Imagelayout.setStyleName("test");

		layoutNameInputs = new HorizontalLayout();
		layoutNameInputs.setSizeUndefined();
		layoutNameInputs.setStyleName("padding-style");

		layoutInputs = new HorizontalLayout();
		layoutInputs.setSizeUndefined();
		layoutInputs.setStyleName("padding-style");

		layoutOptionInputs = new HorizontalLayout();
		layoutOptionInputs.setSizeUndefined();
		layoutOptionInputs.setStyleName("padding-style");

		layout = new HorizontalLayout();
		layout.setSizeUndefined();
		// layout.setStyleName("test");

		title = createTitle();
		patientID = createPatientID();

		layout.addComponent(title);
		layout.addComponent(patientID);
		((AbstractOrderedLayout) layout).setSpacing(true);

		layoutmain.addComponent(layout);
		fillFields(layoutmainFields);
		layoutmain.addComponent(layoutmainFields);

		addComponent(layoutmain);
	}

	private void fillFields(Layout mainLayout) {

		firstName = createFirstName();
		secondName = createSecondName();
		lastName = createLastName();
		dob = createDOB();
		primaryContact = createContact();
		gender = createGender();
		paymentType = createPaymentType();
		myLocalImage = createImage();
		profilePic = createProfilePic();
		profilePictureUpload = createUploader();

		layoutFields.addComponent(layoutNameInputs);
		layoutFields.addComponent(layoutInputs);
		layoutFields.addComponent(layoutOptionInputs);

		Imagelayout.addComponent(myLocalImage);
		Imagelayout.addComponent(profilePictureUpload);
		((AbstractOrderedLayout) Imagelayout).setSpacing(true);

		layoutNameInputs.addComponent(firstName);
		layoutNameInputs.addComponent(secondName);
		layoutNameInputs.addComponent(lastName);
		((AbstractOrderedLayout) layoutNameInputs).setSpacing(true);

		layoutInputs.addComponent(dob);
		layoutInputs.addComponent(primaryContact);
		((AbstractOrderedLayout) layoutInputs).setSpacing(true);

		layoutOptionInputs.addComponent(gender);
		layoutOptionInputs.addComponent(paymentType);
		((AbstractOrderedLayout) layoutOptionInputs).setSpacing(true);

		/// Image
		mainLayout.addComponent(Imagelayout);
		/// Data
		mainLayout.addComponent(layoutFields);

		((AbstractOrderedLayout) mainLayout).setExpandRatio(layoutFields, 1);

	}

	private void addContactFieldGroup(BeanItem<Contact_Entity> contactItem) {
		ContactfieldGroup = new BeanFieldGroup<Contact_Entity>(Contact_Entity.class);
		ContactfieldGroup.setBuffered(false);// not to depend on commitss
		ContactfieldGroup.setItemDataSource(contactItem);
		ContactfieldGroup.bindMemberFields(this);
	}

	private void addPatientFieldGroup(BeanItem<Patient_Entity> patientItem) {

		PatientfieldGroup = new BeanFieldGroup<Patient_Entity>(Patient_Entity.class);
		PatientfieldGroup.setBuffered(false);// not to depend on commitss
		PatientfieldGroup.setItemDataSource(patientItem);
		PatientfieldGroup.bindMemberFields(this);
	}

	private Label createTitle() {
		title = new Label("Patient Information");
		title.addStyleName(ValoTheme.LABEL_H1);
		title.addStyleName(ValoTheme.LABEL_NO_MARGIN);
		return title;
	}

	private Label createPatientID() {
		patientID = new Label("");
		patientID.setStyleName(ValoTheme.LABEL_H1);

		return patientID;
	}

	private Image createImage() {

		myLocalImage = new Image();
		myLocalImage.setWidth("120px");
		myLocalImage.setHeight("120px");
		return myLocalImage;

	}

	private Upload createUploader() {
		profilePictureUpload = new Upload();
		// profilePictureUpload.setStyleName("test");
		return profilePictureUpload;

	}

	private TextField createFirstName() {
		firstName = new TextField();
		firstName.setStyleName(ValoTheme.TEXTFIELD_LARGE);
		firstName.setCaption(getBundleValue(CAPTIONS, FISRT_NAME));
		firstName.setId(FISRT_NAME);
		firstName.setDescription(getBundleValue(MSGS, FISRT_NAME));
		firstName.setNullRepresentation("");

		return firstName;
	}

	private TextField createSecondName() {
		secondName = new TextField();
		secondName.setStyleName(ValoTheme.TEXTFIELD_LARGE);
		secondName.setCaption(getBundleValue(CAPTIONS, SECOND_NAME));
		secondName.setId(SECOND_NAME);
		secondName.setDescription(getBundleValue(MSGS, SECOND_NAME));
		secondName.setNullRepresentation("");

		return secondName;
	}

	private TextField createLastName() {
		lastName = new TextField();
		lastName.setStyleName(ValoTheme.TEXTFIELD_LARGE);
		lastName.setCaption(getBundleValue(CAPTIONS, LAST_NAME));
		lastName.setId(LAST_NAME);
		lastName.setDescription(getBundleValue(MSGS, LAST_NAME));
		lastName.setNullRepresentation("");

		return lastName;
	}

	private TextField createContact() {
		primaryContact = new TextField();
		primaryContact.setStyleName(ValoTheme.TEXTFIELD_LARGE);
		primaryContact.setCaption(getBundleValue(CAPTIONS, PRIMARY_CONTACT));
		primaryContact.setId(PRIMARY_CONTACT);
		primaryContact.setDescription(getBundleValue(MSGS, PRIMARY_CONTACT));
		primaryContact.setNullRepresentation("");

		return primaryContact;
	}

	private TextField createProfilePic() {
		profilePic = new TextField();
		profilePic.setVisible(false);
		// profilePic.setStyleName(ValoTheme.TEXTFIELD_LARGE);
		// profilePic.setCaption(getBundleValue(CAPTIONS, FISRT_NAME));
		// profilePic.setId(FISRT_NAME);
		// profilePic.setDescription(getBundleValue(MSGS, FISRT_NAME));
		profilePic.setNullRepresentation("");

		return profilePic;
	}

	private DateField createDOB() {
		dob = new DateField();
		dob.setStyleName(ValoTheme.DATEFIELD_LARGE);
		dob.setCaption(getBundleValue(CAPTIONS, DOB));
		dob.setId(PRIMARY_CONTACT);

		return dob;
	}

	private OptionGroup createGender() {
		OptionGroup sex = new OptionGroup();
		sex.setStyleName(ValoTheme.TEXTFIELD_LARGE);
		sex.setCaption(getBundleValue(CAPTIONS, GENDER));
		sex.setId(GENDER);
		sex.setDescription(getBundleValue(MSGS, GENDER));
		BeanItemContainer sexCntr = new BeanItemContainer(String.class);
		sexCntr.addItem(Gender.Male.name());
		sexCntr.addItem(Gender.Female.name());
		sex.setContainerDataSource(sexCntr);
		return sex;
	}

	private OptionGroup createPaymentType() {
		OptionGroup payment = new OptionGroup();
		payment.setStyleName(ValoTheme.TEXTFIELD_LARGE);
		payment.setCaption(getBundleValue(CAPTIONS, PAYMENT));
		payment.setId(PAYMENT);
		payment.setDescription(getBundleValue(MSGS, PAYMENT));
		BeanItemContainer pmtCntr = new BeanItemContainer(String.class);
		pmtCntr.addItem(PaymentType.Cash.name());
		pmtCntr.addItem(PaymentType.Credit.name());
		payment.setContainerDataSource(pmtCntr);
		return payment;
	}

	@Override
	public OutputStream receiveUpload(String filename, String mimeType) {

		if (filename.equals("") || filename.equals(null)) {
			return null;
		}

		FileOutputStream fos = null; // Output stream to write to

		file = new File(filename);
		try {
			// Open the file for writing.
			fos = new FileOutputStream(file);
		} catch (final java.io.FileNotFoundException e) {
			// Error while opening the file. Not reported here.
			e.printStackTrace();
			return null;
		}

		return fos; // Return the output stream to write to
	}

	@Override
	public void uploadFailed(FailedEvent event) {
		// TODO Auto-generated method stub

	}

	@Override
	public void uploadSucceeded(SucceededEvent event) {
		FileResource resource;
		resource = new FileResource(file);
		try {
			patientItem.getBean().setProfile_pic(file.getCanonicalPath());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		myLocalImage.setSource(resource);
	}

	public TextField getPrimaryContact() {
		return primaryContact;
	}

	public void setPrimaryContact(TextField primaryContact) {
		this.primaryContact = primaryContact;
	}

	public DateField getDob() {
		return dob;
	}

	public void setDob(DateField dob) {
		this.dob = dob;
	}

	public OptionGroup getGender() {
		return gender;
	}

	public void setGender(OptionGroup gender) {
		this.gender = gender;
	}

	public OptionGroup getPaymentType() {
		return paymentType;
	}

	public void setPaymentType(OptionGroup paymentType) {
		this.paymentType = paymentType;
	}

	public TextField getFirstName() {
		return firstName;
	}

	public void setFirstName(TextField firstName) {
		this.firstName = firstName;
	}

	public TextField getSecondName() {
		return secondName;
	}

	public void setSecondName(TextField secondName) {
		this.secondName = secondName;
	}

	public TextField getLastName() {
		return lastName;
	}

	public void setLastName(TextField lastName) {
		this.lastName = lastName;
	}

	public BeanFieldGroup<Patient_Entity> getPatientfieldGroup() {
		return PatientfieldGroup;
	}

	public void setPatientfieldGroup(BeanFieldGroup<Patient_Entity> patientfieldGroup) {
		PatientfieldGroup = patientfieldGroup;
	}

	public BeanFieldGroup<Contact_Entity> getContactfieldGroup() {
		return ContactfieldGroup;
	}

	public void setContactfieldGroup(BeanFieldGroup<Contact_Entity> contactfieldGroup) {
		ContactfieldGroup = contactfieldGroup;
	}

	public Label getPatientID() {
		return patientID;
	}

	public void setPatientID(Label patientID) {
		this.patientID = patientID;
	}

	public File getFile() {
		return file;
	}

	public void setFile(File file) {
		this.file = file;
	}

	public void updateFieldGroup(BeanItem<Patient_Entity> patientItem) {
		PatientfieldGroup.setItemDataSource(patientItem);
	}

    public Image getMyLocalImage() {
        return myLocalImage;
    }

    public void setMyLocalImage(Image myLocalImage) {
        this.myLocalImage = myLocalImage;
    }
}
