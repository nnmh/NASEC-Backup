package com.smartera3s.nasec.listeners;

import static com.smartera3s.nasec.controllers.RegisterationController.SAVE;
import static com.smartera3s.nasec.controllers.RegisterationController.ADD;
import static com.smartera3s.nasec.controllers.RegisterationController.ADDR;
import static com.smartera3s.nasec.controllers.RegisterationController.ADDCCCC;
import static com.smartera3s.nasec.controllers.RegisterationController.SEARCH;

import com.smartera3s.nasec.controllers.RegisterationController;
import com.vaadin.ui.Button;
import com.vaadin.ui.Button.ClickEvent;
import com.vaadin.ui.Button.ClickListener;

public class RegisterationScreenListener implements ClickListener{
    private RegisterationController registerController;
    
    public RegisterationScreenListener(RegisterationController controller){
            this.registerController=controller;
    }
    
    @Override
    public void buttonClick(ClickEvent event) {
            if(event.getButton().getId().equals(SAVE)){
                registerController.save();
            }
            if(event.getButton().getId().equals(ADD)){
                registerController.addcontact();
            }
            if(event.getButton().getId().equals(ADDR)){
                registerController.addrelation();
            }
            if(event.getButton().getId().equals(ADDCCCC)){
                registerController.addcompany();
            }
            if(event.getButton().getId().equals(SEARCH)){
                registerController.searchPatient();
            }
    }
}