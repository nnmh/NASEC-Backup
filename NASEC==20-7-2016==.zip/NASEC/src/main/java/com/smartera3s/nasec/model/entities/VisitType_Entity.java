package com.smartera3s.nasec.model.entities;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the visittypes database table.
 * 
 */
@Entity
@Table(name="visittypes")
@NamedQuery(name="VisitType_Entity.findAll", query="SELECT v FROM VisitType_Entity v")
public class VisitType_Entity implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int id;

	private String type;

	public VisitType_Entity() {
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getType() {
		return this.type;
	}

	public void setType(String type) {
		this.type = type;
	}
	public String getDisplayName(){
	    return type;
	}

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + id;
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        VisitType_Entity other = (VisitType_Entity) obj;
        if (id != other.id)
            return false;
        return true;
    }

    @Override
    public String toString() {
        // TODO Auto-generated method stub
        return this.type;
    }

}