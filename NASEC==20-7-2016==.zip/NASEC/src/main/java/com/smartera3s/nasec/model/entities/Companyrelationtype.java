package com.smartera3s.nasec.model.entities;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the companyrelationtype database table.
 * 
 */
@Entity
@NamedQuery(name="Companyrelationtype.findAll", query="SELECT c FROM Companyrelationtype c")
public class Companyrelationtype implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int id;

	private String types;

	public Companyrelationtype() {
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getTypes() {
		return this.types;
	}

	public void setTypes(String types) {
		this.types = types;
	}
	public String getDisplayName(){
            return types;
        }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + id;
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        Companyrelationtype other = (Companyrelationtype) obj;
        if (id != other.id)
            return false;
        return true;
    }

    @Override
    public String toString() {
        // TODO Auto-generated method stub
        return types;
    }

}