package com.smartera3s.nasec.model.entities;

import java.io.Serializable;
import javax.persistence.*;

import java.util.Collection;
import java.util.Date;
import java.util.List;


/**
 * The persistent class for the patientsymptoms database table.
 * 
 */
@Entity
@Table(name="patientsymptoms")
@NamedQuery(name="PatientsymptomEntity.findAll", query="SELECT p FROM PatientsymptomEntity p")
public class PatientsymptomEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int id;

	private String clinicId;

	@Temporal(TemporalType.DATE)
	private Date date;

	private String ICD10Codes;

	@Lob
	private String notes;

	private String patient_id;
	
	@Transient
	Collection<BodypartEntity> bodyPartsList;
	@Transient
        Collection<Icd10Entity> ICD10List;
	
	@Transient
        List<Symeptoms_badypartEntity> symeptomsList;
        

	public PatientsymptomEntity() {
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getClinicId() {
		return this.clinicId;
	}

	public void setClinicId(String clinicId) {
		this.clinicId = clinicId;
	}

	public Date getDate() {
		return this.date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public String getICD10Codes() {
		return this.ICD10Codes;
	}

	public void setICD10Codes(String ICD10Codes) {
		this.ICD10Codes = ICD10Codes;
	}

	public String getNotes() {
		return this.notes;
	}

	public void setNotes(String notes) {
		this.notes = notes;
	}

	public String getPatient_id() {
		return this.patient_id;
	}

	public void setPatient_id(String patient_id) {
		this.patient_id = patient_id;
	}

    public Collection<BodypartEntity> getBodyPartsList() {
        return bodyPartsList;
    }

    public void setBodyPartsList(
            Collection<BodypartEntity> bodyPartsList) {
        this.bodyPartsList = bodyPartsList;
    }

    public Collection<Icd10Entity> getICD10List() {
        return ICD10List;
    }

    public void setICD10List(Collection<Icd10Entity> iCD10List) {
        ICD10List = iCD10List;
    }

    public List<Symeptoms_badypartEntity> getSymeptoms() {
        return symeptomsList;
    }

    public void setSymeptoms(List<Symeptoms_badypartEntity> symeptomsList) {
        this.symeptomsList = symeptomsList;
    }

}