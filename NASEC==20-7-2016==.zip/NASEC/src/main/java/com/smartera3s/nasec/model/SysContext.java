package com.smartera3s.nasec.model;

import java.io.Serializable;

import com.smartera3s.nasec.model.entities.ClinicvisitEntity;
import com.smartera3s.nasec.model.entities.Patient_Entity;
import com.smartera3s.nasec.model.entities.UserEntity;
import com.smartera3s.nasec.model.entities.VisitEntity;

/*
 * This is the sharable context of the system where session values will be stored.
 * This object will be shared cross the different controllers to share the session data.
 * i.e. sharing the current logged in user captured by login controller with all other system controllers
*/
public class SysContext implements Serializable {
	private static final long serialVersionUID = -3302389147677094476L;
	
	private UserEntity currentLoggedInUser;
	private Patient_Entity selectedPatient;
	private VisitEntity CurrentVisit;
	private ClinicvisitEntity CurrentClinic;
	
	public UserEntity getCurrentLoggedInUser() {
		return currentLoggedInUser;
	}
	public void setCurrentLoggedInUser(UserEntity currentLoggedInUser) {
		this.currentLoggedInUser = currentLoggedInUser;
	}
	public Patient_Entity getSelectedPatient() {
		return selectedPatient;
	}
	public void setSelectedPatient(Patient_Entity selectedPatient) {
		this.selectedPatient = selectedPatient;
	}
        public VisitEntity getCurrentVisit() {
            return CurrentVisit;
        }
        public void setCurrentVisit(VisitEntity currentVisit) {
            this.CurrentVisit = currentVisit;
        }
        public ClinicvisitEntity getCurrentClinic() {
            return CurrentClinic;
        }
        public void setCurrentClinic(ClinicvisitEntity currentClinic) {
            CurrentClinic = currentClinic;
        }
	

}
