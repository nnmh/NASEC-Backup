package com.smartera3s.nasec.screens.templateLayouts;

import static com.smartera3s.nasec.controllers.LoginController.*;

import com.smartera3s.nasec.listeners.LoginListener;
import com.smartera3s.nasec.model.entities.UserEntity;
import com.smartera3s.utils.InternationalizationFileBundle;
import com.vaadin.data.fieldgroup.BeanFieldGroup;
import com.vaadin.data.fieldgroup.FieldGroup;
import com.vaadin.data.fieldgroup.PropertyId;
import com.vaadin.data.util.BeanItem;
import com.vaadin.event.ShortcutAction.KeyCode;
import com.vaadin.ui.AbstractOrderedLayout;
import com.vaadin.ui.Button;
import com.vaadin.ui.CssLayout;
import com.vaadin.ui.CustomComponent;
import com.vaadin.ui.Layout;
import com.vaadin.ui.PasswordField;
import com.vaadin.ui.TextField;
import com.vaadin.ui.VerticalLayout;
import com.vaadin.ui.themes.ValoTheme;
import static com.smartera3s.utils.InternationalizationFileBundle.*;

public class AdminScreen extends CustomComponent{
	/*
	 * mapping the UI fields with the associated properties of the bean that
	 * will be binded
	 */
	@PropertyId("userName")
	private TextField userName;
	@PropertyId("password")
	private PasswordField password;

	// Layouts
	private Layout layoutLogin;
	private Layout layoutFields;
	private Layout layoutControls;

	// FieldGroup that will link between the ui fields and the binded
	// properties of the bean
	private BeanFieldGroup<UserEntity> fieldGroup;

	// Actions & Controls
	private Button loginButton;
	private LoginListener eventsListener;

	// Constructor
	public AdminScreen(BeanItem<UserEntity> userItem, LoginListener listener) {
		this.eventsListener = listener;
		addLayouts();
		addFieldGroup(userItem);
		addControls(layoutControls);
	}

	/*
	 * layout size should be undefined to be responsive to the subcomponents
	 * sizes. while each subcomponent can take its size (fixed or
	 * resolution-conditional)
	 * 
	 */
	private void addLayouts() {
		layoutLogin = new VerticalLayout();
		layoutLogin.setSizeUndefined();

		layoutFields = new CssLayout();
		layoutFields.setSizeUndefined();

		layoutControls = new CssLayout();
		layoutControls.setSizeUndefined();

		layoutLogin.addComponent(layoutFields);
		layoutLogin.addComponent(layoutControls);
		setCompositionRoot(layoutLogin);
		fillFields(layoutFields);
	}

	private void addFieldGroup(BeanItem<UserEntity> user) {
		fieldGroup = new BeanFieldGroup<UserEntity>(UserEntity.class);
		fieldGroup.setBuffered(false);// not to depend on commit
		// you can set any custom factory if you need to change the display
		// component for certain property
		// fieldGroup.setFieldFactory(DefaultFieldGroupFieldFactory.get());
		fieldGroup.setItemDataSource(user);
		/*
		 * this is the core of binding. it takes the class which contains the UI
		 * fields
		 */
		fieldGroup.bindMemberFields(this);
		
	}
	
	private void fillFields(Layout layout){
		// fill the layout
		userName = createUserName();
		password = createPassword();
		layout.addComponent(userName);
		layout.addComponent(password);
	}

	private void addControls(Layout layout) {
		loginButton=createLoginButton();
		// fill related layout
		layout.addComponent(loginButton);
	}

	private TextField createUserName() {
		TextField name= new TextField();
		name.setStyleName(ValoTheme.TEXTFIELD_LARGE);
		name.setCaption(getBundleValue(CAPTIONS,USER_NAME));
		name.setId(USER_NAME);
		name.setNullRepresentation("");
		name.setInputPrompt(getBundleValue(MSGS,USER_NAME));
		name.setDescription(getBundleValue(MSGS,USER_NAME));
		return name;
	}

	private PasswordField createPassword() {
		PasswordField pass = new PasswordField();
		pass.setStyleName(ValoTheme.TEXTFIELD_LARGE);
		pass.addStyleName(ValoTheme.TEXTFIELD_ALIGN_CENTER);
		pass.setCaption(getBundleValue(CAPTIONS,PASSW0RD));
		pass.setId(PASSW0RD);
		pass.setNullRepresentation("");
		pass.setDescription(getBundleValue(MSGS,PASSW0RD));
		return pass;
	}

	private Button createLoginButton(){
		Button login = new Button(getBundleValue(CAPTIONS,SUBMIT));
		login.setStyleName(ValoTheme.BUTTON_PRIMARY);
		login.setClickShortcut(KeyCode.ENTER);
		login.setId(SUBMIT);
		login.setDescription(getBundleValue(MSGS,SUBMIT));
		// assign the listener class that handles events
		login.addClickListener(eventsListener);
		return login;
	}
	
	public Layout getLayoutLogin() {
		return layoutLogin;
	}
	public TextField getUserName() {
		return userName;
	}
	public PasswordField getPassword() {
		return password;
	}
	public Button getLoginButton() {
		return loginButton;
	}
	
	// common screens functions
	public void resetFields() {
		// TODO clear the values of all components
	}
	public FieldGroup getFieldGroup() {
		return fieldGroup;
	}	
}
