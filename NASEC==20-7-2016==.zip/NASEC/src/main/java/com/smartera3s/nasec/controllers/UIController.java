package com.smartera3s.nasec.controllers;

import com.vaadin.ui.Component;
import com.vaadin.ui.CustomComponent;

public interface UIController {
	CustomComponent getView();
	void setNotification(String msg);
}
