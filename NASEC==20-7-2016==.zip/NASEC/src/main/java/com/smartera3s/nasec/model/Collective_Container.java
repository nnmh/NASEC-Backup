package com.smartera3s.nasec.model;

import com.smartera3s.nasec.model.entities.Contact_Entity;
import com.smartera3s.nasec.model.entities.Patient_Entity;

public class Collective_Container {
    Patient_Entity patient;
    Contact_Entity contact;
    public Patient_Entity getPatient() {
        return patient;
    }
    public void setPatient(Patient_Entity patient) {
        this.patient = patient;
    }
    public Contact_Entity getContact() {
        return contact;
    }
    public void setContact(Contact_Entity contact) {
        this.contact = contact;
    }
}
