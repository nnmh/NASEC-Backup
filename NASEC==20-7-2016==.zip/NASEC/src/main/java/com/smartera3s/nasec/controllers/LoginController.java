package com.smartera3s.nasec.controllers;

import static com.smartera3s.utils.InternationalizationFileBundle.*;
import static com.smartera3s.nasec.controllers.LoginController.SUBMIT;

import com.smartera3s.nasec.listeners.LoginListener;
import com.smartera3s.nasec.screens.LoginScreen;
import com.smartera3s.nasec.model.SysContext;
import com.smartera3s.nasec.model.entities.UserEntity;
import com.smartera3s.nasec.services.LoginService;
import com.smartera3s.utils.InternationalizationFileBundle;
import com.vaadin.data.fieldgroup.FieldGroup.CommitException;
import com.vaadin.data.util.BeanItem;
import com.vaadin.server.VaadinService;
import com.vaadin.server.VaadinSession;
import com.vaadin.ui.Component;
import com.vaadin.ui.CustomComponent;
import com.vaadin.ui.Notification;
import com.vaadin.ui.Notification.Type;

public class LoginController implements UIController{
	// constants
	public static final String PASSW0RD = "login.userPassword";
	public static final String USER_NAME = "login.userName";
	public static final String SUBMIT = "login.submit";
	public static final String WRONG_PASSWORD = "login.srvs.wrongPassword";
	public static final String WRONG_USER = "login.srvs.userNotExist";
	public static final String LOGIN_SUCCESS = "login.srvs.successfulLogin";

	private UserEntity user; // Model
	private LoginScreen screen; // View
	private LoginListener listener; //Actions & Events listener
	private LoginService loginService; // managing service

	private UIController callerController;
	public LoginController(UIController caller) {
		this.callerController = caller;
		user = new UserEntity();
		listener = new LoginListener(this);
		screen = new LoginScreen(new BeanItem<UserEntity>(user), listener);
		loginService = new LoginService();
	}

	public void login() {
		// TODO hit DB for User&Password
		BeanItem<UserEntity> item= (BeanItem<UserEntity>) screen.getFieldGroup().getItemDataSource();
		boolean isAuthenticated =false;
		try {
//			System.out.println(">>item.getBean().getUserName() " + item.getBean().getUsername());
//			screen.getFieldGroup().commit();
			if(!screen.getFieldGroup().isValid()){
				screen.getFieldGroup().discard();
				System.out.println("Discarded ----<");
			}
			isAuthenticated = loginService.login(user);
			if(isAuthenticated){
				SysContext context = (SysContext)VaadinService.getCurrentRequest().getWrappedSession().getAttribute(SysContext.class.getName());
				user.setPassword(null);
				context.setCurrentLoggedInUser(user); 
				callerController.setNotification("LoginSuccess");
				Notification.show(getBundleValue(MSGS,LOGIN_SUCCESS), Type.TRAY_NOTIFICATION);
			}
		} catch (Exception e) {//CommitException
			// TODO Auto-generated catch block
			Notification.show("Exceptions: "+e.getMessage(), Type.WARNING_MESSAGE);
		}
	}

	// Controllers Common function
	@Override
	public CustomComponent getView() {
		return screen;
	}

	@Override
	public void setNotification(String msg) {
		// TODO Auto-generated method stub
		
	}

	
}
