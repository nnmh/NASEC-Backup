package com.smartera3s.nasec.listeners;

import static com.smartera3s.nasec.controllers.ClinicController.ADDDESCRIPSION;
import static com.smartera3s.nasec.controllers.ClinicController.ADDDESCRIPSIONDETAILS;
import static com.smartera3s.nasec.controllers.ClinicController.ADDCOMBOBOX;
import static com.smartera3s.nasec.controllers.ClinicController.LOADPATIENT;
import static com.smartera3s.nasec.controllers.ClinicController.SAVECLINICVISIT;
import static com.smartera3s.nasec.controllers.ClinicController.SAVEPOPUP;

import com.smartera3s.nasec.controllers.ClinicController;
import com.vaadin.data.Property.ValueChangeEvent;
import com.vaadin.data.Property.ValueChangeListener;
import com.vaadin.ui.Button.ClickEvent;
import com.vaadin.ui.Button.ClickListener;

@SuppressWarnings("serial")
public class ClinicListener implements ClickListener , ValueChangeListener {
    private ClinicController controller;
    
    public ClinicListener(ClinicController controller) {
        this.controller = controller;
    }
    
    public void buttonClick(ClickEvent event) {
        if(event.getButton().getId().equals(LOADPATIENT)){
            controller.load();
        }
        if(event.getButton().getId().equals(ADDDESCRIPSION)){
            controller.addDescription();
        }
        if(event.getButton().getId().equals(ADDCOMBOBOX)){
            controller.addFromCombo();
        }
        if(event.getButton().getId().equals(SAVECLINICVISIT)){
            controller.saveRequest();
        }
        if(event.getButton().getId().equals(ADDDESCRIPSIONDETAILS)){
            controller.addDescriptionDetails();
        }
        if(event.getButton().getId().equals(SAVEPOPUP)){
            controller.savePopUp();
        }
    }

    @Override
    public void valueChange(ValueChangeEvent event) {
                   controller.changeListener(event);
            }
    }

