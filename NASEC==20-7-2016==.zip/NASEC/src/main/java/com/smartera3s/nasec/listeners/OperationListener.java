package com.smartera3s.nasec.listeners;

import com.smartera3s.nasec.controllers.OperationController;

public class OperationListener {

    public OperationListener(OperationController controller) {
        // TODO Auto-generated constructor stub
    }

}
