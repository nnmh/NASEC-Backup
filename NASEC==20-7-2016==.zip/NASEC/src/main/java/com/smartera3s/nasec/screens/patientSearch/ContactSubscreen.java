package com.smartera3s.nasec.screens.patientSearch;

import static com.smartera3s.utils.InternationalizationFileBundle.*;

import com.smartera3s.nasec.model.entities.Company_Entity;
import com.smartera3s.nasec.model.entities.Contact_Entity;
/*import com.smartera3s.nasec.model.entities.ContactTypeEntity;*/
import com.smartera3s.nasec.model.entities.UserEntity;
import com.smartera3s.utils.InternationalizationFileBundle;
import com.smartera3s.utils.LOV;
import com.vaadin.data.fieldgroup.BeanFieldGroup;
import com.vaadin.data.fieldgroup.FieldGroup;
import com.vaadin.data.fieldgroup.PropertyId;
import com.vaadin.data.util.BeanItem;
import com.vaadin.ui.ComboBox;
import com.vaadin.ui.CssLayout;
import com.vaadin.ui.CustomComponent;
import com.vaadin.ui.HorizontalLayout;
import com.vaadin.ui.Layout;
import com.vaadin.ui.PasswordField;
import com.vaadin.ui.TextField;
import com.vaadin.ui.themes.ValoTheme;
import static com.smartera3s.nasec.controllers.PatientSearchController.*;

@SuppressWarnings("serial")
public class ContactSubscreen extends CssLayout {
	/*
	 * mapping the UI fields with the associated properties of the bean that
	 * will be binded
	 */
	private static final String CONTACTSUBSCREENSTYLE = "PatientcontactSubscreen";
	@PropertyId("name")
	private TextField companyname;
	@PropertyId("value")
	private TextField contactvalue;
	// Layouts
	private Layout layoutFields;
	// FieldGroup that will link between the ui fields and the binded
	// properties of the bean
	private BeanFieldGroup<Contact_Entity> contactfieldGroup;
	private BeanFieldGroup<Company_Entity> companyfieldGroup;

	// Constructor
	public ContactSubscreen(BeanItem<Contact_Entity> contactItem, BeanItem<Company_Entity> companyItem) {
		addLayouts();
		setStyleName(CONTACTSUBSCREENSTYLE);
		addcontactFieldGroup(contactItem);
		addcompanyFieldGroup(companyItem);
	}

	private void addLayouts() {
		layoutFields = new HorizontalLayout();
		addComponent(layoutFields);
		fillFields(layoutFields);
	}

	private void addcontactFieldGroup(BeanItem<Contact_Entity> contactItem) {
		contactfieldGroup = new BeanFieldGroup<Contact_Entity>(Contact_Entity.class);
		contactfieldGroup.setBuffered(false);// not to depend on commit
		contactfieldGroup.setItemDataSource(contactItem);
		contactfieldGroup.bindMemberFields(this);
	}

	private void addcompanyFieldGroup(BeanItem<Company_Entity> companyItem) {
		companyfieldGroup = new BeanFieldGroup<Company_Entity>(Company_Entity.class);
		companyfieldGroup.setBuffered(false);// not to depend on commit
		companyfieldGroup.setItemDataSource(companyItem);
		companyfieldGroup.bindMemberFields(this);
	}

	private void fillFields(Layout layout) {
		companyname = createcompany();
		contactvalue = createValue();
		
		HorizontalLayout companynameLayout = new HorizontalLayout();
		HorizontalLayout contactvalueLayout = new HorizontalLayout();
		
		companynameLayout.addComponent(companyname);
		contactvalueLayout.addComponent(contactvalue);
		layout.addComponents(companynameLayout,contactvalueLayout);

	}

	private TextField createValue() {
		TextField contactValue = new TextField();
		// contactValue.setStyleName(ValoTheme.TEXTFIELD_LARGE);
		contactValue.setCaption(getBundleValue(CAPTIONS, CONTACT_VALUE));
		contactValue.setId(CONTACT_VALUE);
		contactValue.setNullRepresentation("");
		contactValue.setInputPrompt(getBundleValue(MSGS, CONTACT_VALUE));
		contactValue.setDescription(getBundleValue(MSGS, CONTACT_VALUE));
		return contactValue;
	}

	private TextField createcompany() {
		TextField company = new TextField();
		// contactValue.setStyleName(ValoTheme.TEXTFIELD_LARGE);
		company.setCaption(getBundleValue(CAPTIONS, COMPANY));
		company.setId(COMPANY);
		company.setNullRepresentation("");
		company.setInputPrompt(getBundleValue(MSGS, COMPANY));
		company.setDescription(getBundleValue(MSGS, COMPANY));
		return company;
	}

	public TextField getValue() {
		return contactvalue;
	}

	public Layout getLayoutFields() {
		return layoutFields;
	}

	public BeanFieldGroup<Contact_Entity> getFieldGroup() {
		return contactfieldGroup;
	}

	public TextField getCompany() {
		return companyname;
	}

	public void setCompany(TextField company) {
		this.companyname = company;
	}

	public BeanFieldGroup<Contact_Entity> getContactfieldGroup() {
		return contactfieldGroup;
	}

	public void setContactfieldGroup(BeanFieldGroup<Contact_Entity> contactfieldGroup) {
		this.contactfieldGroup = contactfieldGroup;
	}

	public BeanFieldGroup<Company_Entity> getCompanyfieldGroup() {
		return companyfieldGroup;
	}

	public void setCompanyfieldGroup(BeanFieldGroup<Company_Entity> companyfieldGroup) {
		this.companyfieldGroup = companyfieldGroup;
	}
}
