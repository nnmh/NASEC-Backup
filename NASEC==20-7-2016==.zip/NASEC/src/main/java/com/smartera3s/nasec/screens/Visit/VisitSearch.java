package com.smartera3s.nasec.screens.Visit;

import static com.smartera3s.nasec.controllers.VisitController.SUBMIT;
import static com.smartera3s.nasec.controllers.VisitController.FRONDATE;
import static com.smartera3s.nasec.controllers.PatientSearchController.EDIT;
import static com.smartera3s.nasec.controllers.PatientSearchController.PATIENT_ID;
import static com.smartera3s.nasec.controllers.PatientSearchController.PATIENT_NAME;
import static com.smartera3s.nasec.controllers.PatientSearchController.PATIENT_ID_IDENTIFICATION;
import static com.smartera3s.nasec.controllers.VisitController.TODATE;
import static com.smartera3s.nasec.controllers.VisitController.VISITTYPE;
import static com.smartera3s.utils.InternationalizationFileBundle.CAPTIONS;
import static com.smartera3s.utils.InternationalizationFileBundle.MSGS;
import static com.smartera3s.utils.InternationalizationFileBundle.getBundleValue;

import java.util.List;

import com.smartera3s.nasec.listeners.VisitScreenListener;
import com.smartera3s.nasec.model.entities.Company_Entity;
import com.smartera3s.nasec.model.entities.Contact_Entity;
import com.smartera3s.nasec.model.entities.Patient_Entity;
import com.smartera3s.nasec.model.entities.VisitEntity;
import com.smartera3s.nasec.model.entities.VisitType_Entity;
import com.smartera3s.nasec.services.VisitServices;
import com.vaadin.data.Container;
import com.vaadin.data.fieldgroup.BeanFieldGroup;
import com.vaadin.data.fieldgroup.PropertyId;
import com.vaadin.data.util.BeanItem;
import com.vaadin.data.util.BeanItemContainer;
import com.vaadin.event.ShortcutAction.KeyCode;
import com.vaadin.navigator.View;
import com.vaadin.navigator.ViewChangeListener.ViewChangeEvent;
import com.vaadin.server.ThemeResource;
import com.vaadin.ui.AbstractOrderedLayout;
import com.vaadin.ui.Button;
import com.vaadin.ui.ComboBox;
import com.vaadin.ui.CssLayout;
import com.vaadin.ui.CustomComponent;
import com.vaadin.ui.DateField;
import com.vaadin.ui.HorizontalLayout;
import com.vaadin.ui.Layout;
import com.vaadin.ui.ListSelect;
import com.vaadin.ui.Table;
import com.vaadin.ui.TextField;
import com.vaadin.ui.VerticalLayout;
import com.vaadin.ui.themes.ValoTheme;

@SuppressWarnings("serial")
public class VisitSearch extends CustomComponent implements View {
	
	private Table patientList;

	@PropertyId("fullName")
	private TextField PateintName;

	@PropertyId("id")
	private TextField PateintID;

	@PropertyId("idNumber")
	private TextField PateintNationalId;

	@PropertyId("linkedVisitType")
	private ComboBox visitType;

	@PropertyId("fromDate")
	private DateField VisitDateFrom;

	@PropertyId("toDate")
	private DateField VisitDateTo;

	private Button SearchButtonResult;

	private Layout MainLayout;
	private Layout layoutFields;
	private Layout layoutResult;

	private VisitScreenListener eventsListener;
	private VisitServices Service;
	private BeanFieldGroup<Patient_Entity> fieldPatientGroup;
	private BeanFieldGroup<VisitEntity> fieldVisitGroup;
	String test;
	 List<VisitType_Entity> VisitList;
	public VisitSearch(BeanItem<Patient_Entity> patientItem,BeanItem<VisitEntity> visitItem,VisitScreenListener listener) {
	        Service = new VisitServices();
	        this.eventsListener = listener;
		addLayout();
		VisitList = Service.findAlltype();
		fillLayout(layoutFields);
		addVisitFieldGroup(visitItem);
		addPatientFieldGroup(patientItem);
		
	}

	private void addLayout() {
		// TODO Auto-generated method stub
		MainLayout = new VerticalLayout();
		MainLayout.setStyleName("Search-visit-main-layouts");

		layoutFields = new CssLayout();
		layoutFields.setStyleName("Search-visit-search-field");

		layoutResult = new VerticalLayout();
                layoutResult.setSizeFull();
		
		MainLayout.addComponent(layoutFields);
		MainLayout.addComponent(layoutResult);
		setCompositionRoot(MainLayout);
	}

	private void fillLayout(Layout mainlayout) {
		// TODO Auto-generated method stub

		PateintName = createPateintNameField();
		PateintID = createPateintID();
		PateintNationalId = createPateintNationaId();
		visitType = createVisitTypeField();
		VisitDateFrom = createFromDateField();
		VisitDateTo = createToDateField();
		SearchButtonResult = createSearchButton();

		HorizontalLayout DateFrom = new HorizontalLayout();
		DateFrom.addComponent(VisitDateFrom);
		((AbstractOrderedLayout) DateFrom).setSpacing(true);
		HorizontalLayout DateTo = new HorizontalLayout();
		DateFrom.addComponent(VisitDateTo);
		 
                 visitType.setContainerDataSource(new BeanItemContainer<VisitType_Entity>(VisitType_Entity.class,VisitList));
                 visitType.setItemCaptionPropertyId("displayName");
		
		
		mainlayout.addComponent(PateintName);
		mainlayout.addComponent(PateintID);
		mainlayout.addComponent(PateintNationalId);
		mainlayout.addComponent(visitType);
		mainlayout.addComponent(DateFrom);
		mainlayout.addComponent(DateTo);
		mainlayout.addComponent(SearchButtonResult);
	}

	private TextField createPateintNameField() {
		// TODO Auto-generated method stub
		PateintName = new TextField();
		PateintName.setStyleName(ValoTheme.TEXTFIELD_LARGE);
		PateintName.setInputPrompt(getBundleValue(CAPTIONS, PATIENT_NAME));
		PateintName.setDescription(getBundleValue(MSGS, PATIENT_NAME));
		PateintName.setNullRepresentation("");
		PateintName.setId(PATIENT_NAME);

		return PateintName;
	}

	private ComboBox createVisitTypeField() {
		// TODO Auto-generated method stub
	        ComboBox Type = new ComboBox();
	        Type.setStyleName(ValoTheme.TEXTFIELD_LARGE);
	        Type.setId(VISITTYPE);
	        Type.setNullSelectionItemId(getBundleValue(MSGS,VISITTYPE));
	        Type.setInputPrompt(getBundleValue(MSGS,VISITTYPE));
	        Type.setDescription(getBundleValue(MSGS,VISITTYPE));
	        
	        Type.addValueChangeListener(eventsListener);
	        return Type;
	}

	private TextField createPateintID() {
		// TODO Auto-generated method stub
		PateintID = new TextField();
		PateintID.setStyleName(ValoTheme.TEXTFIELD_LARGE);
		PateintID.setInputPrompt(getBundleValue(CAPTIONS, PATIENT_ID));
		PateintID.setDescription(getBundleValue(MSGS, PATIENT_ID));
//		PateintID.setNullRepresentation(getBundleValue(CAPTIONS,PATIENT_ID));
		PateintID.setId(PATIENT_ID);

		return PateintID;
	}

	private TextField createPateintNationaId() {
		// TODO Auto-generated method stub
		PateintNationalId = new TextField();
		PateintNationalId.setStyleName(ValoTheme.TEXTFIELD_LARGE);
		PateintNationalId.setInputPrompt(getBundleValue(CAPTIONS, PATIENT_ID_IDENTIFICATION));
		PateintNationalId.setDescription(getBundleValue(MSGS, PATIENT_ID_IDENTIFICATION));
		PateintNationalId.setNullRepresentation("");
		PateintNationalId.setId(PATIENT_ID_IDENTIFICATION);

		return PateintNationalId;
	}

	private DateField createFromDateField() {
		// TODO Auto-generated method stub
		VisitDateFrom = new DateField();
		VisitDateFrom.setStyleName(ValoTheme.DATEFIELD_LARGE);
		VisitDateFrom.setCaption(getBundleValue(CAPTIONS, FRONDATE));
		VisitDateFrom.setId(FRONDATE);
		return VisitDateFrom;
	}

	private DateField createToDateField() {
		// TODO Auto-generated method stub
		VisitDateTo = new DateField();
		VisitDateTo.setStyleName(ValoTheme.DATEFIELD_LARGE);
		VisitDateTo.setCaption(getBundleValue(CAPTIONS, TODATE));
		VisitDateTo.setId(TODATE);
		return VisitDateTo;
	}

	private void addControls(Layout layout) {
		SearchButtonResult = createSearchButton();
		// fill related layout
		layout.addComponent(SearchButtonResult);
	}
	
	private Button createSearchButton() {
		SearchButtonResult = new Button(getBundleValue(CAPTIONS, SUBMIT));
		SearchButtonResult.setClickShortcut(KeyCode.ENTER);
		SearchButtonResult.setId(SUBMIT);
		SearchButtonResult.setIcon(new ThemeResource("img/search.PNG"));
		SearchButtonResult.setDescription(getBundleValue(MSGS, SUBMIT));
		SearchButtonResult.addClickListener(eventsListener);
		return SearchButtonResult;
	}
	private Table createPatientList() {
            Table resultList = new Table();
            layoutResult.removeAllComponents();
            layoutResult.addComponent(resultList);
            // resultList.setContainerDataSource(new
            // BeanItemContainer<Patient_Entity>(Patient_Entity.class));

            return resultList;
    }

	
	public void setResultContainer(Container result) {
            patientList = createPatientList();
            patientList.setContainerDataSource(result);
            patientList
                .setVisibleColumns(new Object[] { "linkedVisitType", "patientID", "description", "patient","vistsDateTime" });
            patientList.setColumnHeaders(new String[] { "Visit Type", "Patient ID", "Visit Vescription", "Patient Name","Visit Date" });
        
            patientList.setSelectable(true);
            patientList.setSizeFull();
            patientList.setPageLength(10);
            patientList.setResponsive(true);
            patientList.setImmediate(true);
            patientList.addItemClickListener(eventsListener);
    }
	
	public TextField getPateintName() {
		return PateintName;
	}

	public void setPateintName(TextField pateintName) {
		PateintName = pateintName;
	}

	public TextField getPateintID() {
		return PateintID;
	}

	public void setPateintID(TextField pateintID) {
		PateintID = pateintID;
	}

	public TextField getPateintNationalId() {
		return PateintNationalId;
	}

	public void setPateintNationalId(TextField pateintNationalId) {
		PateintNationalId = pateintNationalId;
	}

	public ComboBox getVisitType() {
		return visitType;
	}

	public void setVisitType(ComboBox visitType) {
	    visitType = visitType;
	}

	public DateField getVisitDateFrom() {
		return VisitDateFrom;
	}

	public void setVisitDateFrom(DateField visitDateFrom) {
		VisitDateFrom = visitDateFrom;
	}

	public DateField getVisitDateTo() {
		return VisitDateTo;
	}

	public void setVisitDateTo(DateField visitDateTo) {
		VisitDateTo = visitDateTo;
	}

	public Layout getMainLayout() {
		return MainLayout;
	}

	public void setMainLayout(Layout mainLayout) {
		MainLayout = mainLayout;
	}

	public Layout getLayoutFields() {
		return layoutFields;
	}

	public void setLayoutFields(Layout layoutFields) {
		this.layoutFields = layoutFields;
	}

	@Override
	public void enter(ViewChangeEvent event) {
		// TODO Auto-generated method stub

	}
	private void addPatientFieldGroup(BeanItem<Patient_Entity> patientItem) {
	    fieldPatientGroup = new BeanFieldGroup<Patient_Entity>(Patient_Entity.class);
	    fieldPatientGroup.setBuffered(false);// not to depend on commitss
	    fieldPatientGroup.setItemDataSource(patientItem);
	    fieldPatientGroup.bindMemberFields(this);
        }
	private void addVisitFieldGroup(BeanItem<VisitEntity> visitItem) {
            fieldVisitGroup = new BeanFieldGroup<VisitEntity>(VisitEntity.class);
            fieldVisitGroup.setBuffered(false);// not to depend on commitss
            fieldVisitGroup.setItemDataSource(visitItem);
            fieldVisitGroup.bindMemberFields(this);
        }

    public BeanFieldGroup<Patient_Entity> getFieldPatientGroup() {
        return fieldPatientGroup;
    }

    public void setFieldPatientGroup(
            BeanFieldGroup<Patient_Entity> fieldPatientGroup) {
        this.fieldPatientGroup = fieldPatientGroup;
    }

    public BeanFieldGroup<VisitEntity> getFieldVisitGroup() {
        return fieldVisitGroup;
    }

    public void setFieldVisitGroup(BeanFieldGroup<VisitEntity> fieldVisitGroup) {
        this.fieldVisitGroup = fieldVisitGroup;
    }
}
