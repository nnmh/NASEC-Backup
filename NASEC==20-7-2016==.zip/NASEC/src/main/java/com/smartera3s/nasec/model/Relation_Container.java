package com.smartera3s.nasec.model;


public class Relation_Container{
    
    private String first;
    private String second;
    private String last;
    private String mobile;
    private String relation;
    
    
    public Relation_Container(String fisrt,String second,String last, String Contact,String Relation_Type) {
            
            setFirst(fisrt);
            setSecond(second);
            setLast(last);
            this.relation=Relation_Type;
            this.mobile=Contact;
    }





    public String getFirst() {
        return first;
    }





    public void setFirst(String first) {
        this.first = first;
    }





    public String getSecond() {
        return second;
    }





    public void setSecond(String second) {
        this.second = second;
    }





    public String getLast() {
        return last;
    }





    public void setLast(String last) {
        this.last = last;
    }





    public String getMobile() {
        return mobile;
    }





    public void setMobile(String mobile) {
        this.mobile = mobile;
    }





    public String getRelation() {
        return relation;
    }





    public void setRelation(String relation) {
        this.relation = relation;
    }





    public String getFullName() {
        return this.first+" "+this.second+" "+this.last;
    }
    
}
