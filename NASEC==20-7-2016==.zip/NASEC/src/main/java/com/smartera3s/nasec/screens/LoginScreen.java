package com.smartera3s.nasec.screens;

import static com.smartera3s.nasec.controllers.LoginController.*;

import com.smartera3s.nasec.listeners.LoginListener;
import com.smartera3s.nasec.model.entities.UserEntity;
import com.smartera3s.utils.InternationalizationFileBundle;
import com.vaadin.data.fieldgroup.BeanFieldGroup;
import com.vaadin.data.fieldgroup.FieldGroup;
import com.vaadin.data.fieldgroup.PropertyId;
import com.vaadin.data.util.BeanItem;
import com.vaadin.event.ShortcutAction.KeyCode;
import com.vaadin.server.FontAwesome;
import com.vaadin.server.Responsive;
import com.vaadin.ui.AbstractOrderedLayout;
import com.vaadin.ui.Alignment;
import com.vaadin.ui.Button;
import com.vaadin.ui.Button.ClickListener;
import com.vaadin.ui.Component;
import com.vaadin.ui.CssLayout;
import com.vaadin.ui.CustomComponent;
import com.vaadin.ui.HorizontalLayout;
import com.vaadin.ui.Label;
import com.vaadin.ui.Layout;
import com.vaadin.ui.PasswordField;
import com.vaadin.ui.TextField;
import com.vaadin.ui.VerticalLayout;
import com.vaadin.ui.themes.ValoTheme;
import static com.smartera3s.utils.InternationalizationFileBundle.*;

public class LoginScreen extends CustomComponent{
	/*
	 * mapping the UI fields with the associated properties of the bean that
	 * will be binded
	 */
	
	private static final String LAYOUTLOGINSTYLE ="LoginView";
	private static final String LOGINFRAMSTYLE ="LoginFram";
	@PropertyId("username")
	private TextField userName;
	@PropertyId("password")
	private PasswordField password;

	// Layouts
	private Layout layoutLogin;
	private Layout layoutFields;
	private Layout layoutControls;

	// FieldGroup that will link between the ui fields and the binded
	// properties of the bean
	private BeanFieldGroup<UserEntity> fieldGroup;

	// Actions & Controls
	private Button loginButton;
	private LoginListener eventsListener;

	// Constructor
	public LoginScreen(BeanItem<UserEntity> userItem, LoginListener listener) {
		this.eventsListener = listener;
		addLayouts();
		addFieldGroup(userItem);
		addControls(layoutControls);
	}

	/*
	 * layout size should be undefined to be responsive to the subcomponents
	 * sizes. while each subcomponent can take its size (fixed or
	 * resolution-conditional)
	 * 
	 */
	private void addLayouts() {
		layoutLogin = new VerticalLayout();
		layoutLogin.setStyleName(LAYOUTLOGINSTYLE);
		layoutLogin.setSizeUndefined();
		((AbstractOrderedLayout) layoutLogin).setSpacing(true);
		Responsive.makeResponsive(layoutLogin);

		VerticalLayout Container = new VerticalLayout();
		Container.setStyleName(LOGINFRAMSTYLE);
		Container.setSizeUndefined();
		Container.setSpacing(true);
        Responsive.makeResponsive(Container);

		layoutFields = new CssLayout();
		layoutFields.setSizeUndefined();
		layoutFields.addComponent(buildFields());

		layoutControls = new CssLayout();
		layoutControls.setSizeUndefined();

		Container.addComponent(buildLabels());
		Container.addComponent(layoutFields);
		Container.addComponent(layoutControls);
		layoutLogin.addComponent(Container);
		Responsive.makeResponsive(Container);
		
		((AbstractOrderedLayout) layoutLogin).setComponentAlignment(Container, Alignment.MIDDLE_CENTER);
		setCompositionRoot(layoutLogin);
		
		//fillFields(layoutFields);
	}

	private void addFieldGroup(BeanItem<UserEntity> user) {
		fieldGroup = new BeanFieldGroup<UserEntity>(UserEntity.class);
		fieldGroup.setBuffered(false);// not to depend on commit
		// you can set any custom factory if you need to change the display
		// component for certain property
		// fieldGroup.setFieldFactory(DefaultFieldGroupFieldFactory.get());
		fieldGroup.setItemDataSource(user);
		/*
		 * this is the core of binding. it takes the class which contains the UI
		 * fields
		 */
		fieldGroup.bindMemberFields(this);
		
	}
	
	private Component buildLabels() {
        CssLayout labels = new CssLayout();
        labels.addStyleName("labels");

        Label welcome = new Label("Welcome");
        welcome.setSizeUndefined();
        welcome.addStyleName(ValoTheme.LABEL_H4);
        welcome.addStyleName(ValoTheme.LABEL_COLORED);
        labels.addComponent(welcome);
        return labels;
    }
	/*private void fillFields(Layout layout){
		// fill the layout
		userName = createUserName();
		password = createPassword();
		layout.addComponent(userName);
		layout.addComponent(password);
	}*/

	private void addControls(Layout layout) {
		loginButton=createLoginButton();
		// fill related layout
		layout.addComponent(loginButton);
	}

	private Component buildFields() {
        HorizontalLayout fields = new HorizontalLayout();
        fields.setSpacing(true);
        fields.addStyleName("fields");

        userName = new TextField("Username");
        userName.setIcon(FontAwesome.USER);
        userName.addStyleName(ValoTheme.TEXTFIELD_INLINE_ICON);
        userName.setId(USER_NAME);
        userName.setNullRepresentation("");
        userName.setDescription(getBundleValue(MSGS,USER_NAME));
		
        password = new PasswordField("Password");
        password.setIcon(FontAwesome.LOCK);
        password.addStyleName(ValoTheme.TEXTFIELD_INLINE_ICON);
        password.setId(PASSW0RD);
        password.setNullRepresentation("");
        password.setDescription(getBundleValue(MSGS,PASSW0RD));
        fields.addComponents(userName, password);
        return fields;
    }
	private Button createLoginButton(){
		Button login = new Button(getBundleValue(CAPTIONS,SUBMIT));
		//login.setStyleName(ValoTheme.BUTTON_PRIMARY);
		login.setClickShortcut(KeyCode.ENTER);
		login.setId(SUBMIT);
		login.setDescription(getBundleValue(MSGS,SUBMIT));
		// assign the listener class that handles events
		login.addClickListener(eventsListener);
		return login;
	}
	
	public Layout getLayoutLogin() {
		return layoutLogin;
	}
	public TextField getUserName() {
		return userName;
	}
	public PasswordField getPassword() {
		return password;
	}
	public Button getLoginButton() {
		return loginButton;
	}
	
	// common screens functions
	public void resetFields() {
		// TODO clear the values of all components
	}
	public FieldGroup getFieldGroup() {
		return fieldGroup;
	}	
}
