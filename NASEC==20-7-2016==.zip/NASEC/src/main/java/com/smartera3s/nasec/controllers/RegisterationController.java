package com.smartera3s.nasec.controllers;

import static com.smartera3s.utils.InternationalizationFileBundle.*;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.atmosphere.interceptor.AtmosphereResourceStateRecovery.B;

import com.smartera3s.nasec.listeners.RegisterationScreenListener;
import com.smartera3s.nasec.model.Company_Contanier;
import com.smartera3s.nasec.model.Relation_Container;
import com.smartera3s.nasec.model.SysContext;
import com.smartera3s.nasec.model.entities.Address_Entity;
import com.smartera3s.nasec.model.entities.Company_Entity;
import com.smartera3s.nasec.model.entities.Companyrelationtype;
import com.smartera3s.nasec.model.entities.Contact_Entity;
import com.smartera3s.nasec.model.entities.PatientCompany;
import com.smartera3s.nasec.model.entities.PatientRelation;
import com.smartera3s.nasec.model.entities.Patient_Entity;
import com.smartera3s.nasec.model.entities.Relation;
import com.smartera3s.nasec.screens.patientSearch.PatientSearchScreen;
import com.smartera3s.nasec.screens.reg.*;
import com.smartera3s.nasec.services.RegisterationService;
import com.vaadin.data.Property;
import com.vaadin.data.Property.ValueChangeEvent;
import com.vaadin.data.fieldgroup.BeanFieldGroup;
import com.vaadin.data.util.BeanItem;
import com.vaadin.data.util.BeanItemContainer;
import com.vaadin.server.VaadinService;
import com.vaadin.server.Sizeable.Unit;
import com.vaadin.ui.Button;
import com.vaadin.ui.Component;
import com.vaadin.ui.CustomComponent;
import com.vaadin.ui.HorizontalLayout;
import com.vaadin.ui.Notification;
import com.vaadin.ui.Table;
import com.vaadin.ui.UI;
import com.vaadin.ui.Window;
import com.vaadin.ui.Button.ClickEvent;
import com.vaadin.ui.Notification.Type;

public class RegisterationController implements UIController {
    public static final String FISRT_NAME = "register.firstName";
    public static final String SECOND_NAME = "register.secondName";
    public static final String LAST_NAME = "register.lastName";
    public static final String DOB = "register.dob";
    public static final String PRIMARY_CONTACT = "register.primary_Contact";
    public static final String IDNUMBER = "register.idNumber";
    public static final String IDTYPE = "register.id_Type";
    public static final String ADDRESS = "register.address";
    public static final String POSTALCODE = "register.postal";
    public static final String REGION = "register.region";
    public static final String GENDER = "register.gender";
    public static final String PAYMENT = "register.payment";
    public static final String NATIONALITY = "register.nationality";
    public static final String MARTIAL_STATUS = "register.status";
    public static final String COUNTRY = "register.country";
    public static final String CITY = "register.city";
    public static final String SAVE = "register.save";
    public static final String CONTACT = "register.contact";
    public static final String CONTACT_TYPE = "register.type";
    public static final String RELATION_TYPE = "register.rtype";
    public static final String ADD = "register.addcontact";
    public static final String ADDR = "register.relation";
    public static final String COMPANY_NAME = "register.company";
    public static final String INSURANCE_NUMBER = "register.insurance";
    public static final String COMPANYR = "register.companyr";
    public static final String ADDCCCC = "register.addcompany";
    public static final String ID = "patient.patientid";
    public static final String REGISTERATION = "register.msg";
    public static final String VIEW_NAME = "Patient Registration";
    public static final String SEARCH = "register.search";

    public static int PATIENTID;
    
    // Beans Containers For tables
    private BeanItemContainer<Relation_Container> relationContainer;
    private BeanItemContainer<Company_Contanier> companyContainer;
    private BeanItemContainer<Contact_Entity> contactContainer;

    // Model
    private Patient_Entity Patient; 
    private Patient_Entity Patient2;
    private Contact_Entity primaryContact;
    private Contact_Entity additionalContact;
    private Address_Entity Address;
    private Relation Relation;
    private PatientRelation PatientRelation;
    private Company_Entity Company;
    private PatientCompany PatientCompany;
    
    // View
    private RegisterationScreen screen; 
    private Window window;
    private PatientSearchScreen patientSearchscreen;

    private RegisterationScreenListener listener; // Actions & Events listener
    private RegisterationService RegisterService; // managing service
    
    //Beans Item for Table data
    private BeanItem<Contact_Entity> contactBeanItem;
    private BeanItem<Contact_Entity> relationcontactBeanItem;
    private BeanItem<Relation_Container> relationBeanItem;
    private BeanItem<Company_Contanier> companyBeanItem;
    
    //Controller
    private UIController callerController;
    
    // For Saving Current Patient
    private Object SelectedPatient;
    private SysContext context;

    public RegisterationController() {
        patientSearchscreen = (PatientSearchScreen) new PatientSearchController(
                this).getView();
        contactContainer = new BeanItemContainer<Contact_Entity>(
                Contact_Entity.class);

        relationContainer = new BeanItemContainer<Relation_Container>(
                Relation_Container.class);

        companyContainer = new BeanItemContainer<Company_Contanier>(
                Company_Contanier.class);
        context = (SysContext) VaadinService.getCurrentRequest()
                .getWrappedSession().getAttribute(SysContext.class.getName());
        Patient = new Patient_Entity();
        Patient2 = new Patient_Entity();
        primaryContact = new Contact_Entity();
        additionalContact = new Contact_Entity();
        Address = new Address_Entity();
        Relation = new Relation();
        PatientRelation = new PatientRelation();
        Company = new Company_Entity();
        PatientCompany = new PatientCompany();
        listener = new RegisterationScreenListener(this);

        screen = new RegisterationScreen(new BeanItem<Patient_Entity>(Patient),
                new BeanItem<Contact_Entity>(primaryContact),
                new BeanItem<Contact_Entity>(additionalContact),
                new BeanItem<Address_Entity>(Address),
                new BeanItem<PatientRelation>(PatientRelation),
                new BeanItem<Company_Entity>(Company),
                new BeanItem<PatientCompany>(PatientCompany), listener);
        screen.getContactInformation().getContacts()
                .setContainerDataSource(contactContainer);
        screen.getContactInformation().getContacts()
                .setVisibleColumns("contact_type", "value", "primaryContact");
        screen.getContactInformation().getContacts().setColumnHeaders(
                new String[] { "Contact Type", "Contact", "Primary Contact" });
        screen.getContactInformation().getContacts().addGeneratedColumn("Remove",
                new Table.ColumnGenerator() {
                    public Object generateCell(Table source,
                            final Object itemId, Object columnId) {
                        HorizontalLayout Contact_Table_Horizontal_Layout = new HorizontalLayout();
                        Button removeButton = new Button("-");
                        removeButton
                                .addClickListener(new Button.ClickListener() {
                                    public void buttonClick(ClickEvent event) {
                                        contactContainer.removeItem(itemId);
                                    }
                                });
                        Contact_Table_Horizontal_Layout
                                .addComponent(removeButton);
                        return Contact_Table_Horizontal_Layout;
                    }
                });
        screen.getBasic().getPrimaryContact()
                .addValueChangeListener(new Property.ValueChangeListener() {
                    public void valueChange(ValueChangeEvent event) {

                        Object x = event.getProperty().getValue();
                        if (x != null) {
                            Contact_Entity primary = new Contact_Entity(
                                    "Mobile", x.toString(), true);
                            contactContainer.addBean(primary);
                        }
                    }
                });
        screen.getRelationInformation().getRelations()
                .setContainerDataSource(relationContainer);
        screen.getRelationInformation().getRelations().setVisibleColumns("fullName",
                "relation", "mobile");
        screen.getRelationInformation().getRelations().setColumnHeaders(
                new String[] { "Full Name", "Patient Relation", "Mobile" });
        screen.getRelationInformation().getRelations().addGeneratedColumn("Remove",
                new Table.ColumnGenerator() {
                    public Object generateCell(Table source,
                            final Object itemId, Object columnId) {
                        HorizontalLayout Relation_Table_Horizontal_Layout = new HorizontalLayout();
                        Button removeButton = new Button("-");
                        removeButton
                                .addClickListener(new Button.ClickListener() {
                                    public void buttonClick(ClickEvent event) {
                                        relationContainer.removeItem(itemId);
                                    }
                                });
                        Relation_Table_Horizontal_Layout
                                .addComponent(removeButton);
                        return Relation_Table_Horizontal_Layout;
                    }
                });
        screen.getCompanyInformation().getCompanies()
                .setContainerDataSource(companyContainer);
        screen.getCompanyInformation().getCompanies().setVisibleColumns("name",
                "type", "insurance_number");
        screen.getCompanyInformation().getCompanies().setColumnHeaders(
                new String[] { "Company Name", "Company Relation", "Patient Number" });
        screen.getCompanyInformation().getCompanies().addGeneratedColumn("Remove",
                new Table.ColumnGenerator() {
                    public Object generateCell(Table source,
                            final Object itemId, Object columnId) {
                        HorizontalLayout Company_Table_Horizontal_Layout = new HorizontalLayout();
                        Button removeButton = new Button("-");
                        removeButton
                                .addClickListener(new Button.ClickListener() {
                                    public void buttonClick(ClickEvent event) {
                                        companyContainer.removeItem(itemId);
                                    }
                                });
                        Company_Table_Horizontal_Layout
                                .addComponent(removeButton);
                        return Company_Table_Horizontal_Layout;
                    }
                });

        RegisterService = new RegisterationService();

    }

    public RegisterationController(UIController caller) {
        patientSearchscreen = (PatientSearchScreen) new PatientSearchController(
                this).getView();
        this.callerController = caller;
        context = (SysContext) VaadinService.getCurrentRequest()
                .getWrappedSession().getAttribute(SysContext.class.getName());
        contactContainer = new BeanItemContainer<Contact_Entity>(
                Contact_Entity.class);
        relationContainer = new BeanItemContainer<Relation_Container>(
                Relation_Container.class);

        companyContainer = new BeanItemContainer<Company_Contanier>(
                Company_Contanier.class);

        Patient = new Patient_Entity();
        Patient2 = new Patient_Entity();
        primaryContact = new Contact_Entity();
        additionalContact = new Contact_Entity();
        Address = new Address_Entity();
        Relation = new Relation();
        PatientRelation = new PatientRelation();
        Company = new Company_Entity();
        PatientCompany = new PatientCompany();
        listener = new RegisterationScreenListener(this);

        screen = new RegisterationScreen(new BeanItem<Patient_Entity>(Patient),
                new BeanItem<Contact_Entity>(primaryContact),
                new BeanItem<Contact_Entity>(additionalContact),
                new BeanItem<Address_Entity>(Address),
                new BeanItem<PatientRelation>(PatientRelation),
                new BeanItem<Company_Entity>(Company),
                new BeanItem<PatientCompany>(PatientCompany), listener);
        screen.getContactInformation().getContacts()
                .setContainerDataSource(contactContainer);
        screen.getContactInformation().getContacts()
                .setVisibleColumns("contact_type", "value", "primaryContact");
        screen.getContactInformation().getContacts().addGeneratedColumn("Remove",
                new Table.ColumnGenerator() {
                    public Object generateCell(Table source,
                            final Object itemId, Object columnId) {
                        HorizontalLayout Contact_Table_Horizontal_Layout = new HorizontalLayout();
                        Button removeButton = new Button("-");
                        removeButton
                                .addClickListener(new Button.ClickListener() {
                                    public void buttonClick(ClickEvent event) {
                                        screen.getContactInformation()
                                                .getContacts()
                                                .getContainerDataSource()
                                                .removeItem(itemId);
                                    }
                                });
                        Contact_Table_Horizontal_Layout
                                .addComponent(removeButton);
                        return Contact_Table_Horizontal_Layout;
                    }
                });
        screen.getBasic().getPrimaryContact()
                .addValueChangeListener(new Property.ValueChangeListener() {
                    public void valueChange(ValueChangeEvent event) {

                        Object x = event.getProperty().getValue();
                        if (x != null) {
                            Contact_Entity primary = new Contact_Entity(
                                    "Mobile", x.toString(), true);
                            screen.getContactInformation().getContacts()
                                    .getContainerDataSource().addItem(primary);
                        }
                    }
                });
        screen.getRelationInformation().getRelations()
                .setContainerDataSource(relationContainer);
        screen.getRelationInformation().getRelations().setVisibleColumns("fullName",
                "relation", "mobile");
        screen.getRelationInformation().getRelations().addGeneratedColumn("Remove",
                new Table.ColumnGenerator() {
                    public Object generateCell(Table source,
                            final Object itemId, Object columnId) {
                        HorizontalLayout Relation_Table_Horizontal_Layout = new HorizontalLayout();
                        Button removeButton = new Button("-");
                        removeButton
                                .addClickListener(new Button.ClickListener() {
                                    public void buttonClick(ClickEvent event) {
                                        screen.getRelationInformation()
                                                .getRelations()
                                                .getContainerDataSource()
                                                .removeItem(itemId);
                                    }
                                });
                        Relation_Table_Horizontal_Layout
                                .addComponent(removeButton);
                        return Relation_Table_Horizontal_Layout;
                    }
                });
        screen.getCompanyInformation().getCompanies()
                .setContainerDataSource(companyContainer);
        screen.getCompanyInformation().getCompanies().setVisibleColumns("name",
                "type", "insurance_number");
        screen.getCompanyInformation().getCompanies().addGeneratedColumn("Remove",
                new Table.ColumnGenerator() {
                    public Object generateCell(Table source,
                            final Object itemId, Object columnId) {
                        HorizontalLayout Company_Table_Horizontal_Layout = new HorizontalLayout();
                        Button removeButton = new Button("-");
                        removeButton
                                .addClickListener(new Button.ClickListener() {
                                    public void buttonClick(ClickEvent event) {
                                        screen.getCompanyInformation()
                                                .getCompanies()
                                                .getContainerDataSource()
                                                .removeItem(itemId);
                                    }
                                });
                        Company_Table_Horizontal_Layout
                                .addComponent(removeButton);
                        return Company_Table_Horizontal_Layout;
                    }
                });

        RegisterService = new RegisterationService();

    }

    public void save() {
        BeanItem<Patient_Entity> patientItem = (BeanItem<Patient_Entity>) screen
                .getFieldGroupPatient().getItemDataSource();
        BeanItem<Contact_Entity> contactItem = (BeanItem<Contact_Entity>) screen
                .getFieldGroupContact().getItemDataSource();
        BeanItem<Address_Entity> addressItem = (BeanItem<Address_Entity>) screen
                .getFieldGroupAddress().getItemDataSource();

        if (screen.getBasic().getPatientID().getValue().isEmpty()) {
            Patient = RegisterService.createPatient(patientItem, screen);

            PATIENTID = Patient.getId();
            screen.getBasic().getPatientID().setValue(String.valueOf(PATIENTID));

            for (Object itemId : screen.getContactInformation().getContacts()
                    .getContainerDataSource().getItemIds()) {
                contactBeanItem = (BeanItem<Contact_Entity>) screen
                        .getContactInformation().getContacts()
                        .getContainerDataSource().getItem(itemId);
                RegisterService.createContact(Patient, contactBeanItem);// hold
                                                                        // each
                                                                        // returned
                                                                        // contact
                                                                        // to
                                                                        // displa
            }

            Address = RegisterService.createAddress(Patient, addressItem);
            createPatientRelation(Patient);
            createPatientCompany(Patient);

            SelectedPatient = Patient;
            context.setSelectedPatient((Patient_Entity) SelectedPatient);
            if (callerController != null) {
                callerController
                        .setNotification("Registeration Susuccessfully");
                Notification.show(getBundleValue(MSGS, REGISTERATION),
                        Type.TRAY_NOTIFICATION);
            }

        } else {
            System.out.println("Not");
            SelectedPatient = context.getSelectedPatient();
            RegisterService.updatePatient((Patient_Entity) SelectedPatient,
                    patientItem, screen);
            removecontacts();
            for (Object itemId : screen.getContactInformation().getContacts()
                    .getContainerDataSource().getItemIds()) {
                contactBeanItem = (BeanItem<Contact_Entity>) screen
                        .getContactInformation().getContacts()
                        .getContainerDataSource().getItem(itemId);
                RegisterService.updateContact((Patient_Entity) SelectedPatient,
                        contactBeanItem);// hold each returned contact to
                                         // display
            }

            RegisterService.updateAddress((Patient_Entity) SelectedPatient,
                    Address, addressItem);
            removePatientCompany(((Patient_Entity) SelectedPatient).getId());
            createPatientCompany((Patient_Entity) SelectedPatient);
            removePatientRelation(((Patient_Entity) SelectedPatient).getId());
            createPatientRelation((Patient_Entity) SelectedPatient);
        }
    }

    public void removecontacts() {
        List<Integer> contacts = RegisterService
                .Search_contact(((Patient_Entity) SelectedPatient).getId());
        int pID = 0;
        for (int i = 0; i < contacts.size(); i++) {
            pID = Integer.parseInt(contacts.get(i).toString());
            RegisterService.EntityManager.getTransaction().begin();
            RegisterService.removeContact(pID);
            RegisterService.EntityManager.flush();
            RegisterService.EntityManager.getTransaction().commit();
        }
    }

    public void createPatientRelation(Patient_Entity Patient1) {
        for (Object itemId : screen.getRelationInformation().getRelations()
                .getContainerDataSource().getItemIds()) {
            relationBeanItem = (BeanItem<Relation_Container>) screen
                    .getRelationInformation().getRelations()
                    .getContainerDataSource().getItem(itemId);

            Patient2 = RegisterService.createPatient2(screen, relationBeanItem);

            // RegisterService.createContact(Patient2,screen);
            Relation.setRelation_type(screen.getRelationInformation()
                    .getRelationtype().getValue().toString());
            Relation.setId(
                    RegisterService.findRtypeid(screen.getRelationInformation()
                            .getRelationtype().getValue().toString()));
            RegisterService.createPatientRelation(Patient1, Patient2, Relation);
        }
    }

    public void createPatientCompany(Patient_Entity Patient1) {
        for (Object itemId : screen.getCompanyInformation().getCompanies()
                .getContainerDataSource().getItemIds()) {
            companyBeanItem = (BeanItem<Company_Contanier>) screen
                    .getCompanyInformation().getCompanies()
                    .getContainerDataSource().getItem(itemId);

            Company = RegisterService.createCompany(screen, companyBeanItem);
            RegisterService.createPatientCompany(Patient1, Company,
                    companyBeanItem);
        }
    }

    public void addcontact() {
        if (screen.getContactInformation().getContacttype().getValue() != null
                && !screen.getContactInformation().getAdcontact().getValue()
                        .equals("")) {
            screen.getContactInformation().getContacts()
                    .getContainerDataSource()
                    .addItem(new Contact_Entity(
                            screen.getContactInformation().getContacttype()
                                    .getValue().toString(),
                            screen.getContactInformation().getAdcontact()
                                    .getValue(),
                            false));
            screen.getContactInformation().getContacts().refreshRowCache();
        }
    }

    public void addrelation() {
        if (screen.getRelationInformation().getRelationtype().getValue() != null
                && !screen.getRelationInformation().getRelationfirstName()
                        .getValue().equals("")) {
            screen.getRelationInformation().getRelations()
                    .getContainerDataSource()
                    .addItem(new Relation_Container(
                            screen.getRelationInformation()
                                    .getRelationfirstName().getValue(),
                            screen.getRelationInformation()
                                    .getRelationsecondName().getValue(),
                            screen.getRelationInformation()
                                    .getRelationlastName().getValue(),
                            screen.getRelationInformation()
                                    .getRelationprimaryContact().getValue(),
                            screen.getRelationInformation().getRelationtype()
                                    .getValue().toString()));
        }
    }

    public void addcompany() {
        if (screen.getCompanyInformation().getCompanyName()
                .getValue() != null) {
            Companyrelationtype c = ((Companyrelationtype) (screen
                    .getCompanyInformation().getCompanyRType().getValue()));
            screen.getCompanyInformation().getCompanies()
                    .getContainerDataSource()
                    .addItem(new Company_Contanier(
                            screen.getCompanyInformation().getCompanyName()
                                    .getValue(),
                            screen.getCompanyInformation().getInsuranceNumber()
                                    .getValue(),
                            screen.getCompanyInformation().getCompanyContact()
                                    .getValue(),
                            c.getId(), c.getDisplayName()));
        }
    }

    public void removePatientCompany(int patientID) {
        RegisterService.EntityManager.getTransaction().begin();

        List<Object[]> company = RegisterService.findPatient_Company(patientID);
        for (int i = 0; i < company.size(); i++) {

            RegisterService.removePatientCompany(
                    Integer.parseInt(company.get(i)[0].toString()),
                    Integer.parseInt(company.get(i)[1].toString()));
        }
        RegisterService.EntityManager.flush();
        RegisterService.EntityManager.getTransaction().commit();
    }

    public void removePatientRelation(int patientID) {
        RegisterService.EntityManager.getTransaction().begin();

        RegisterService.removeRelation(patientID);

        RegisterService.EntityManager.flush();
        RegisterService.EntityManager.getTransaction().commit();
    }

    public void searchPatient() {
        window = new Window("Patient Search");
        window.setWidth(900.0f, Unit.PIXELS);
        window.setHeight(600.0f, Unit.PIXELS);
        screen.getWindowLayout().addComponent(patientSearchscreen);
        window.setContent(screen.getWindowLayout());
        window.setModal(true);
        UI.getCurrent().addWindow(window);
        patientSearchscreen.getPatientSubscreen().getFieldGroup()
                .setItemDataSource(screen.getBasic().getPatientfieldGroup()
                        .getItemDataSource());
    }

    @Override
    public CustomComponent getView() {
        // TODO Auto-generated method stub
        return screen;
    }

    @Override
    public void setNotification(String msg) {
        // TODO Auto-generated method stub

    }
}
