package com.smartera3s.nasec.controllers;

import static com.smartera3s.utils.InternationalizationFileBundle.MSGS;
import static com.smartera3s.utils.InternationalizationFileBundle.getBundleValue;

import java.io.File;
import java.sql.Date;
import java.util.List;

import com.smartera3s.nasec.listeners.PatientSearchListener;
import com.smartera3s.nasec.listeners.VisitScreenListener;
import com.smartera3s.nasec.model.SysContext;
import com.smartera3s.nasec.model.entities.Contact_Entity;
import com.smartera3s.nasec.model.entities.Device;
import com.smartera3s.nasec.model.entities.Operationlist;
import com.smartera3s.nasec.model.entities.Patient_Entity;
import com.smartera3s.nasec.model.entities.Staff_Entity;
import com.smartera3s.nasec.model.entities.UserEntity;
import com.smartera3s.nasec.model.entities.VisitEntity;
import com.smartera3s.nasec.model.entities.VisitType_Entity;
import com.smartera3s.nasec.screens.Visit.VisitScreen;
import com.smartera3s.nasec.screens.Visit.VisitSearch;
import com.smartera3s.nasec.screens.patientSearch.PatientSearchScreen;
import com.smartera3s.nasec.screens.reg.RegisterationScreen;
import com.smartera3s.nasec.services.VisitServices;
import com.smartera3s.utils.ControllersSelector;
import com.vaadin.data.Container;
import com.vaadin.data.Property;
import com.vaadin.data.Property.ValueChangeEvent;
import com.vaadin.data.util.BeanItem;
import com.vaadin.data.util.BeanItemContainer;
import com.vaadin.navigator.Navigator;
import com.vaadin.server.FileResource;
import com.vaadin.server.VaadinService;
import com.vaadin.server.Sizeable.Unit;
import com.vaadin.ui.CustomComponent;
import com.vaadin.ui.Label;
import com.vaadin.ui.Notification;
import com.vaadin.ui.UI;
import com.vaadin.ui.Window;
import com.vaadin.ui.Notification.Type;

public class VisitController implements UIController {

    public static final String PATIENTID = "visit.patientid";
    public static final String PATIENTNATIONALID = "visit.patientnationalid";
    public static final String FRONDATE = "visit.VisitDateFrom";
    public static final String TODATE = "visit.VisitDateTo";
    public static final String SUBMIT = "visit.submit";
    public static final String LOAD = "visit.loadbutton";
    public static final String VISITSEARCH = "visit.searchbutton";
    public static final String ADD = "visit.addbutton";
    public static final String SAVEREQUEST = "visit.savebutton";
    public static final String PATIENTNAME = "visit.patientname";
    public static final String VISITTYPE = "visit.type";
    public static final String VISITPAYMENT = "visit.payment";
    public static final String DESCRIPTION = "visit.description";
    public static final String VIEW_NAME = "Visit Service";
    public static final String VISIT = "visit.msg";
    public static final String VISITDATE = "visit.date";
    public static final String VISITID = "visit.id";
    public static final String PATIENTSELECTED = "search.srvs.successfulSelection";
    
    
    // View
    private PatientSearchScreen patientSubscreen;
    private RegisterationScreen Registeration;
    private VisitSearch Visitsearch;
    private VisitScreen screen;
    private Window window;
    
    private VisitScreenListener eventListener; // Actions & Events listener
    
    //Services
    private VisitServices Services;
    
    // Model
    private VisitEntity visitSample; 
    private VisitEntity visitSearch;
    private Patient_Entity patientSample;
    
    
    //Controllers
    private UIController callerController;
    private Navigator navigator;
    private ClinicController Clinic;
    private InvestigationController Investigation;
    private OperationController Operation;
    private NurseController Nurse;
    private ControllersSelector Selector;
    private UIController controller;
    
    //Saving Current Data
    private SysContext context;
    private Patient_Entity SelectedPatient;
    private Object SelectedVisit;
    
   

    public VisitController(Navigator navigator) {
        this.navigator = navigator;
        Selector = new ControllersSelector();
        
        patientSubscreen = (PatientSearchScreen) new PatientSearchController(
                this).getView();
        Registeration = (RegisterationScreen) new RegisterationController(this)
                .getView();
        eventListener = new VisitScreenListener(this);
        visitSample = new VisitEntity();
        visitSearch = new VisitEntity();
        patientSample = new Patient_Entity();
        Clinic = (ClinicController) Selector.get(ClinicController.class);
        Investigation = new InvestigationController();
        Operation = new OperationController();
        Nurse = new NurseController();

        screen = new VisitScreen(new BeanItem<Patient_Entity>(patientSample),
                new BeanItem<VisitEntity>(visitSample),
                new BeanItem<VisitEntity>(visitSample), eventListener);
        Services = new VisitServices();
        context = (SysContext) VaadinService.getCurrentRequest()
                .getWrappedSession().getAttribute(SysContext.class.getName());
        refreshVisit();
    }

    public VisitController(UIController caller, Navigator navigator) {
        this.callerController = caller;
        this.navigator = navigator;
        Selector = new ControllersSelector();
        patientSubscreen = (PatientSearchScreen) new PatientSearchController(
                this).getView();
        Registeration = (RegisterationScreen) new RegisterationController(this)
                .getView();
        eventListener = new VisitScreenListener(this);
        visitSample = new VisitEntity(); 
        visitSearch = new VisitEntity();
        patientSample = new Patient_Entity();
        Investigation = new InvestigationController();
        Operation = new OperationController();
        Nurse = new NurseController();

        screen = new VisitScreen(new BeanItem<Patient_Entity>(patientSample),
                new BeanItem<VisitEntity>(visitSample),
                new BeanItem<VisitEntity>(visitSample), eventListener);
        Services = new VisitServices();
        context = (SysContext) VaadinService.getCurrentRequest()
                .getWrappedSession().getAttribute(SysContext.class.getName());

        refreshVisit();
    }

    public void load() {
        window = new Window("Patient Search");
        window.setWidth(900.0f, Unit.PIXELS);
        window.setHeight(600.0f, Unit.PIXELS);
        screen.getWindowLayout().addComponent(patientSubscreen);
        window.setContent(screen.getWindowLayout());
        window.setModal(true);
        UI.getCurrent().addWindow(window);
    }

    public void add() {
        window = new Window("Patient Register");
        window.setWidth(900.0f, Unit.PIXELS);
        window.setHeight(600.0f, Unit.PIXELS);
        screen.getWindowLayout2().addComponent(Registeration);
        window.setModal(true);
        window.setContent(screen.getWindowLayout2());
        UI.getCurrent().addWindow(window);
    }

    void refreshVisit() {
        SelectedPatient = context.getSelectedPatient();
        if (SelectedPatient == null) {

        } else {

            screen.getVisitService().getPatientID()
                    .setValue(SelectedPatient.getId().toString());
            screen.getVisitService().getPatientName()
                    .setValue(SelectedPatient.getFirst_name() + " "
                            + SelectedPatient.getSecond_name() + " "
                            + SelectedPatient.getLast_name());
            if (SelectedPatient.getProfile_pic() != null) {
                screen.getVisitService().getMyLocalImage()
                        .setSource(new FileResource(
                                new File(SelectedPatient.getProfile_pic())));
            }
        }

    }
    

    public void saveRequest() {
        BeanItem<VisitEntity> visitItem = (BeanItem<VisitEntity>) screen
                .getFieldGroup().getItemDataSource();
        visitSample.setPatientID(String.valueOf(SelectedPatient.getId()));
        visitSample = Services.createVisit(visitItem);

        context.setCurrentVisit((VisitEntity) visitSample);
        
        if (visitItem.getBean().getLinkedVisitType().getType()
                .equals("Clinic Visit")) {
            navigator.navigateTo(
                    Selector.get(ClinicController.class).getClass().getName());
            ((ClinicController) Selector.get(ClinicController.class))
                    .refreshClinic();
        }
        if (visitItem.getBean().getLinkedVisitType().getType()
                .equals("Investigation")) {
            navigator.navigateTo(Investigation.getClass().getName());

        }
        if (visitItem.getBean().getLinkedVisitType().getType()
                .equals("Operation")) {
            navigator.navigateTo(Operation.getClass().getName());

        }
        if (visitItem.getBean().getLinkedVisitType().getType()
                .equals("Follow Up")) {
            navigator.navigateTo(Nurse.getClass().getName());

        }

        Notification.show(getBundleValue(MSGS, VISIT), Type.TRAY_NOTIFICATION);
    }

    public void visitTO(ValueChangeEvent event) {
        VisitType_Entity x = (VisitType_Entity) event.getProperty().getValue();
        if (x.getType() != null) {
            if (x.getType().equals("Clinic Visit")) {
                screen.getVisitService().getVisitTo().setVisible(true);
                screen.getVisitService().getVisitTo().setContainerDataSource(
                        new BeanItemContainer<Staff_Entity>(Staff_Entity.class,
                                screen.getVisitService().getDoctorList()));

            }
            if (x.getType().equals("Investigation")) {
                screen.getVisitService().getVisitTo().setVisible(true);
                screen.getVisitService().getVisitTo().setContainerDataSource(
                        new BeanItemContainer<Device>(Device.class,
                                screen.getVisitService().getDevicesList()));

            }
            if (x.getType().equals("Operation")) {
                screen.getVisitService().getVisitTo().setVisible(true);
                screen.getVisitService().getVisitTo().setContainerDataSource(
                        new BeanItemContainer<Operationlist>(
                                Operationlist.class,
                                screen.getVisitService().getOperationtList()));
            }
            if (x.getType().equals("Follow Up")) {
                screen.getVisitService().getVisitTo().setVisible(true);
                screen.getVisitService().getVisitTo().setContainerDataSource(
                        new BeanItemContainer<Staff_Entity>(Staff_Entity.class,
                                screen.getVisitService().getDoctorList()));
            }
        }

    }

    public void search() {
        // TODO hit DB for
        BeanItem<Patient_Entity> patientItem = (BeanItem<Patient_Entity>) screen
                .getFieldGroupPatient().getItemDataSource();
        BeanItem<VisitEntity> visitItem = (BeanItem<VisitEntity>) screen
                .getFieldGroupVisit().getItemDataSource();
        try {
            Container result = Services.search(patientItem.getBean(),
                    visitItem.getBean());
            screen.getVisitsearch().setResultContainer(result);

            // TODO handle result
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            Notification.show("Exceptions: " + e.getMessage(),
                    Type.WARNING_MESSAGE);
        }
    }

    public void selectVisit(Object value) {
        Notification.show(getBundleValue(MSGS, PATIENTSELECTED),
                Type.TRAY_NOTIFICATION);
        SelectedVisit = value;
        context.setCurrentVisit((VisitEntity) SelectedVisit);
        visitSearch = context.getCurrentVisit();
        SelectedPatient = visitSearch.getPatient();
        context.setSelectedPatient((Patient_Entity) SelectedPatient);
        window.close();
        if (visitSearch.getVisitTypeID() == 1){
            navigator.navigateTo(
                    Selector.get(ClinicController.class).getClass().getName());
            ((ClinicController) Selector.get(ClinicController.class))
                    .refreshClinic();
            ((ClinicController) Selector.get(ClinicController.class))
            .refreshClinicContents();
        }
        if (callerController != null) {
            callerController.setNotification("Selection Susuccessfully");
            Notification.show(getBundleValue(MSGS, PATIENTSELECTED),
                    Type.TRAY_NOTIFICATION);
        }

    }

    @Override
    public CustomComponent getView() {
        // TODO Auto-generated method stub
        return screen;
    }

    @Override
    public void setNotification(String msg) {
        if (msg != null && msg.equals("Selection Susuccessfully")
                || msg.equals("Registeration Susuccessfully")) {
            window.close();
            refreshVisit();
        }

    }

    public void searchbutton() {
        // TODO Auto-generated method stub
        window = new Window("Search Visit");
        window.setWidth(1024.0f, Unit.PIXELS);
        window.setHeight(800.0f, Unit.PIXELS);
        screen.getWindowLayout3().addComponent(screen.getVisitsearch());
        window.setModal(true);
        window.setContent(screen.getWindowLayout3());
        UI.getCurrent().addWindow(window);
    }
}
