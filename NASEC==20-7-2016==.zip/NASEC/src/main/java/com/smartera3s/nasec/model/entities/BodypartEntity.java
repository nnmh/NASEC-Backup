package com.smartera3s.nasec.model.entities;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the bodypart database table.
 * 
 */
@Entity
@Table(name="bodypart")
@NamedQuery(name="BodypartEntity.findAll", query="SELECT b FROM BodypartEntity b")
public class BodypartEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int id;

	private String name;

	private String parentpartid;

	public BodypartEntity() {
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getParentpartid() {
		return this.parentpartid;
	}

	public void setParentpartid(String parentpartid) {
		this.parentpartid = parentpartid;
	}

	public String getDisplayName(){
            return name;
        }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + id;
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        BodypartEntity other = (BodypartEntity) obj;
        if (id != other.id)
            return false;
        return true;
    }
    @Override
    public String toString() {
        return this.name;
    }

}