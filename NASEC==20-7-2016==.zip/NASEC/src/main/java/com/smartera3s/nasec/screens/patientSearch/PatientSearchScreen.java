package com.smartera3s.nasec.screens.patientSearch;

import static com.smartera3s.nasec.controllers.PatientSearchController.*;
import static com.smartera3s.utils.InternationalizationFileBundle.*;

import java.util.List;

import com.smartera3s.nasec.listeners.PatientSearchListener;
import com.smartera3s.nasec.model.entities.Company_Entity;
import com.smartera3s.nasec.model.entities.Contact_Entity;
import com.smartera3s.nasec.model.entities.Patient_Entity;
import com.vaadin.data.Container;
import com.vaadin.data.fieldgroup.BeanFieldGroup;
import com.vaadin.data.util.BeanItem;
import com.vaadin.data.util.BeanItemContainer;
import com.vaadin.event.ShortcutAction.KeyCode;
import com.vaadin.navigator.View;
import com.vaadin.navigator.ViewChangeListener.ViewChangeEvent;
import com.vaadin.server.Responsive;
import com.vaadin.ui.AbstractOrderedLayout;
import com.vaadin.ui.Alignment;
import com.vaadin.ui.Button;
import com.vaadin.ui.CssLayout;
import com.vaadin.ui.CustomComponent;
import com.vaadin.ui.Layout;
import com.vaadin.ui.ListSelect;
import com.vaadin.ui.Table;
import com.vaadin.ui.VerticalLayout;
import com.vaadin.ui.themes.ValoTheme;

@SuppressWarnings("serial")
public class PatientSearchScreen extends CustomComponent implements View {
	/*
	 * mapping the UI fields with the associated properties of the bean that
	 * will be binded
	 */
	// Style names
	public static final String PATIENTSEARCHTVIEW = "PatientSearchtView";
	public static final String PATIENTSIMPLESTYLE = "PatientSimple";
	public static final String PATIENTSEARCHTVIEWCONTAINER = "Container_PatientSearch";
	public static final String LAYOUTRESULT = "SearchResult";
	// Layouts
	private Layout layoutSearch;
	private Layout layoutPatientSimple;
	private Layout layoutContact;
	private Layout layoutControls;
	private Layout layoutResult;
	private Layout Container;
	// Sub screens
	private PatientSubscreen patientSubscreen;
	private ContactSubscreen contactSubscreen;
	public Table patientList;

	// Actions & Controls
	private Button searchButton;
	// ....
	private PatientSearchListener eventsListener;

	public PatientSearchScreen() {
	}

	// Constructor
	public PatientSearchScreen(BeanItem<Patient_Entity> patientItem, BeanItem<Contact_Entity> contactItem,
			BeanItem<Company_Entity> companyItem, PatientSearchListener listener) {
		this.eventsListener = listener;
		patientSubscreen = new PatientSubscreen(patientItem, listener);
		contactSubscreen = new ContactSubscreen(contactItem, companyItem);

		addLayouts();
		addControls(layoutControls);
	}

	/*
	 * layout size should be undefined to be responsive to the subcomponents
	 * sizes. while each subcomponent can take its size (fixed or
	 * resolution-conditional)
	 * 
	 */
	private void addLayouts() {
		layoutSearch = new VerticalLayout();
		layoutSearch.setStyleName(PATIENTSEARCHTVIEW);
		layoutSearch.setSizeUndefined();
		// Responsive.makeResponsive(layoutSearch);

		layoutPatientSimple = new CssLayout();
		layoutPatientSimple.setStyleName(PATIENTSIMPLESTYLE);
		layoutPatientSimple.setSizeUndefined();
		Responsive.makeResponsive(layoutPatientSimple);

		layoutContact = new CssLayout();
		layoutContact.setSizeUndefined();
		// layoutContact.setStyleName("test");

		layoutControls = new CssLayout();
		layoutControls.setSizeUndefined();

		Container = new CssLayout();
		Container.setStyleName(PATIENTSEARCHTVIEWCONTAINER);
		Container.setSizeUndefined();

		layoutResult = new VerticalLayout();
		layoutResult.setStyleName(LAYOUTRESULT);
		layoutResult.setSizeFull();

		// filling layout
		layoutPatientSimple.addComponent(patientSubscreen);
		layoutContact.addComponents(contactSubscreen);
		Container.addComponents(layoutContact, layoutControls);

		layoutPatientSimple.addComponent(Container);
		layoutSearch.addComponent(layoutPatientSimple);

		layoutSearch.addComponent(layoutResult);

		/// ِ Alignment
		((AbstractOrderedLayout) layoutSearch).setComponentAlignment(layoutPatientSimple, Alignment.TOP_CENTER);
		((AbstractOrderedLayout) layoutSearch).setComponentAlignment(layoutResult, Alignment.BOTTOM_CENTER);

		setCompositionRoot(layoutSearch);
	}

	private void addControls(Layout layout) {
		searchButton = createSearchButton();
		// fill related layout
		layout.addComponent(searchButton);
	}

	private Button createSearchButton() {
		Button search = new Button(getBundleValue(CAPTIONS, SUBMIT));
		search.setStyleName(ValoTheme.BUTTON_PRIMARY);
		search.setClickShortcut(KeyCode.ENTER);
		search.setId(SUBMIT);
		search.setDescription(getBundleValue(MSGS, SUBMIT));
		// assign the listener class that handles events
		search.addClickListener(eventsListener);
		return search;
	}

	private Table createPatientList() {
		Table resultList = new Table();
		layoutResult.removeAllComponents();
		layoutResult.addComponent(resultList);

		return resultList;
	}

	// common screens functions
	public void resetFields() {
		// TODO clear the values of all components
	}

	public Layout getLayoutSearch() {
		return layoutSearch;
	}

	public BeanFieldGroup<Patient_Entity> getFieldGroupPatient() {
		return patientSubscreen.getFieldGroup();
	}

	public BeanFieldGroup<Contact_Entity> getFieldGroupContact() {
		return contactSubscreen.getFieldGroup();
	}

	public BeanFieldGroup<Company_Entity> getFieldGroupCompany() {
		return contactSubscreen.getCompanyfieldGroup();
	}

	public void setResultContainer(Container result) {
		patientList = createPatientList();
		patientList.setContainerDataSource(result);
		patientList.setVisibleColumns(
				new Object[] { "first_name", "second_name", "last_name", "idNumber", "gender", "payment_method" });
		patientList.setColumnHeaders(
				new String[] { "First Name", "Second Name", "Last Name", "National ID Number", "Gender", "Payment" });

		patientList.setSelectable(true);
		// patientList.addValueChangeListener(eventsListener);
		patientList.addItemClickListener(eventsListener);
		patientList.setSizeFull();
		patientList.setPageLength(10);
		patientList.setResponsive(true);
		patientList.setImmediate(true);
		patientList.addGeneratedColumn("Contacts", new Table.ColumnGenerator() {
			public Object generateCell(Table source, final Object itemId, Object columnId) {
				Layout contactLayout = new VerticalLayout();
				contactLayout.setSizeUndefined();
				List<Contact_Entity> cList = ((Patient_Entity) itemId).getContacts();
				if (cList.size() > 0) {
					ListSelect Contacts = new ListSelect("Contacts List");
					Contacts.setNullSelectionAllowed(false);
					Contacts.setSizeUndefined();
					Contacts.setRows(cList.size());
					Contacts.setContainerDataSource(new BeanItemContainer<Contact_Entity>(Contact_Entity.class, cList));
					contactLayout.addComponent(Contacts);

				}

				return contactLayout;
			}
		});
		patientList.addGeneratedColumn("Company", new Table.ColumnGenerator() {
			public Object generateCell(Table source, final Object itemId, Object columnId) {
				Layout companyLayout = new VerticalLayout();
				companyLayout.setSizeUndefined();
				if (((Patient_Entity) itemId).getCompany() != null) {
					List<Company_Entity> companyList = ((Patient_Entity) itemId).getCompany();

					if (companyList.size() > 0) {
						ListSelect company = new ListSelect("Company List");
						company.setNullSelectionAllowed(false);
						company.setSizeUndefined();
						company.setRows(companyList.size());
						company.setContainerDataSource(
								new BeanItemContainer<Company_Entity>(Company_Entity.class, companyList));
						companyLayout.addComponent(company);
					}
				}

				return companyLayout;
			}
		});
		patientList.addGeneratedColumn("Edit", new Table.ColumnGenerator() {
			public Object generateCell(Table source, final Object itemId, Object columnId) {
				Layout editLayout = new VerticalLayout();
				editLayout.setSizeUndefined();
				Button EditButton = new Button("-");
				EditButton.setId(EDIT);
				EditButton.addClickListener(eventsListener);
				editLayout.addComponent(EditButton);
				return editLayout;
			}
		});
	}

	@Override
	public void enter(ViewChangeEvent event) {
		// TODO Auto-generated method stub
	}

	public PatientSubscreen getPatientSubscreen() {
		return patientSubscreen;
	}

	public void setPatientSubscreen(PatientSubscreen patientSubscreen) {
		this.patientSubscreen = patientSubscreen;
	}

	public ContactSubscreen getContactSubscreen() {
		return contactSubscreen;
	}

	public void setContactSubscreen(ContactSubscreen contactSubscreen) {
		this.contactSubscreen = contactSubscreen;
	}

	public Table getPatientList() {
		return patientList;
	}

}
