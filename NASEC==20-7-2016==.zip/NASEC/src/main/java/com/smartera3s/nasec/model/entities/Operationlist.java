package com.smartera3s.nasec.model.entities;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the operationlist database table.
 * 
 */
@Entity
@NamedQuery(name="Operationlist.findAll", query="SELECT o FROM Operationlist o")
public class Operationlist implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int id;
	
	@Column(name="operationList")
	private String operationName;

	public Operationlist() {
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getOperationName() {
		return this.operationName;
	}

	public void setOperationName(String operationName) {
		this.operationName = operationName;
	}
	public String getDisplayName(){
            return operationName;
        }

}