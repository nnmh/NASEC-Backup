package com.smartera3s.nasec.screens.Clinic;

import static com.smartera3s.nasec.controllers.ClinicController.ADDDESCRIPSIONDETAILS;

import static com.smartera3s.nasec.controllers.ClinicController.DATE;
import static com.smartera3s.nasec.controllers.ClinicController.BODYPARTS;
import static com.smartera3s.nasec.controllers.ClinicController.ICD10;
import static com.smartera3s.nasec.controllers.ClinicController.NOTES;
import static com.smartera3s.utils.InternationalizationFileBundle.CAPTIONS;
import static com.smartera3s.utils.InternationalizationFileBundle.MSGS;
import static com.smartera3s.utils.InternationalizationFileBundle.getBundleValue;

import java.util.List;

import com.smartera3s.nasec.listeners.ClinicListener;
import com.smartera3s.nasec.model.entities.BodypartEntity;
import com.smartera3s.nasec.model.entities.ClinicvisitEntity;
import com.smartera3s.nasec.model.entities.Icd10Entity;
import com.smartera3s.nasec.model.entities.PatientsymptomEntity;
import com.smartera3s.nasec.services.ClinicServices;
import com.vaadin.data.fieldgroup.BeanFieldGroup;
import com.vaadin.data.fieldgroup.PropertyId;
import com.vaadin.data.util.BeanItem;
import com.vaadin.data.util.BeanItemContainer;
import com.vaadin.ui.AbstractOrderedLayout;
import com.vaadin.ui.Alignment;
import com.vaadin.ui.Button;
import com.vaadin.ui.CustomComponent;
import com.vaadin.ui.DateField;
import com.vaadin.ui.HorizontalLayout;
import com.vaadin.ui.Layout;
import com.vaadin.ui.ListSelect;
import com.vaadin.ui.TextArea;
import com.vaadin.ui.TextField;
import com.vaadin.ui.VerticalLayout;
import com.vaadin.ui.themes.ValoTheme;

@SuppressWarnings("serial")
public class ClinicDescriptionScreen extends CustomComponent {

	@PropertyId("date")
	private DateField date;

	@PropertyId("notes")
	private TextArea notes;
	
	private Button addDetails;
	
	@PropertyId("ICD10List")
	private ListSelect ICD;
	
	@PropertyId("bodyPartsList")
	private ListSelect Bodyparts;
	
	private ClinicServices services;
	private ClinicListener eventListener;
	
	//Layouts
	private VerticalLayout MainLayout;
	private HorizontalLayout TextFieldLayout;
	private HorizontalLayout ListSelectLayout;
	
	
	//Service Lists
	private List<Icd10Entity> Icd10;
	private List<BodypartEntity> bodyParts;
	
	private BeanItem<PatientsymptomEntity> SymptomsItems;
	
	private BeanFieldGroup<PatientsymptomEntity> symptomfieldGroup;
	
	public ClinicDescriptionScreen(ClinicListener listener) {
		this.eventListener = listener;
		services = new ClinicServices();
		Icd10 = services.findAllcodes();
		bodyParts = services.findAllParts();
		addlayout();
		SymptomsItems = new BeanItem<PatientsymptomEntity>(new PatientsymptomEntity());

		addsymptomFieldGroup(SymptomsItems);
	}

	///Fill Layout Method.
	private void addlayout() {
		MainLayout = new VerticalLayout();
		MainLayout.setSpacing(true);
		MainLayout.setMargin(true);
		MainLayout.setStyleName("ClinicDescriptionView");

		TextFieldLayout = new HorizontalLayout();
		TextFieldLayout.setStyleName("TextFieldLayout");
		TextFieldLayout.setSpacing(true);

		ListSelectLayout = new HorizontalLayout();
		ListSelectLayout.setStyleName("ListSelectLayout");
		setSizeUndefined();
		ListSelectLayout.setSpacing(true);

		fillFields(MainLayout);
		setCompositionRoot(MainLayout);
	}

	///Fill Layout Method.
	private void fillFields(Layout mainLayout) {

		date = createDOB();
		ICD = createICD();
		notes = createNote();
		addDetails = createAddButton();
		Bodyparts = createBodyparts();
		TextFieldLayout.addComponent(date);
		ListSelectLayout.addComponent(ICD);
		ListSelectLayout.addComponent(Bodyparts);

		mainLayout.addComponent(TextFieldLayout);
		((AbstractOrderedLayout) mainLayout).setComponentAlignment(TextFieldLayout, Alignment.TOP_LEFT);
		mainLayout.addComponent(ListSelectLayout);
		((AbstractOrderedLayout) mainLayout).setComponentAlignment(ListSelectLayout, Alignment.MIDDLE_LEFT);
		mainLayout.addComponent(notes);

		mainLayout.addComponent(addDetails);
		((AbstractOrderedLayout) mainLayout).setComponentAlignment(addDetails, Alignment.BOTTOM_LEFT);
		

	}
	private void addsymptomFieldGroup(BeanItem<PatientsymptomEntity> symptomItem) {
	    symptomfieldGroup = new BeanFieldGroup<PatientsymptomEntity>(
	            PatientsymptomEntity.class);
	    symptomfieldGroup.setBuffered(false);// not to depend on commitss
	    symptomfieldGroup.setItemDataSource(symptomItem);
	    symptomfieldGroup.bindMemberFields(this);

	    }

	///Methods Of Creating Fields
	private TextArea createNote() {
		notes = new TextArea();
		notes.setStyleName(ValoTheme.TEXTFIELD_LARGE);
		notes.setCaption(getBundleValue(CAPTIONS, NOTES));
		notes.setId(NOTES);
		notes.setDescription(getBundleValue(MSGS, NOTES));
		notes.setNullRepresentation("");

		return notes;
	}

	private DateField createDOB() {
		date = new DateField();
		date.setStyleName(ValoTheme.DATEFIELD_LARGE);
		date.setCaption(getBundleValue(CAPTIONS, DATE));
		date.setId(DATE);

		return date;
	}

	private ListSelect createICD() {
		ListSelect status = new ListSelect();
		
		status.setId(ICD10);
		status.setMultiSelect(true);
		status.setItemCaptionPropertyId("displayName");
		status.setStyleName(ValoTheme.TEXTFIELD_LARGE);
		status.setCaption(getBundleValue(CAPTIONS, ICD10));
		status.setContainerDataSource(new BeanItemContainer<Icd10Entity>(Icd10Entity.class, Icd10));
		
		return status;
	}

	private ListSelect createBodyparts() {
		ListSelect status = new ListSelect();
		
		status.setId(BODYPARTS);
		status.setMultiSelect(true);
		status.setStyleName(ValoTheme.TEXTFIELD_LARGE);
		status.setItemCaptionPropertyId("displayName");
		status.setCaption(getBundleValue(CAPTIONS, BODYPARTS));
		status.setContainerDataSource(new BeanItemContainer<BodypartEntity>(BodypartEntity.class, bodyParts));
		
		return status;
	}

	private Button createAddButton() {
		addDetails = new Button(getBundleValue(CAPTIONS, ADDDESCRIPSIONDETAILS));
		
		addDetails.setId(ADDDESCRIPSIONDETAILS);
		addDetails.addClickListener(eventListener);
		addDetails.setStyleName(ValoTheme.BUTTON_FRIENDLY);

		return addDetails;
	}

	
	////Setters and getters.
	public DateField getDate() {
		return date;
	}

	public void setDate(DateField date) {
		this.date = date;
	}

	public TextArea getNotes() {
		return notes;
	}

	public void setNotes(TextArea notes) {
		this.notes = notes;
	}

	public ListSelect getICD() {
		return ICD;
	}

	public void setICD(ListSelect iCD) {
		ICD = iCD;
	}

	public ListSelect getBodyparts() {
		return Bodyparts;
	}

	public void setBodyparts(ListSelect bodyparts) {
		Bodyparts = bodyparts;
	}

    public BeanItem<PatientsymptomEntity> getSymptomsItems() {
        return SymptomsItems;
    }

    public void setSymptomsItems(BeanItem<PatientsymptomEntity> symptomsItems) {
        SymptomsItems = symptomsItems;
    }

}
