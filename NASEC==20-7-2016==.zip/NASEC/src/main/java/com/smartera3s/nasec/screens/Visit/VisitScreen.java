package com.smartera3s.nasec.screens.Visit;

import static com.smartera3s.nasec.controllers.VisitController.ADD;
import static com.smartera3s.nasec.controllers.VisitController.LOAD;
import static com.smartera3s.nasec.controllers.VisitController.VISITSEARCH;
import static com.smartera3s.nasec.controllers.VisitController.SAVEREQUEST;
import static com.smartera3s.utils.InternationalizationFileBundle.CAPTIONS;
import static com.smartera3s.utils.InternationalizationFileBundle.getBundleValue;

import java.util.List;

import com.smartera3s.nasec.listeners.VisitScreenListener;
import com.smartera3s.nasec.model.entities.Contact_Entity;
import com.smartera3s.nasec.model.entities.Patient_Entity;
import com.smartera3s.nasec.model.entities.VisitEntity;
import com.smartera3s.nasec.model.entities.VisitType_Entity;
import com.smartera3s.nasec.services.VisitServices;
import com.vaadin.data.fieldgroup.BeanFieldGroup;
import com.vaadin.data.fieldgroup.PropertyId;
import com.vaadin.data.util.BeanItem;
import com.vaadin.data.util.BeanItemContainer;
import com.vaadin.event.ShortcutAction.KeyCode;
import com.vaadin.navigator.View;
import com.vaadin.navigator.ViewChangeListener.ViewChangeEvent;
import com.vaadin.server.Responsive;
import com.vaadin.ui.AbstractOrderedLayout;
import com.vaadin.ui.Button;
import com.vaadin.ui.Component;
import com.vaadin.ui.CustomComponent;
import com.vaadin.ui.HorizontalLayout;
import com.vaadin.ui.Label;
import com.vaadin.ui.Layout;
import com.vaadin.ui.VerticalLayout;
import com.vaadin.ui.themes.ValoTheme;

@SuppressWarnings("serial")
public class VisitScreen extends CustomComponent implements View {

	public static final String VISITSCREENSTYLE = "VisitView";
	
	private Button AddPatient;
	private Button LoadPatient;
	private Button VisitSearch;
	private Button SaveRequest;

	private CustomComponent currentView;

	// Labels
	@PropertyId("title")
	private Label title;

	// Layouts
	private Layout layout;
	private Layout topLayout;
	private Layout layoutFields;
	private Layout windowLayout;
	private Layout windowLayout2;
	private Layout windowLayout3;
	private Layout layoutControls;
	private Layout layoutMainVisit;

	
	private VisitServices Service;
	private VisitScreenListener eventsListener;

	
	//View
	private VisitServiceSubScreen VisitService;
	private VisitSearch Visitsearch;

	public VisitScreen(BeanItem<Patient_Entity> PatientItem,BeanItem<VisitEntity> VisitItem,BeanItem<VisitEntity> VisitSearchItem, VisitScreenListener listener) {

		Service = new VisitServices();
		this.eventsListener = listener;

		VisitService = new VisitServiceSubScreen(VisitItem, listener);
		 Visitsearch = new VisitSearch(PatientItem,VisitSearchItem,listener);
		
		addLayouts();
		fillLayout(layoutFields);
		addControls(layoutControls);
	}

	private void addLayouts() {
		SaveRequest = createVisitButton();

		layoutMainVisit = new VerticalLayout();
		layoutMainVisit.setSizeFull();
		layoutMainVisit.setStyleName(VISITSCREENSTYLE);

		Responsive.makeResponsive(layoutMainVisit);

		layoutFields = new VerticalLayout();
		//layoutFields.setSizeFull();
		layoutFields.setStyleName("visit-container");

		windowLayout = new VerticalLayout();
		windowLayout.setSizeUndefined();

		windowLayout2 = new VerticalLayout();
		windowLayout2.setSizeUndefined();
		
		windowLayout3 = new VerticalLayout();
                windowLayout3.setSizeUndefined();

		layoutControls = new HorizontalLayout();
		layoutControls.setSizeUndefined();
//		((AbstractOrderedLayout) layoutControls).setSpacing(true);
		layoutControls.addStyleName("visit-toolbar");

		layout = new VerticalLayout();
		layout.setSizeUndefined();

		topLayout = new HorizontalLayout();
		topLayout.setSizeUndefined();

		layoutMainVisit.addComponent(buildHeader());
		layoutMainVisit.addComponent(layoutFields);
		Responsive.makeResponsive(layoutMainVisit);
		setCompositionRoot(layoutMainVisit);
	}

	private void fillLayout(Layout fields) {
		fields.addComponent(VisitService);
		fields.addComponent(SaveRequest);
		((AbstractOrderedLayout) fields).setSpacing(true);
	}

	private Component buildHeader() {
		HorizontalLayout header = new HorizontalLayout();
		header.addStyleName("Visit-header");
		header.setSpacing(true);
		
		/// This is the Layout That have the Buttons
		header.addComponent(layoutControls);
		return header;
	}

	private void addControls(Layout layout) {
		LoadPatient = createLoadButton();
		AddPatient  = createAddButton();
		VisitSearch = createVisitSearch();
		// fill related layout
		layout.addComponent(LoadPatient);
		layout.addComponent(AddPatient);
		layout.addComponent(VisitSearch);
	}

	private Button createVisitSearch()
	{
		VisitSearch = new Button();
		VisitSearch = new Button(getBundleValue(CAPTIONS, VISITSEARCH));
		VisitSearch.setStyleName(ValoTheme.BUTTON_PRIMARY);
		VisitSearch.setClickShortcut(KeyCode.ENTER);
		VisitSearch.setId(VISITSEARCH);

		// assign the listener class that handles events
		VisitSearch.addClickListener(eventsListener);
		return VisitSearch;
	}
	private Button createLoadButton() {
		LoadPatient = new Button(getBundleValue(CAPTIONS, LOAD));
		LoadPatient.setStyleName(ValoTheme.BUTTON_PRIMARY);
		LoadPatient.setClickShortcut(KeyCode.ENTER);
		LoadPatient.setId(LOAD);

		// assign the listener class that handles events
		LoadPatient.addClickListener(eventsListener);
		return LoadPatient;
	}

	private Button createVisitButton() {
		SaveRequest = new Button(getBundleValue(CAPTIONS, SAVEREQUEST));
		SaveRequest.setStyleName(ValoTheme.BUTTON_PRIMARY);
		SaveRequest.setClickShortcut(KeyCode.ENTER);
		SaveRequest.setId(SAVEREQUEST);

		// assign the listener class that handles events
		SaveRequest.addClickListener(eventsListener);
		return SaveRequest;
	}

	private Button createAddButton() {
		AddPatient = new Button(getBundleValue(CAPTIONS, ADD));
		AddPatient.setStyleName(ValoTheme.BUTTON_PRIMARY);
		AddPatient.setClickShortcut(KeyCode.ENTER);
		AddPatient.setId(ADD);

		// assign the listener class that handles events
		AddPatient.addClickListener(eventsListener);
		return AddPatient;
	}

	private Label createTitle() {
		title = new Label("Visit Request");
		//title.setStyleName();
		title.setSizeUndefined();
		title.addStyleName(ValoTheme.LABEL_NO_MARGIN);
		return title;
	}

	public Label getTitle() {
		return title;
	}

	public void setTitle(Label title) {
		this.title = title;
	}

	public Layout getWindowLayout() {
		return windowLayout;
	}

	public VisitServiceSubScreen getVisitService() {
		return VisitService;
	}

	public Layout getWindowLayout2() {
		return windowLayout2;
	}

	/*
	 * public VisitRequestSubScreen getVisitRequest() { return VisitRequest; }
	 * public void setVisitRequest(VisitRequestSubScreen visitRequest) {
	 * VisitRequest = visitRequest; }
	 */
	public void setCurrentView(CustomComponent view) {
		this.currentView = view;
		setCompositionRoot(currentView);

	}

	public void setWindowLayout(Layout windowLayout) {
		this.windowLayout = windowLayout;
	}

	public void setWindowLayout2(Layout windowLayout2) {
		this.windowLayout2 = windowLayout2;
	}

	public BeanFieldGroup<VisitEntity> getFieldGroup() {
		return VisitService.getVisitfieldGroup();
	}
	public BeanFieldGroup<Patient_Entity> getFieldGroupPatient() {
            return Visitsearch.getFieldPatientGroup();
        }
	public BeanFieldGroup<VisitEntity> getFieldGroupVisit() {
            return Visitsearch.getFieldVisitGroup();
	}
	@Override
	public void enter(ViewChangeEvent event) {
		// TODO Auto-generated method stub

	}

    public VisitSearch getVisitsearch() {
        return Visitsearch;
    }

    public void setVisitsearch(VisitSearch visitsearch) {
        Visitsearch = visitsearch;
    }

    public Layout getWindowLayout3() {
        return windowLayout3;
    }

    public void setWindowLayout3(Layout windowLayout3) {
        this.windowLayout3 = windowLayout3;
    }
}
