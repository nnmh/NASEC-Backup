package com.smartera3s.nasec.screens.templateLayouts;

import static com.smartera3s.nasec.controllers.LoginController.*;

import com.smartera3s.nasec.listeners.LoginListener;
import com.smartera3s.nasec.model.entities.UserEntity;
import com.smartera3s.utils.InternationalizationFileBundle;
import com.vaadin.data.fieldgroup.BeanFieldGroup;
import com.vaadin.data.fieldgroup.FieldGroup;
import com.vaadin.data.fieldgroup.PropertyId;
import com.vaadin.data.util.BeanItem;
import com.vaadin.event.ShortcutAction.KeyCode;
import com.vaadin.ui.AbstractOrderedLayout;
import com.vaadin.ui.Button;
import com.vaadin.ui.CssLayout;
import com.vaadin.ui.CustomComponent;
import com.vaadin.ui.HorizontalLayout;
import com.vaadin.ui.Label;
import com.vaadin.ui.Layout;
import com.vaadin.ui.PasswordField;
import com.vaadin.ui.TextField;
import com.vaadin.ui.VerticalLayout;
import com.vaadin.ui.themes.ValoTheme;
import static com.smartera3s.utils.InternationalizationFileBundle.*;

public class HomeScreen extends CustomComponent{
	// Layouts
	private Layout homeLayout; // biggest layout
	private Layout header;
	private Layout menue;
	private Layout body;
	private Layout footer;

	// Constructor
	public HomeScreen() {
		addLayouts();
	}

	/*
	 * layout size should be undefined to be responsive to the subcomponents
	 * sizes. while each subcomponent can take its size (fixed or
	 * resolution-conditional)
	 * 
	 */
	private void addLayouts() {
		homeLayout = new VerticalLayout();
		homeLayout.setSizeUndefined();
		
		header = new HorizontalLayout();
		header.setSizeUndefined(); 	header.addComponent(new Label("Header"));
		
		HorizontalLayout menueAndBody = new HorizontalLayout();
		menueAndBody.setSizeUndefined();
		menue = new VerticalLayout();
		menue.setSizeUndefined();	menue.addComponent(new Label("menue"));
		body = new CssLayout();
		body.setSizeUndefined(); 	body.addComponent(new Label("body"));
		menueAndBody.addComponents(menue,body);
		
		footer = new HorizontalLayout();
		footer.setSizeUndefined(); 	footer.addComponent(new Label("footer"));
		
		setCompositionRoot(homeLayout);
		homeLayout.addComponents(header,menueAndBody,footer);
	}

	public Layout getHomeLayout() {
		return homeLayout;
	}

	public Layout getHeader() {
		return header;
	}

	public Layout getMenue() {
		return menue;
	}

	public Layout getBody() {
		return body;
	}

	public Layout getFooter() {
		return footer;
	}

	
}
