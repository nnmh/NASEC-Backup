package com.smartera3s.nasec.model.entities;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the `concept attribute` database table.
 * 
 */
@Entity
@Table(name="`concept attribute`")
@NamedQuery(name="Concept_attribute.findAll", query="SELECT c FROM Concept_attribute c")
public class Concept_attribute implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int id;

	private String medical_id;

	private String name;

	public Concept_attribute() {
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getMedical_id() {
		return this.medical_id;
	}

	public void setMedical_id(String medical_id) {
		this.medical_id = medical_id;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

}