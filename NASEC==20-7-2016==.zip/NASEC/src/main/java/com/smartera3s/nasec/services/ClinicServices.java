package com.smartera3s.nasec.services;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

import com.google.gwt.resources.css.InterfaceGenerator;
import com.smartera3s.nasec.model.entities.BodypartEntity;
import com.smartera3s.nasec.model.entities.Categories_listEntity;
import com.smartera3s.nasec.model.entities.ClinicvisitEntity;
import com.smartera3s.nasec.model.entities.ColumnEntity;
import com.smartera3s.nasec.model.entities.Columnsdata;
import com.smartera3s.nasec.model.entities.Concept_attribute;
import com.smartera3s.nasec.model.entities.FormEntity;
import com.smartera3s.nasec.model.entities.Icd10Entity;
import com.smartera3s.nasec.model.entities.Medical_concept;
import com.smartera3s.nasec.model.entities.PatientsymptomEntity;
import com.smartera3s.nasec.model.entities.RowEntity;
import com.smartera3s.nasec.model.entities.Scattered_fieldEntity;
import com.smartera3s.nasec.model.entities.Scattered_fields_dataEntity;
import com.smartera3s.nasec.model.entities.Symeptoms_badypartEntity;
import com.smartera3s.nasec.model.entities.VisitEntity;
import com.vaadin.addon.jpacontainer.JPAContainer;
import com.vaadin.addon.jpacontainer.JPAContainerFactory;
import com.vaadin.data.util.BeanItem;

public class ClinicServices {
    //Database Linking
    protected EntityManagerFactory emf = Persistence.createEntityManagerFactory("NASEC");
    protected EntityManager EntityManager = emf.createEntityManager();

    // ICD10 Code To Fill List
    @SuppressWarnings("unchecked")
    public List<Icd10Entity> findAllcodes() {

        Query query = EntityManager.createQuery("SELECT i FROM Icd10Entity i");
        return (List<Icd10Entity>) query.getResultList();
    }

    // Body Parts To Fill List
    @SuppressWarnings("unchecked")
    public List<BodypartEntity> findAllParts() {

        Query query = EntityManager
                .createQuery("SELECT b FROM BodypartEntity b");
        return (List<BodypartEntity>) query.getResultList();
    }

    // Get Buttons Categories List
    public List<Categories_listEntity> findAllCategories() {
        Query query = EntityManager
                .createQuery("SELECT c FROM Categories_listEntity c");
        return (List<Categories_listEntity>) query.getResultList();
    }

    // Get Clinic By Visit ID
    @SuppressWarnings("unchecked")
    public List<ClinicvisitEntity> findClinicVisitsbyVisitID(String visitid) {

        Query query = EntityManager
                .createQuery(
                        "SELECT c FROM ClinicvisitEntity c WHERE c.visitID =:vID")
                .setParameter("vID", visitid);
        return (List<ClinicvisitEntity>) query.getResultList();
    }

    // Get Clinic By Patient ID
    @SuppressWarnings("unchecked")
    public List<ClinicvisitEntity> findClinicVisitsbyPatientID(
            String patientid) {

        Query query = EntityManager
                .createQuery(
                        "SELECT c FROM ClinicvisitEntity c WHERE c.patient_id =:pID")
                .setParameter("pID", patientid);
        return (List<ClinicvisitEntity>) query.getResultList();
    }

    // Get Patient Symptoms By Patient ID
    @SuppressWarnings("unchecked")
    public List<PatientsymptomEntity> findPatientsymptomPatientID(
            String patientid) {

        Query query = EntityManager
                .createQuery(
                        "SELECT p FROM PatientsymptomEntity p WHERE p.patient_id =:pID")
                .setParameter("pID", patientid);
        return (List<PatientsymptomEntity>) query.getResultList();
    }

    // Get Patient Symptoms By Clinic ID
    @SuppressWarnings("unchecked")
    public List<PatientsymptomEntity> findPatientsymptomClinicID(
            String clinicid) {

        Query query = EntityManager
                .createQuery(
                        "SELECT p FROM PatientsymptomEntity p WHERE p.clinicId =:cID")
                .setParameter("cID", clinicid);
        return (List<PatientsymptomEntity>) query.getResultList();
    }

    // Get ICD10 By ID
    @SuppressWarnings("unchecked")
    public List<Icd10Entity> findICD10ID(int id) {

        Query query = EntityManager
                .createQuery("SELECT i FROM Icd10Entity i WHERE i.id =:ID")
                .setParameter("ID", id);
        return (List<Icd10Entity>) query.getResultList();
    }

    // Get Patient Symptoms By ID
    @SuppressWarnings("unchecked")
    public List<BodypartEntity> findBodyPartID(int id) {

        Query query = EntityManager
                .createQuery("SELECT b FROM BodypartEntity b WHERE b.id =:ID")
                .setParameter("ID", id);
        return (List<BodypartEntity>) query.getResultList();
    }
    // Get Patient Symptoms Body Parts By Patient SymptomsID
    @SuppressWarnings("unchecked")
    public List<Symeptoms_badypartEntity> findSymeptomsBodyPartID(String id) {

        Query query = EntityManager
                .createQuery("SELECT s FROM Symeptoms_badypartEntity s WHERE s.patientSymptomsID =:ID")
                .setParameter("ID", id);
        return (List<Symeptoms_badypartEntity>) query.getResultList();
    }

    // ================================================Find Clinic Visit
    // ===================================//
    public List<ClinicvisitEntity> findClinic(String Vid, String Pid) {

        Query query = EntityManager
                .createQuery(
                        "SELECT c FROM ClinicvisitEntity c WHERE c.patient_id =:PID AND c.visitID=:VID")
                .setParameter("PID", Pid).setParameter("VID", Vid);
        return (List<ClinicvisitEntity>) query.getResultList();
    }

    // ==========================================================Fill of
    // Forms========================================//
    // Get Form id By name
    public List<FormEntity> findAllforms(String name) {
        Query query = EntityManager
                .createQuery("SELECT f FROM FormEntity f WHERE f.name = :name")
                .setParameter("name", name);
        return (List<FormEntity>) query.getResultList();
    }

    // Get Rows By form id
    public List<RowEntity> findAllrows(String id) {
        Query query = EntityManager
                .createQuery("SELECT r FROM RowEntity r WHERE r.formId = :id")
                .setParameter("id", id);
        return (List<RowEntity>) query.getResultList();
    }

    // Get Columns By form id & Row Id
    public List<ColumnEntity> findAllcolumns(String formid, String rowid) {
        Query query = EntityManager
                .createQuery(
                        "SELECT c FROM ColumnEntity c WHERE c.formId = :formid AND c.rowid = :rowid")
                .setParameter("formid", formid).setParameter("rowid", rowid);
        return (List<ColumnEntity>) query.getResultList();
    }

    // Get Scattered Fields By form id
    public List<Scattered_fieldEntity> findAllScattered(String formid) {
        Query query = EntityManager
                .createQuery(
                        "SELECT s FROM Scattered_fieldEntity s WHERE s.formId = :formid")
                .setParameter("formid", formid);
        return (List<Scattered_fieldEntity>) query.getResultList();
    }
    // ==========================================================Fill of
    // Forms========================================//

    public ClinicvisitEntity createClinic(
            BeanItem<ClinicvisitEntity> clinicItem) {
        JPAContainer<ClinicvisitEntity> ClinicContainer = JPAContainerFactory
                .make(ClinicvisitEntity.class, "NASEC");

        ClinicvisitEntity Clinic = new ClinicvisitEntity();
        Object ClinicItem = ClinicContainer.addEntity(clinicItem.getBean());

        Clinic = ClinicContainer.getItem(ClinicItem).getEntity();
        System.out.println(Clinic.getId() + "=========");
        System.out.println("Clinic Done");

        return Clinic;

    }

    public PatientsymptomEntity createSymptoms(
            BeanItem<PatientsymptomEntity> symptomsItem,
            ClinicvisitEntity clinic) {
        JPAContainer<PatientsymptomEntity> symptomsContainer = JPAContainerFactory
                .make(PatientsymptomEntity.class, "NASEC");
        symptomsItem.getBean().setClinicId(String.valueOf(clinic.getId()));
        symptomsItem.getBean().setPatient_id(clinic.getPatient_id());

        Object symptoms = symptomsContainer.addEntity(symptomsItem.getBean());

        PatientsymptomEntity patientsymptoms = new PatientsymptomEntity();
        patientsymptoms = symptomsContainer.getItem(symptoms).getEntity();

        System.out.println(patientsymptoms.getId() + "=========");
        System.out.println("patient Symptoms Done");

        return patientsymptoms;

    }

    public Symeptoms_badypartEntity createBodyParts(
            BeanItem<Symeptoms_badypartEntity> BodyItem) {
        JPAContainer<Symeptoms_badypartEntity> symptomsContainer = JPAContainerFactory
                .make(Symeptoms_badypartEntity.class, "NASEC");

        Object symptoms = symptomsContainer.addEntity(BodyItem.getBean());

        Symeptoms_badypartEntity patientsymptoms = new Symeptoms_badypartEntity();
        patientsymptoms = symptomsContainer.getItem(symptoms).getEntity();

        System.out.println(patientsymptoms.getId() + "=========");
        System.out.println("Body Symptoms Done");

        return patientsymptoms;

    }

    public Columnsdata createPopup(BeanItem<Columnsdata> dataItem,
            BeanItem<ClinicvisitEntity> clinicItem) {
        JPAContainer<Columnsdata> cloumnsDataContainer = JPAContainerFactory
                .make(Columnsdata.class, "NASEC");

        Object cloumnsDataObject = cloumnsDataContainer
                .addEntity(dataItem.getBean());

        Columnsdata cloumnsData = new Columnsdata();
        cloumnsData = cloumnsDataContainer.getItem(cloumnsDataObject)
                .getEntity();

        return cloumnsData;
    }

    public Scattered_fields_dataEntity createScattered(
            BeanItem<Scattered_fields_dataEntity> dataItem,
            BeanItem<ClinicvisitEntity> clinicItem) {
        JPAContainer<Scattered_fields_dataEntity> scatteredDataContainer = JPAContainerFactory
                .make(Scattered_fields_dataEntity.class, "NASEC");

        Object scatteredDataObject = scatteredDataContainer
                .addEntity(dataItem.getBean());

        Scattered_fields_dataEntity scatteredData = new Scattered_fields_dataEntity();
        scatteredData = scatteredDataContainer.getItem(scatteredDataObject)
                .getEntity();

        return scatteredData;
    }

    // ======================================Medical Concept=============================//
    public List<Medical_concept> findAllMedical() {
        Query query = EntityManager
                .createQuery("SELECT m FROM Medical_concept m");
        return (List<Medical_concept>) query.getResultList();
    }

    public List<Concept_attribute> findAllAttribute(String medicalId) {
        Query query = EntityManager
                .createQuery(
                        "SELECT c FROM Concept_attribute c WHERE c.medical_id = :medicalId")
                .setParameter("medicalId", medicalId);
        return (List<Concept_attribute>) query.getResultList();
    }
    //===========================Update==============================================//
    public List<ClinicvisitEntity> findClinic(int id){
         Query query = EntityManager
                .createQuery(
                        "SELECT c FROM ClinicvisitEntity c WHERE c.id = :id")
                .setParameter("id", id);
        return (List<ClinicvisitEntity>) query.getResultList();
    }
}
