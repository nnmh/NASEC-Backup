package com.smartera3s.nasec.services;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

import com.smartera3s.nasec.model.entities.Company_Entity;
import com.smartera3s.nasec.model.entities.ContactTypeEntity;
import com.smartera3s.nasec.model.entities.Contact_Entity;
import com.smartera3s.nasec.model.entities.Device;
import com.smartera3s.nasec.model.entities.Operationlist;
import com.smartera3s.nasec.model.entities.Patient_Entity;
import com.smartera3s.nasec.model.entities.Payment_Entity;
import com.smartera3s.nasec.model.entities.Staff_Entity;
import com.smartera3s.nasec.model.entities.VisitType_Entity;
import com.smartera3s.nasec.model.entities.VisitEntity;
import com.vaadin.addon.jpacontainer.JPAContainer;
import com.vaadin.addon.jpacontainer.JPAContainerFactory;
import com.vaadin.data.util.BeanItem;
import com.vaadin.data.util.BeanItemContainer;



public class VisitServices {
    
    private  BeanItemContainer<VisitEntity> PatientBean;
    
    private HashMap <String,Object>  ParamHash;            // Query Parameter Container
    private Map.Entry MappingEntry;                       // Mapper For HashMap Elements
    
    private Query query;
    private Query visitQuery;//Query Function
    private Query visitTypeQuery;//Query Function
    
    //Database Linking
    protected EntityManagerFactory emf = Persistence.createEntityManagerFactory("NASEC");
    protected EntityManager EntityManager = emf.createEntityManager();

    @SuppressWarnings("unchecked")
    public List<VisitType_Entity> findAlltype() {
        
        Query query = EntityManager.createQuery("SELECT v FROM VisitType_Entity v");
        return (List<VisitType_Entity>) query.getResultList();
      }
    public List<VisitType_Entity> findAlltype(int id) {
        
        Query query = EntityManager.createQuery("SELECT v FROM VisitType_Entity v WHERE v.id=:id").setParameter("id", id);
        return (List<VisitType_Entity>) query.getResultList();
      }
    @SuppressWarnings("unchecked")
    public List<Staff_Entity> findName(int id) {
        
        Query query = EntityManager.createQuery("SELECT s FROM Staff_Entity s WHERE s.roleID =:ID").setParameter("ID", id);
        return (List<Staff_Entity>) query.getResultList();
      }
    public List<Device> findAllDevices() {
        
        Query query = EntityManager.createQuery("SELECT d FROM Device d");
        return (List<Device>) query.getResultList();
    }
    public List<Operationlist> findAllOperationList() {
        
        Query query = EntityManager.createQuery("SELECT o FROM Operationlist o");
        return (List<Operationlist>) query.getResultList();
      }
    public List<Payment_Entity> findAllPayment() {
        
        Query query = EntityManager.createQuery("SELECT p FROM Payment_Entity p");
        return (List<Payment_Entity>) query.getResultList();
      }
    
    public VisitEntity createVisit(BeanItem<VisitEntity> visitItem){
        JPAContainer<VisitEntity> VisitContainer =  JPAContainerFactory.make(VisitEntity.class, "NASEC");
        
        Object  VisitItem= VisitContainer.addEntity(visitItem.getBean());
        VisitEntity Visit = new VisitEntity();
        
        Visit=VisitContainer.getItem(VisitItem).getEntity();
        System.out.println(Visit.getId()+"=========");
        System.out.println("Visit Done");
        
        return Visit;
        
    }
    ///=================================Visit Search Services======================================///
    public BeanItemContainer<VisitEntity> search(Patient_Entity patient , VisitEntity visit){
        
        List<VisitEntity> result=findVisit(patient,visit);
       
        PatientBean = new BeanItemContainer<VisitEntity> (VisitEntity.class,result);
        return PatientBean;
}
    
    
    @SuppressWarnings("unchecked")
    public List<VisitEntity> findVisit(Patient_Entity patient, VisitEntity visit) {
        List<VisitEntity> finalResult = new ArrayList<VisitEntity>();
        String where = "";
        String SELECT = "SELECT p ";
        String FROM= " FROM Patient_Entity p ";
        boolean VisitFlag=false;
        ParamHash = new HashMap <String,Object> ();
        
        if (patient.getFullName() != null && !patient.getFullName().equals("")) {
            where += ((where == "") ? " " :" AND ")
                  +  "CONCAT(p.first_name,' ',p.second_name,' ',p.last_name) LIKE :fullname"; 
            ParamHash.put("fullname", ('%' +patient.getFullName().trim()+ '%'));         
         }
        if (patient.getId() != null && !patient.getId().equals("")) {
            where += ((where == "") ? " " :" AND ")
                  +  "p.id = :id"; 
            ParamHash.put("id", patient.getId());         
         }
        if (patient.getIdNumber() != null && !patient.getIdNumber().equals("")) {
            where += ((where == "") ? " " :" AND ")
                  +  "p.idNumber =:idNumber"; 
            ParamHash.put("idNumber", patient.getIdNumber());         
         }
        if (visit.getLinkedVisitType().getType() != null && visit.getLinkedVisitType().getId()!=0) {
            where += ((where == "") ? " " :" AND ") +  "v.visitTypeID = :Type AND p.id=v.patientID";
            FROM += ", VisitEntity v "; 
            SELECT+= " ,v ";
            VisitFlag=true;
            ParamHash.put("Type", visit.getVisitTypeID());
         }
        if (visit.getFromDate() != null && !visit.getFromDate() .equals("")) {
            where += ((where == "") ? " " :" AND ") +  "v2.vistsDateTime >= :fromdate AND v2.vistsDateTime <= :todate AND p.id=v2.patientID";
            FROM += ", VisitEntity v2 "; 
            SELECT+= " ,v2 ";
            VisitFlag=true;
            ParamHash.put("fromdate", visit.getFromDate());
            ParamHash.put("todate", visit.getToDate());
         }
        
        SELECT+=   FROM+(where.equals("")? " ":(" WHERE " +where));
        query = EntityManager
                .createQuery(SELECT);
        Set set = ParamHash.entrySet();
        // Get an iterator
        Iterator i = set.iterator();
        // Display elements
        while(i.hasNext()) {
             MappingEntry = (Map.Entry)i.next();
             query.setParameter(MappingEntry.getKey().toString(),MappingEntry.getValue());
        }
         List result = query.getResultList();
         if(VisitFlag==false)
         {
             for(int j=0;j<result.size();j++){
                 Patient_Entity tempP=null;
                 if (result.get(j) instanceof Patient_Entity){
                     tempP = (Patient_Entity) result.get(j);
                 }
                 visitQuery = EntityManager
                     .createQuery("SELECT v FROM VisitEntity v WHERE v.patientID=:id").setParameter("id", String.valueOf(tempP.getId()));
                 List<VisitEntity> result2 = (List<VisitEntity>) visitQuery.getResultList();
                 for(int k=0;k<result2.size();k++){
                     VisitEntity tempV=(VisitEntity) result2.get(k);
                     
                     visitTypeQuery = EntityManager
                     .createQuery("SELECT v FROM VisitType_Entity v WHERE v.id=:id").setParameter("id", tempV.getVisitTypeID());
                     List<VisitType_Entity> result3 = (List<VisitType_Entity>) visitTypeQuery.getResultList();
                     for(int h=0;h<result3.size();h++){
                         VisitType_Entity tempT= result3.get(h);
                         
                     tempV.setLinkedVisitType(tempT);    
                     tempV.setPatient(tempP);
                     finalResult.add(tempV);
                 }
                 }                  
             }
         }
         if(VisitFlag == true) {
             
             for(int j=0;j<result.size();j++){
                 Patient_Entity tempP = (Patient_Entity)(((Object[])result.get(j))[0]);
                 VisitEntity tempV = null;
                 Object secondItem = (((Object[])result.get(j))[1]);
                 if(secondItem instanceof VisitEntity){
                     tempV= (VisitEntity) secondItem;
                 }
                 visitTypeQuery = EntityManager
                 .createQuery("SELECT v FROM VisitType_Entity v WHERE v.id=:id").setParameter("id", tempV.getVisitTypeID());
                 List<VisitType_Entity> result3 = (List<VisitType_Entity>) visitTypeQuery.getResultList();
                 for(int h=0;h<result3.size();h++){
                     VisitType_Entity tempT=null;
                     if (result3.get(h) instanceof VisitType_Entity){
                         tempT = (VisitType_Entity) result3.get(h);
                     }
                     tempV.setLinkedVisitType(tempT);    
                     tempV.setPatient(tempP);
                     finalResult.add(tempV);
                 }
             }
         }
        return finalResult;
    
}
    }