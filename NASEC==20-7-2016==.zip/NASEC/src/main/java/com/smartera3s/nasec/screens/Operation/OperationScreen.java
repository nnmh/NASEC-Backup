package com.smartera3s.nasec.screens.Operation;

import com.smartera3s.nasec.listeners.OperationListener;
import com.vaadin.navigator.View;
import com.vaadin.navigator.ViewChangeListener.ViewChangeEvent;
import com.vaadin.server.FontAwesome;
import com.vaadin.shared.ui.label.ContentMode;
import com.vaadin.ui.Alignment;
import com.vaadin.ui.CustomComponent;
import com.vaadin.ui.CustomLayout;
import com.vaadin.ui.Label;
import com.vaadin.ui.VerticalLayout;

@SuppressWarnings("serial")
public class OperationScreen extends CustomComponent implements View {

	public static final String VIEW_NAME = "Operation Services";
	private OperationListener eventListener;
	public OperationScreen(OperationListener listener) {
	    this.eventListener = listener;
		setStyleName("OperationView");
		CustomLayout aboutContent = new CustomLayout("aboutview");
		aboutContent
				.addComponent(new Label(FontAwesome.INFO_CIRCLE.getHtml() + " Operation Services is under construction",
						ContentMode.HTML), "info");

		aboutContent.setStyleName("about-content");
		setSizeFull();
	              VerticalLayout vLayout = new VerticalLayout();
	                vLayout.addComponent(aboutContent);
	                vLayout.setComponentAlignment(aboutContent, Alignment.MIDDLE_CENTER);
	                setCompositionRoot(vLayout);
	}

	@Override
	public void enter(ViewChangeEvent event) {
	}

}
