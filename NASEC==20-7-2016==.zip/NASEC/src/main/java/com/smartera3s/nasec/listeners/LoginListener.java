package com.smartera3s.nasec.listeners;

import static com.smartera3s.nasec.controllers.LoginController.*;

import com.smartera3s.nasec.controllers.LoginController;
import com.smartera3s.utils.InternationalizationFileBundle;
import com.vaadin.ui.Button.ClickEvent;
import com.vaadin.ui.Button.ClickListener;

public class LoginListener implements ClickListener {
	
	private LoginController loginController;
	
	public LoginListener(LoginController controller){
		this.loginController=controller;
	}
	
	@Override
	public void buttonClick(ClickEvent event) {
		if(event.getButton().getId().equals(SUBMIT)){
			loginController.login();
		}

	}

}
