package com.smartera3s.nasec.model.entities;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the columns database table.
 * 
 */
@Entity
@Table(name="columns")
@NamedQuery(name="ColumnEntity.findAll", query="SELECT c FROM ColumnEntity c")
public class ColumnEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int columnId;

	private String formId;

	private String name;

	private String rowid;

	private String type;
	@Transient
	private String RowName;
	
	public ColumnEntity() {
	}

	public int getColumnId() {
		return this.columnId;
	}

	public void setColumnId(int columnId) {
		this.columnId = columnId;
	}

	public String getFormId() {
		return this.formId;
	}

	public void setFormId(String formId) {
		this.formId = formId;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getRowid() {
		return this.rowid;
	}

	public void setRowid(String rowid) {
		this.rowid = rowid;
	}

	public String getType() {
		return this.type;
	}

	public void setType(String type) {
		this.type = type;
	}

    public String getRowName() {
        return RowName;
    }

    public void setRowName(String rowName) {
        RowName = rowName;
    }

}