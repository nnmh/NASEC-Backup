package com.smartera3s.nasec.screens.reg;

import static com.smartera3s.nasec.controllers.RegisterationController.IDNUMBER;
import static com.smartera3s.nasec.controllers.RegisterationController.IDTYPE;
import static com.smartera3s.nasec.controllers.RegisterationController.MARTIAL_STATUS;
import static com.smartera3s.nasec.controllers.RegisterationController.NATIONALITY;
import static com.smartera3s.utils.InternationalizationFileBundle.CAPTIONS;
import static com.smartera3s.utils.InternationalizationFileBundle.MSGS;
import static com.smartera3s.utils.InternationalizationFileBundle.getBundleValue;

import java.util.List;

import com.smartera3s.nasec.model.entities.CountryEntity;
import com.smartera3s.nasec.model.entities.MstatusEntity;
import com.smartera3s.nasec.model.entities.Patient_Entity;
import com.smartera3s.nasec.model.entities.Patientidtype;
import com.smartera3s.nasec.services.RegisterationService;
import com.vaadin.data.fieldgroup.BeanFieldGroup;
import com.vaadin.data.fieldgroup.PropertyId;
import com.vaadin.data.util.BeanItem;
import com.vaadin.data.util.BeanItemContainer;
import com.vaadin.ui.AbstractOrderedLayout;
import com.vaadin.ui.ComboBox;
import com.vaadin.ui.CssLayout;
import com.vaadin.ui.HorizontalLayout;
import com.vaadin.ui.Label;
import com.vaadin.ui.Layout;
import com.vaadin.ui.TextField;
import com.vaadin.ui.VerticalLayout;
import com.vaadin.ui.themes.ValoTheme;

public class RegisterationBasicSubScreen extends CssLayout {

	// Labels
	@PropertyId("basictitle")
	private Label basictitle;

	// TextFields
	@PropertyId("idNumber")
	private TextField idNumber;

	// combobox
	@PropertyId("linkedIDType")
	private ComboBox idType;
	@PropertyId("nationality")
	private ComboBox nationality;
	@PropertyId("martial_status")
	private ComboBox status;

	// Layouts
	private Layout layoutBasicTab;
	private Layout layoutBasicTabInputs1;
	private Layout layoutBasicTabInputs2;

	/// Ahmed add it
	private Layout layoutmainFields;

	private RegisterationService Service;

	private List<CountryEntity> countryList;
	private List<MstatusEntity> MstatusList;
	private List<Patientidtype> IDTypesList;

	private BeanFieldGroup<Patient_Entity> PatientfieldGroup;

	public RegisterationBasicSubScreen(BeanItem<Patient_Entity> patientItem) {

		Service = new RegisterationService();
		countryList = Service.findAllCountries();
		MstatusList = Service.findAllStatus();
		IDTypesList = Service.findAllIDTypes();

		addLayouts();
		addPatientFieldGroup(patientItem);
	}

	private void addLayouts() {

		layoutmainFields = new VerticalLayout();
		layoutmainFields.setSizeUndefined();
		layoutmainFields.setStyleName("SubScreen-style");

		layoutBasicTab = new HorizontalLayout();
		layoutBasicTab.setSizeFull();
		layoutBasicTab.setStyleName("SubScreen-tab");

		layoutBasicTabInputs1 = new HorizontalLayout();
		layoutBasicTabInputs1.setSizeUndefined();
		layoutBasicTabInputs1.setStyleName("padding-style");

		layoutBasicTabInputs2 = new HorizontalLayout();
		layoutBasicTabInputs2.setSizeUndefined();
		layoutBasicTabInputs2.setStyleName("padding-style");

		fillFields(layoutmainFields);
		addComponent(layoutmainFields);

	}

	private void fillFields(Layout mainLayout) {
		idType = createIdType();
		idNumber = createIdNumber();
		basictitle = createBasicTitle();
		status = createStatus();
		nationality = createNationality();

		layoutmainFields.addComponent(basictitle);
		layoutBasicTab.addComponent(layoutBasicTabInputs1);
		layoutBasicTab.addComponent(layoutBasicTabInputs2);
		mainLayout.addComponent(layoutBasicTab);

		layoutBasicTabInputs1.addComponent(idNumber);
		layoutBasicTabInputs1.addComponent(idType);
		((AbstractOrderedLayout) layoutBasicTabInputs1).setSpacing(true);

		layoutBasicTabInputs2.addComponent(status);
		layoutBasicTabInputs2.addComponent(nationality);
		((AbstractOrderedLayout) layoutBasicTabInputs2).setSpacing(true);
	}

	private Label createBasicTitle() {
		basictitle = new Label("Basic Information");
		basictitle.setStyleName(ValoTheme.LABEL_H2);
		return basictitle;
	}

	private TextField createIdNumber() {
		idNumber = new TextField();
		idNumber.setStyleName(ValoTheme.TEXTFIELD_LARGE);
		idNumber.setCaption(getBundleValue(CAPTIONS, IDNUMBER));
		idNumber.setId(IDNUMBER);
		idNumber.setNullRepresentation("");

		return idNumber;
	}

	private ComboBox createIdType() {
		ComboBox idType = new ComboBox();
		idType.setStyleName(ValoTheme.TEXTFIELD_LARGE);
		idType.setCaption(getBundleValue(CAPTIONS, IDTYPE));
		idType.setId(IDTYPE);
		idType.setNullSelectionItemId(getBundleValue(MSGS, IDTYPE));
		idType.setInputPrompt(getBundleValue(MSGS, IDTYPE));
		idType.setDescription(getBundleValue(MSGS, IDTYPE));
		idType.setContainerDataSource(new BeanItemContainer<Patientidtype>(Patientidtype.class, IDTypesList));
		idType.setItemCaptionPropertyId("displayName");

		return idType;
	}

	private ComboBox createStatus() {
		ComboBox status = new ComboBox();
		status.setStyleName(ValoTheme.TEXTFIELD_LARGE);
		status.setCaption(getBundleValue(CAPTIONS, MARTIAL_STATUS));
		status.setId(MARTIAL_STATUS);
		status.setNullSelectionItemId(getBundleValue(MSGS, MARTIAL_STATUS));
		// status.setInputPrompt(getBundleValue(MSGS, MARTIAL_STATUS));
		status.setDescription(getBundleValue(MSGS, MARTIAL_STATUS));
		for (int i = 0; i < MstatusList.size(); i++) {
			status.addItem(MstatusList.get(i));
		}
		return status;
	}

	private ComboBox createNationality() {
		ComboBox nationality = new ComboBox();
		nationality.setStyleName(ValoTheme.TEXTFIELD_LARGE);
		nationality.setCaption(getBundleValue(CAPTIONS, NATIONALITY));
		nationality.setId(NATIONALITY);
		nationality.setNullSelectionItemId(getBundleValue(MSGS, NATIONALITY));
		nationality.setInputPrompt(getBundleValue(MSGS, NATIONALITY));
		nationality.setDescription(getBundleValue(MSGS, NATIONALITY));

		for (int i = 0; i < countryList.size(); i++) {
			nationality.addItem(countryList.get(i));
		}

		return nationality;
	}

	public ComboBox getIdType() {
		return idType;
	}

	public void setIdType(ComboBox idType) {
		this.idType = idType;
	}

	public TextField getIdNumber() {
		return idNumber;
	}

	public void setIdNumber(TextField idNumber) {
		this.idNumber = idNumber;
	}

	public ComboBox getNationality() {
		return nationality;
	}

	public void setNationality(ComboBox nationality) {
		this.nationality = nationality;
	}

	public ComboBox getStatus() {
		return status;
	}

	public void setStatus(ComboBox status) {
		this.status = status;
	}

	private void addPatientFieldGroup(BeanItem<Patient_Entity> patientItem) {
		PatientfieldGroup = new BeanFieldGroup<Patient_Entity>(Patient_Entity.class);
		PatientfieldGroup.setBuffered(false);// not to depend on commitss
		PatientfieldGroup.setItemDataSource(patientItem);
		PatientfieldGroup.bindMemberFields(this);
	}

	public BeanFieldGroup<Patient_Entity> getPatientfieldGroup() {
		return PatientfieldGroup;
	}

	public void setPatientfieldGroup(BeanFieldGroup<Patient_Entity> patientfieldGroup) {
		PatientfieldGroup = patientfieldGroup;
	}
	public void updatePatientFieldGroup(BeanItem<Patient_Entity>  patientItem){
		PatientfieldGroup.setItemDataSource(patientItem);
	}
}
