package com.smartera3s.nasec.screens.Clinic;

import static com.smartera3s.nasec.controllers.PatientSearchController.PATIENT_NAME;
import static com.smartera3s.nasec.controllers.PatientSearchController.AGE;
import static com.smartera3s.nasec.controllers.VisitController.VISITDATE;
import static com.smartera3s.nasec.controllers.VisitController.VISITID;
import static com.smartera3s.utils.InternationalizationFileBundle.CAPTIONS;
import static com.smartera3s.utils.InternationalizationFileBundle.getBundleValue;

import java.util.Date;

import com.smartera3s.nasec.model.entities.ClinicvisitEntity;
import com.vaadin.data.fieldgroup.BeanFieldGroup;
import com.vaadin.data.fieldgroup.PropertyId;
import com.vaadin.data.util.BeanItem;
import com.vaadin.data.util.ObjectProperty;
import com.vaadin.ui.CssLayout;
import com.vaadin.ui.HorizontalLayout;
import com.vaadin.ui.Image;
import com.vaadin.ui.Label;
import com.vaadin.ui.Layout;
import com.vaadin.ui.TextField;
import com.vaadin.ui.VerticalLayout;
import com.vaadin.ui.themes.ValoTheme;

@SuppressWarnings("serial")
public class ClinicPatientSubscreen extends CssLayout {

    private Image myLocalImage;
    private TextField PatientID;
    
    //Labels
    private Label Patientname;
    private Label Patientage;
    private Label Visitid;
    private Label Visitdate;
    @PropertyId("contact")
    private Label Contact;
    @PropertyId("waiting_list")
    private Label WaitingList;
    
    //Layouts
    private Layout imageLayout;
    private Layout pateintinfoLayout;
    private Layout pateintinfoLayout2;
    private Layout VisitLayout;
    private Layout VisitLayout2;
    private Layout ContactLayout;
    private Layout ContactLayout2;
    
    //Object Property to fill Labels
    private ObjectProperty<String> NameLabel;
    private ObjectProperty<String> AgeLabel;
    private ObjectProperty<String> VisitLabel;
    private ObjectProperty<Date> DateLabel;

    //Binding Group
    private BeanFieldGroup<ClinicvisitEntity> ClinicfieldGroup;
    
    public ClinicPatientSubscreen(BeanItem<ClinicvisitEntity> clinicItem) {
        NameLabel = new ObjectProperty<String>("");
        AgeLabel = new ObjectProperty<String>("");
        VisitLabel = new ObjectProperty<String>("");
        DateLabel = new ObjectProperty<Date>(new Date());
        setSizeUndefined();
        addlayout();
        fillLayout();
//        addClinicFieldGroup(clinicItem);
    }

    public void addlayout() {

        imageLayout = new HorizontalLayout();
        imageLayout.setSizeUndefined();
        imageLayout.setStyleName("spark");

        pateintinfoLayout = new VerticalLayout();
        pateintinfoLayout.setSizeUndefined();
        pateintinfoLayout.setStyleName("spark");
        
        pateintinfoLayout2 = new VerticalLayout();
        pateintinfoLayout2.setSizeUndefined();
        pateintinfoLayout2.setStyleName("spark");

        VisitLayout = new VerticalLayout();
        VisitLayout.setSizeUndefined();
        VisitLayout.setStyleName("spark");
        
        VisitLayout2 = new VerticalLayout();
        VisitLayout2.setSizeUndefined();
        VisitLayout2.setStyleName("spark");

        ContactLayout = new VerticalLayout();
        ContactLayout.setSizeUndefined();
        ContactLayout.setStyleName("spark");

        addComponent(imageLayout);
        addComponent(pateintinfoLayout);
        addComponent(VisitLayout);
        addComponent(pateintinfoLayout2);
        addComponent(VisitLayout2);
       // addComponent(ContactLayout);
        setStyleName(ValoTheme.LAYOUT_HORIZONTAL_WRAPPING);

    }

    private void fillLayout() {
        myLocalImage = createImage();
        Patientage = createPatientAge();
        Patientname = createPatientName();
        PatientID = createPatientID();
        Visitdate = createVisitDate();
        Visitid = createVisitID();
        Contact = createContact();
        WaitingList = createWaitingList();
        imageLayout.addComponent(myLocalImage);

        pateintinfoLayout.addComponent(Patientname);
        pateintinfoLayout2.addComponent(Patientage);
        
        VisitLayout.addComponent(Visitid);
        VisitLayout2.addComponent(Visitdate);

        ContactLayout.addComponent(Contact);
        ContactLayout.addComponent(WaitingList);

    }

    private Image createImage() {
        myLocalImage = new Image();
        myLocalImage.setWidth("40px");
        myLocalImage.setHeight("40px");
        myLocalImage.setStyleName("user-menu");
        return myLocalImage;

    }

    private Label createPatientName() {
        Patientname = new Label("");
        Patientname.setId(PATIENT_NAME);
        Patientname.setCaption(getBundleValue(CAPTIONS, PATIENT_NAME));
        Patientname.setStyleName(ValoTheme.LABEL_NO_MARGIN);
        Patientname.setPropertyDataSource(NameLabel);
        return Patientname;
    }

    private TextField createPatientID() {
        PatientID = new TextField();
        PatientID.setStyleName(ValoTheme.TEXTAREA_BORDERLESS);
        return PatientID;
    }

    private Label createPatientAge() {
        Patientage = new Label("");
        Patientage.setId(AGE);
        Patientage.setStyleName(ValoTheme.LABEL_NO_MARGIN);
        Patientage.setCaption(getBundleValue(CAPTIONS, AGE));
         Patientage.setPropertyDataSource(AgeLabel);
        return Patientage;
    }

    private Label createVisitID() {
        Visitid = new Label("");
        Visitid.setId(VISITID);
        Visitid.setCaption(getBundleValue(CAPTIONS, VISITID));
        Visitid.setStyleName(ValoTheme.LABEL_NO_MARGIN);
        Visitid.setPropertyDataSource(VisitLabel);
        return Visitid;
    }

    private Label createVisitDate() {
        Visitdate = new Label("");
        Visitdate.setId(VISITDATE);
        Visitdate.setCaption(getBundleValue(CAPTIONS, VISITDATE));
        Visitdate.setStyleName(ValoTheme.LABEL_NO_MARGIN);
        Visitdate.setPropertyDataSource(DateLabel);
        return Visitdate;
    }

    private Label createContact() {
        Contact = new Label("");
        Contact.setStyleName(ValoTheme.LABEL_H3);
        return Contact;
    }

    private Label createWaitingList() {
        WaitingList = new Label("");
        WaitingList.setStyleName(ValoTheme.LABEL_H3);
        return WaitingList;
    }

    public Label getPatientname() {
        return Patientname;
    }

    public void setPatientname(Label patientname) {
        Patientname = patientname;
    }

    public Label getPatientage() {
        return Patientage;
    }

    public void setPatientage(Label patientage) {
        Patientage = patientage;
    }

    public Label getVisitid() {
        return Visitid;
    }

    public void setVisitid(Label visitid) {
        Visitid = visitid;
    }

    public Label getVisitdate() {
        return Visitdate;
    }

    public void setVisitdate(Label visitdate) {
        Visitdate = visitdate;
    }

    public Label getContact() {
        return Contact;
    }

    public void setContact(Label contact) {
        Contact = contact;
    }

    public Label getWaitingList() {
        return WaitingList;
    }

    public void setWaitingList(Label waitingList) {
        WaitingList = waitingList;
    }

    private void addClinicFieldGroup(BeanItem<ClinicvisitEntity> clinicItem) {
        ClinicfieldGroup = new BeanFieldGroup<ClinicvisitEntity>(ClinicvisitEntity.class);
        ClinicfieldGroup.setBuffered(false);// not to depend on commitss
        ClinicfieldGroup.setItemDataSource(clinicItem);
        ClinicfieldGroup.bindMemberFields(this);

    }

    public BeanFieldGroup<ClinicvisitEntity> getClinicfieldGroup() {
        return ClinicfieldGroup;
    }

    public TextField getPatientID() {
        return PatientID;
    }

    public void setPatientID(TextField patientID) {
        PatientID = patientID;
    }

    public Image getMyLocalImage() {
        return myLocalImage;
    }

    public void setMyLocalImage(Image myLocalImage) {
        this.myLocalImage = myLocalImage;
    }

    public ObjectProperty<String> getNameLabel() {
        return NameLabel;
    }

    public void setNameLabel(ObjectProperty<String> nameLabel) {
        NameLabel = nameLabel;
    }

    public ObjectProperty<String> getVisitLabel() {
        return VisitLabel;
    }

    public void setVisitLabel(ObjectProperty<String> visitLabel) {
        VisitLabel = visitLabel;
    }

    public ObjectProperty<Date> getDateLabel() {
        return DateLabel;
    }

    public void setDateLabel(ObjectProperty<Date> dateLabel) {
        DateLabel = dateLabel;
    }

    public ObjectProperty<String> getAgeLabel() {
        return AgeLabel;
    }

    public void setAgeLabel(ObjectProperty<String> ageLabel) {
        AgeLabel = ageLabel;
    }
}
