package com.smartera3s.nasec.model.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;
import java.util.List;


/**
 * The persistent class for the patient database table.
 * 
 */
@Entity
@Table(name="patient")
@NamedQuery(name="Patient_Entity.findAll", query="SELECT p FROM Patient_Entity p")
public class Patient_Entity implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer id;

	private boolean custodian;

	@Temporal(TemporalType.DATE)
	private Date dob;

	private String first_name;

	private String gender;

	@Column(name="Id_number")
	private String idNumber;

	private int id_type;

	private String last_name;
	@Transient
	private String fullName;
	@Transient
        private Patientidtype linkedIDType;

	private String martial_status;

	private String nationality;

	private String payment_method;

	@Lob
	private String profile_pic;

	private String second_name;
	
	@Transient
	List<Contact_Entity> contacts;
	@Transient
	List<Company_Entity> company;
	@Transient
        VisitEntity visit;
	
	public Patient_Entity() {
	}
	
	public Integer getId() {
		return this.id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public boolean getCustodian() {
		return this.custodian;
	}

	public void setCustodian(boolean custodian) {
		this.custodian = custodian;
	}

	public Date getDob() {
		return this.dob;
	}

	public void setDob(Date dob) {
		this.dob = dob;
	}

	public String getFirst_name() {
		return this.first_name ;
	}

	public void setFirst_name(String first_name) {
		this.first_name = first_name;
		if(second_name == null){second_name ="";}
		if(last_name == null){last_name ="";}
		if(first_name != null){fullName=this.first_name+" "+second_name +" "+ last_name;}
	}

	public String getGender() {
		return this.gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getIdNumber() {
		return this.idNumber;
	}

	public void setIdNumber(String idNumber) {
		this.idNumber = idNumber;
	}

	public int getId_type() {
		return this.id_type;
	}

	public void setId_type(int id_type) {
		this.id_type = id_type;
	}

	public String getLast_name() {
		return this.last_name ;
	}

	public void setLast_name(String last_name) {
		this.last_name =last_name;
		if(second_name == null){second_name = "";}
                if(first_name == null){first_name = "";}
		if(last_name != null){fullName=this.first_name+" "+second_name+" "+this.last_name;}
	}

	public String getMartial_status() {
		return this.martial_status;
	}

	public void setMartial_status(String martial_status) {
		this.martial_status = martial_status;
	}

	public String getNationality() {
		return this.nationality;
	}

	public void setNationality(String nationality) {
		this.nationality = nationality;
	}

	public String getPayment_method() {
		return this.payment_method;
	}

	public void setPayment_method(String payment_method) {
		this.payment_method = payment_method;
	}

	public String getProfile_pic() {
		return this.profile_pic;
	}

	public void setProfile_pic(String profile_pic) {
		this.profile_pic = profile_pic;
	}

	public String getSecond_name() {
		return this.second_name  ;
	}

	public void setSecond_name(String second_name) {
		this.second_name = second_name;
		if(last_name == null){last_name = "";}
                if(first_name == null){first_name = "";}
		if(second_name != null){fullName=this.first_name+" "+this.second_name+" "+last_name;}
	}

        public String getFullName() {
            
                return  fullName;
        }

        public void setFullName(String fullName) {
                this.fullName = fullName;
        }

        public List<Contact_Entity> getContacts() {
            return contacts;
        }

        public void setContacts(List<Contact_Entity> contacts) {
            this.contacts = contacts;
        }

        public Patientidtype getLinkedIDType() {
            if(linkedIDType == null){
                linkedIDType = new Patientidtype();
            }
            linkedIDType.setId(id_type);
            
            return linkedIDType;
        }

        public void setLinkedIDType(Patientidtype linkedIDType) {
            id_type = linkedIDType.getId();
            this.linkedIDType = linkedIDType;
        }


        public void setCompany(List<Company_Entity> company) {
            this.company = company;
        }

        public List<Company_Entity> getCompany() {
            return company;
        }

        public VisitEntity getVisit() {
            return visit;
        }

        public void setVisit(VisitEntity visit) {
            this.visit = visit;
        }

        @Override
        public String toString() {
            return first_name+" "+second_name+" "+last_name;
        }
}