package com.smartera3s.nasec.screens.reg;

import static com.smartera3s.nasec.controllers.RegisterationController.ADDR;
import static com.smartera3s.nasec.controllers.RegisterationController.FISRT_NAME;
import static com.smartera3s.nasec.controllers.RegisterationController.LAST_NAME;
import static com.smartera3s.nasec.controllers.RegisterationController.PRIMARY_CONTACT;
import static com.smartera3s.nasec.controllers.RegisterationController.RELATION_TYPE;
import static com.smartera3s.nasec.controllers.RegisterationController.SECOND_NAME;
import static com.smartera3s.utils.InternationalizationFileBundle.CAPTIONS;
import static com.smartera3s.utils.InternationalizationFileBundle.MSGS;
import static com.smartera3s.utils.InternationalizationFileBundle.getBundleValue;

import java.util.List;

import com.smartera3s.nasec.controllers.RegisterationController;
import com.smartera3s.nasec.listeners.RegisterationScreenListener;
import com.smartera3s.nasec.model.Relation_Container;
import com.smartera3s.nasec.model.entities.Address_Entity;
import com.smartera3s.nasec.model.entities.Company_Entity;
import com.smartera3s.nasec.model.entities.PatientRelation;
import com.smartera3s.nasec.model.entities.Relation;
import com.smartera3s.nasec.services.RegisterationService;
import com.vaadin.data.fieldgroup.BeanFieldGroup;
import com.vaadin.data.fieldgroup.PropertyId;
import com.vaadin.data.util.BeanItem;
import com.vaadin.data.util.BeanItemContainer;
import com.vaadin.ui.AbstractOrderedLayout;
import com.vaadin.ui.Button;
import com.vaadin.ui.ComboBox;
import com.vaadin.ui.Component;
import com.vaadin.ui.CssLayout;
import com.vaadin.ui.HorizontalLayout;
import com.vaadin.ui.Label;
import com.vaadin.ui.Layout;
import com.vaadin.ui.Table;
import com.vaadin.ui.TextField;
import com.vaadin.ui.VerticalLayout;
import com.vaadin.ui.Button.ClickEvent;
import com.vaadin.ui.themes.ValoTheme;

public class RegisterationReslationSubScreen extends CssLayout {

	public Table getRelations() {
		return relations;
	}

	public void setRelations(Table relations) {
		this.relations = relations;
	}

	// Labels
	private Label Relation;

	// TextFields
	@PropertyId("first")
	private TextField relationfirstName;
	@PropertyId("second")
	private TextField relationsecondName;
	@PropertyId("last")
	private TextField relationlastName;
	@PropertyId("mobile")
	private TextField relationprimaryContact;

	// ComboBox
	@PropertyId("relation")
	private ComboBox relationtype;

	// Layouts
	private Layout layoutRelationTabInputs2;
	private Layout layoutRelationTabInputs3;
	private Layout layoutRelationTabInputs4;

	/// Ahmed add it
	private Layout layoutmainFields;
	private Layout Container;

	// Buttons
	private Button addRelation;

	// Tables
	private Table relations;

	private RegisterationScreenListener eventsListener;
	private RegisterationService Service;
	private BeanFieldGroup<PatientRelation> PatientRelationfieldGroup;
	private List<Relation> RType;

	public RegisterationReslationSubScreen(BeanItem<PatientRelation> PatientRelationItem,
			RegisterationScreenListener listener) {

		this.eventsListener = listener;
		Service = new RegisterationService();
		RType = Service.findAllRtype();

		addLayouts();
		addPatientRelationFieldGroup(PatientRelationItem);
	}

	public void addLayouts() {

		layoutmainFields = new VerticalLayout();
		layoutmainFields.setSizeUndefined();
		layoutmainFields.setStyleName("SubScreen-style");

		Container = new VerticalLayout();
		Container.setSizeUndefined();
		Container.setStyleName("SubScreen-tab");
		
		layoutRelationTabInputs2 = new HorizontalLayout();
		layoutRelationTabInputs2.setSizeUndefined();
		layoutRelationTabInputs2.setStyleName("padding-style");

		layoutRelationTabInputs3 = new HorizontalLayout();
		layoutRelationTabInputs3.setSizeUndefined();
		layoutRelationTabInputs3.setStyleName("padding-style");

		layoutRelationTabInputs4 = new HorizontalLayout();
		layoutRelationTabInputs4.setSizeUndefined();
		layoutRelationTabInputs4.setStyleName("padding-style");

		fillFields(layoutmainFields);
		addComponent(layoutmainFields);
	}

	private void fillFields(Layout mainLayout) {
		Relation = createRelation();
		relationtype = createRtype();
		relationfirstName = createRelationFirstName();
		relationsecondName = createRelationSecondName();
		relationlastName = createRelationLastName();
		relationprimaryContact = createContact();
		addRelation = createRelationButton();

		mainLayout.addComponent(Relation);
		Container.addComponent(layoutRelationTabInputs2);
		Container.addComponent(layoutRelationTabInputs3);
		Container.addComponent(layoutRelationTabInputs4);
		mainLayout.addComponent(Container);

		layoutRelationTabInputs2.addComponent(relationfirstName);
		layoutRelationTabInputs2.addComponent(relationsecondName);
		layoutRelationTabInputs2.addComponent(relationlastName);
		layoutRelationTabInputs3.addComponent(relationprimaryContact);
		layoutRelationTabInputs3.addComponent(relationtype);
		layoutRelationTabInputs3.addComponent(addRelation);
		relations = fillRelationTable(relations);
		layoutRelationTabInputs4.addComponent(relations);

		((AbstractOrderedLayout) layoutRelationTabInputs2).setSpacing(true);
		((AbstractOrderedLayout) layoutRelationTabInputs3).setSpacing(true);
	}

	private Table fillRelationTable(Table reltion) {
		reltion = new Table();
		reltion.setEditable(true);
		reltion.setPageLength(3);
		return reltion;
	}

	private Label createRelation() {
		Relation = new Label("Patient Personal Relations");
		Relation.setStyleName(ValoTheme.LABEL_H2);

		return Relation;
	}

	private TextField createRelationSecondName() {
		relationsecondName = new TextField();
		relationsecondName.setStyleName(ValoTheme.TEXTFIELD_LARGE);
		relationsecondName.setCaption(getBundleValue(CAPTIONS, SECOND_NAME));
		relationsecondName.setId(SECOND_NAME);
		relationsecondName.setDescription(getBundleValue(MSGS, SECOND_NAME));
		relationsecondName.setNullRepresentation("");

		return relationsecondName;
	}

	private TextField createRelationLastName() {
		relationlastName = new TextField();
		relationlastName.setStyleName(ValoTheme.TEXTFIELD_LARGE);
		relationlastName.setCaption(getBundleValue(CAPTIONS, LAST_NAME));
		relationlastName.setId(LAST_NAME);
		relationlastName.setDescription(getBundleValue(MSGS, LAST_NAME));
		relationlastName.setNullRepresentation("");

		return relationlastName;
	}

	private TextField createRelationFirstName() {
		relationfirstName = new TextField();
		relationfirstName.setStyleName(ValoTheme.TEXTFIELD_LARGE);
		relationfirstName.setCaption(getBundleValue(CAPTIONS, FISRT_NAME));
		relationfirstName.setId(FISRT_NAME);
		relationfirstName.setDescription(getBundleValue(MSGS, FISRT_NAME));
		relationfirstName.setNullRepresentation("");

		return relationfirstName;
	}

	private TextField createContact() {
		relationprimaryContact = new TextField();
		relationprimaryContact.setStyleName(ValoTheme.TEXTFIELD_LARGE);
		relationprimaryContact.setCaption(getBundleValue(CAPTIONS, PRIMARY_CONTACT));
		relationprimaryContact.setId(PRIMARY_CONTACT);
		relationprimaryContact.setDescription(getBundleValue(MSGS, PRIMARY_CONTACT));
		relationprimaryContact.setNullRepresentation("");

		return relationprimaryContact;
	}

	private Button createRelationButton() {
		addRelation = new Button(getBundleValue(CAPTIONS, ADDR));
		addRelation.setStyleName(ValoTheme.BUTTON_PRIMARY);
		// addRelation.setClickShortcut(KeyCode.ENTER);
		addRelation.setId(ADDR);

		// assign the listener class that handles events
		addRelation.addClickListener(eventsListener);
		return addRelation;
	}

	private ComboBox createRtype() {
		ComboBox type = new ComboBox();
		type.setStyleName(ValoTheme.TEXTFIELD_LARGE);
		type.setCaption(getBundleValue(CAPTIONS, RELATION_TYPE));
		type.setId(RELATION_TYPE);
		type.setNullSelectionItemId(getBundleValue(MSGS, RELATION_TYPE));
		type.setInputPrompt(getBundleValue(MSGS, RELATION_TYPE));
		type.setDescription(getBundleValue(MSGS, RELATION_TYPE));

		for (int i = 0; i < RType.size(); i++) {
			type.addItem(RType.get(i));
		}

		return type;
	}

	public TextField getRelationfirstName() {
		return relationfirstName;
	}

	public void setRelationfirstName(TextField relationfirstName) {
		this.relationfirstName = relationfirstName;
	}

	public TextField getRelationsecondName() {
		return relationsecondName;
	}

	public void setRelationsecondName(TextField relationsecondName) {
		this.relationsecondName = relationsecondName;
	}

	public TextField getRelationlastName() {
		return relationlastName;
	}

	public void setRelationlastName(TextField relationlastName) {
		this.relationlastName = relationlastName;
	}

	public TextField getRelationprimaryContact() {
		return relationprimaryContact;
	}

	public void setRelationprimaryContact(TextField relationprimaryContact) {
		this.relationprimaryContact = relationprimaryContact;
	}

	public ComboBox getRelationtype() {
		return relationtype;
	}

	public void setRelationtype(ComboBox relationtype) {
		this.relationtype = relationtype;
	}

	private void addPatientRelationFieldGroup(BeanItem<PatientRelation> patientRelationItem) {
		PatientRelationfieldGroup = new BeanFieldGroup<PatientRelation>(PatientRelation.class);
		PatientRelationfieldGroup.setBuffered(false);// not to depend on
														// commitss
		PatientRelationfieldGroup.setItemDataSource(patientRelationItem);
		PatientRelationfieldGroup.bindMemberFields(this);
	}
}
