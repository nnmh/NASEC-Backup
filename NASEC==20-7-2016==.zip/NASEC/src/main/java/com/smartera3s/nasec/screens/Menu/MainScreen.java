package com.smartera3s.nasec.screens.Menu;

import com.vaadin.ui.UI;
import com.vaadin.ui.VerticalLayout;
import com.vaadin.ui.CssLayout;
import com.vaadin.server.FontAwesome;
import com.vaadin.server.ThemeResource;
import com.smartera3s.nasec.screens.Nurse.*;
import com.smartera3s.nasec.screens.Operation.*;
import com.smartera3s.utils.ControllersSelector;
import com.smartera3s.nasec.screens.Investigation.*;
import com.smartera3s.nasec.controllers.ClinicController;
import com.smartera3s.nasec.controllers.InvestigationController;
import com.smartera3s.nasec.controllers.NurseController;
import com.smartera3s.nasec.controllers.OperationController;
import com.smartera3s.nasec.controllers.PatientSearchController;
import com.smartera3s.nasec.controllers.RegisterationController;
import com.smartera3s.nasec.controllers.VisitController;
import com.smartera3s.nasec.controllers.UIController;
import com.smartera3s.nasec.screens.Clinic.ClinicScreen;
import com.vaadin.navigator.Navigator;
import com.vaadin.ui.HorizontalLayout;
import com.vaadin.navigator.ViewChangeListener;
import com.vaadin.navigator.ViewChangeListener.ViewChangeEvent;

@SuppressWarnings("serial")
public class MainScreen extends VerticalLayout {
    private MenuScreen menu;
    private ControllersSelector Selector;
    UIController controller;

    public MainScreen() {

        setStyleName("main-screen");
        setSizeFull();
        HorizontalLayout manibody = new HorizontalLayout();
        CssLayout viewContainer = new CssLayout();
        viewContainer.addStyleName("valo-content");
        viewContainer.setSizeFull();

        final Navigator navigator = new Navigator(UI.getCurrent(),
                viewContainer);
        navigator.setErrorView(ErrorView.class);

        menu = new MenuScreen(navigator);
        Selector = new ControllersSelector();
        menu.addView(new PatientSearchController().getView(),
                new PatientSearchController().getClass().getName(),
                PatientSearchController.VIEW_NAME,
                new ThemeResource("img/search.PNG"));
        menu.addView(new VisitController(navigator).getView(),
                new VisitController(navigator).getClass().getName(),
                VisitController.VIEW_NAME, new ThemeResource("img/visit.PNG"));
        menu.addView(Selector.get(ClinicController.class).getView(),
                Selector.get(ClinicController.class).getClass().getName(),
                ClinicScreen.VIEW_NAME, new ThemeResource("img/clinic.PNG"));
        menu.addView(Selector.get(RegisterationController.class).getView(),
                new RegisterationController().getClass().getName(),
                RegisterationController.VIEW_NAME,
                new ThemeResource("img/registartion.PNG"));
        menu.addView(new NurseController().getView(),
                new NurseController().getClass().getName(),
                NurseScreen.VIEW_NAME, new ThemeResource("img/nurse.PNG"));
        menu.addView(new OperationController().getView(),
                new OperationController().getClass().getName(),
                OperationScreen.VIEW_NAME,
                new ThemeResource("img/operation.PNG"));
        menu.addView(new InvestigationController().getView(),
                new InvestigationController().getClass().getName(),
                InvestigationScreen.VIEW_NAME,
                new ThemeResource("img/investigation.PNG"));
        menu.addView(new AboutView(), new AboutView().getClass().getName(),
                AboutView.VIEW_NAME, new ThemeResource("img/about.PNG"));

        navigator.addViewChangeListener(viewChangeListener);

        manibody.addComponent(menu);
        manibody.addComponent(viewContainer);
        manibody.setExpandRatio(viewContainer, 1);
        manibody.setSizeFull();

        addComponent(menu.buildTitle());
        addComponent(manibody);
        setExpandRatio(manibody, 1);
    }

    // notify the view menu about view changes so that it can display which view
    // is currently active
    ViewChangeListener viewChangeListener = new ViewChangeListener() {

        @Override
        public boolean beforeViewChange(ViewChangeEvent event) {
            return true;
        }

        @Override
        public void afterViewChange(ViewChangeEvent event) {
            menu.setActiveView(event.getViewName());
            // System.out.println(event.getViewName());
        }

    };
}
