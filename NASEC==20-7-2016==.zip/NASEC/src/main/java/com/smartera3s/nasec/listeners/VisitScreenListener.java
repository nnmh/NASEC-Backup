package com.smartera3s.nasec.listeners;

import static com.smartera3s.nasec.controllers.VisitController.LOAD;
import static com.smartera3s.nasec.controllers.VisitController.ADD;
import static com.smartera3s.nasec.controllers.VisitController.SAVEREQUEST;
import static com.smartera3s.nasec.controllers.VisitController.VISITSEARCH;
import static com.smartera3s.nasec.controllers.VisitController.SUBMIT;

import com.smartera3s.nasec.controllers.VisitController;
import com.vaadin.data.Property.ValueChangeEvent;
import com.vaadin.data.Property.ValueChangeListener;
import com.vaadin.data.util.BeanItem;
import com.vaadin.event.ItemClickEvent;
import com.vaadin.event.ItemClickEvent.ItemClickListener;
import com.vaadin.ui.Button.ClickEvent;
import com.vaadin.ui.Button.ClickListener;

public class VisitScreenListener implements ClickListener , ValueChangeListener, ItemClickListener{
private VisitController visitController;
    
    public VisitScreenListener(VisitController controller){
            this.visitController=controller;
    }
    public void buttonClick(ClickEvent event) {
        if(event.getButton().getId().equals(LOAD)){
            visitController.load();
        }
        if(event.getButton().getId().equals(ADD)){
            visitController.add();
        }
        if(event.getButton().getId().equals(SAVEREQUEST)){
            visitController.saveRequest();
        }
        if(event.getButton().getId().equals(VISITSEARCH)){
            visitController.searchbutton();
        }
        if(event.getButton().getId().equals(SUBMIT)){
            visitController.search();
        }

}
    public void valueChange(ValueChangeEvent event) {
        visitController.visitTO(event);
        
    }
    public void itemClick(ItemClickEvent event) {
        // TODO Auto-generated method stub
        if(event.isDoubleClick()){
            visitController.selectVisit(((BeanItem)event.getItem()).getBean());
        }
    }
}
