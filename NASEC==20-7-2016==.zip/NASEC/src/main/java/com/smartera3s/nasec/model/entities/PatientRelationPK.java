package com.smartera3s.nasec.model.entities;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the patient_relation database table.
 * 
 */
@Embeddable
public class PatientRelationPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(insertable=true, updatable=true)
	private int patient1_id;

	@Column(insertable=true, updatable=true)
	private int patient2_id;

	@Column(insertable=true, updatable=true)
	private int relation_id;

	public PatientRelationPK() {
	}
	public int getPatient1_id() {
		return this.patient1_id;
	}
	public void setPatient1_id(int patient1_id) {
		this.patient1_id = patient1_id;
	}
	public int getPatient2_id() {
		return this.patient2_id;
	}
	public void setPatient2_id(int patient2_id) {
		this.patient2_id = patient2_id;
	}
	public int getRelation_id() {
		return this.relation_id;
	}
	public void setRelation_id(int relation_id) {
		this.relation_id = relation_id;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof PatientRelationPK)) {
			return false;
		}
		PatientRelationPK castOther = (PatientRelationPK)other;
		return 
			(this.patient1_id == castOther.patient1_id)
			&& (this.patient2_id == castOther.patient2_id)
			&& (this.relation_id == castOther.relation_id);
	}

	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.patient1_id;
		hash = hash * prime + this.patient2_id;
		hash = hash * prime + this.relation_id;
		
		return hash;
	}
}