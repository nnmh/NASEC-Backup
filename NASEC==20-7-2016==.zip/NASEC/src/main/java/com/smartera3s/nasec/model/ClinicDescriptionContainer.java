package com.smartera3s.nasec.model;

import java.util.Collection;
import java.util.Date;
import java.util.List;

import com.smartera3s.nasec.model.entities.BodypartEntity;
import com.smartera3s.nasec.model.entities.Icd10Entity;
import com.vaadin.ui.ListSelect;

public class ClinicDescriptionContainer {
    
    private Date date;
    private String notes;
    private Collection<Icd10Entity> ICD;
    private Collection<BodypartEntity> Bodyparts;
    
    public ClinicDescriptionContainer(Date date2,  String note) {
        this.notes   = note;
        this.date   = date2;
        
    }
    public Date getDate() {
        return date;
    }
    public void setDate(Date date) {
        this.date = date;
    }
    public String getNotes() {
        return notes;
    }
    public void setNotes(String notes) {
        this.notes = notes;
    }
    public Collection<Icd10Entity> getICD() {
        return ICD;
    }
    public void setICD(Collection<Icd10Entity> iCD) {
        ICD = iCD;
    }
    public Collection<BodypartEntity> getBodyparts() {
        return Bodyparts;
    }
    public void setBodyparts(Collection<BodypartEntity> bodyparts) {
        Bodyparts = bodyparts;
    }
    
}
