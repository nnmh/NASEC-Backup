package com.smartera3s.nasec.screens.reg;

import static com.smartera3s.nasec.controllers.PatientSearchController.CONTACT_TYPE;
import static com.smartera3s.nasec.controllers.RegisterationController.ADD;
import static com.smartera3s.nasec.controllers.RegisterationController.ADDRESS;
import static com.smartera3s.nasec.controllers.RegisterationController.CITY;
import static com.smartera3s.nasec.controllers.RegisterationController.CONTACT;
import static com.smartera3s.nasec.controllers.RegisterationController.COUNTRY;
import static com.smartera3s.nasec.controllers.RegisterationController.POSTALCODE;
import static com.smartera3s.nasec.controllers.RegisterationController.REGION;
import static com.smartera3s.utils.InternationalizationFileBundle.CAPTIONS;
import static com.smartera3s.utils.InternationalizationFileBundle.MSGS;
import static com.smartera3s.utils.InternationalizationFileBundle.getBundleValue;

import java.util.List;

import com.smartera3s.nasec.listeners.RegisterationScreenListener;
import com.smartera3s.nasec.model.entities.Address_Entity;
import com.smartera3s.nasec.model.entities.CityEntity;
import com.smartera3s.nasec.model.entities.ContactTypeEntity;
import com.smartera3s.nasec.model.entities.Contact_Entity;
import com.smartera3s.nasec.model.entities.CountryEntity;
import com.smartera3s.nasec.model.entities.MstatusEntity;
import com.smartera3s.nasec.model.entities.Patient_Entity;
import com.smartera3s.nasec.services.RegisterationService;
import com.vaadin.data.Property;
import com.vaadin.data.Property.ValueChangeEvent;
import com.vaadin.data.fieldgroup.BeanFieldGroup;
import com.vaadin.data.fieldgroup.PropertyId;
import com.vaadin.data.util.BeanItem;
import com.vaadin.data.util.BeanItemContainer;
import com.vaadin.ui.AbstractOrderedLayout;
import com.vaadin.ui.Button;
import com.vaadin.ui.ComboBox;
import com.vaadin.ui.CssLayout;
import com.vaadin.ui.HorizontalLayout;
import com.vaadin.ui.Label;
import com.vaadin.ui.Layout;
import com.vaadin.ui.Table;
import com.vaadin.ui.TextArea;
import com.vaadin.ui.TextField;
import com.vaadin.ui.VerticalLayout;
import com.vaadin.ui.Button.ClickEvent;
import com.vaadin.ui.themes.ValoTheme;

public class RegisterationContactSubScreen extends CssLayout {

	// Labels
	@PropertyId("contacttitle")
	private Label contacttitle;

	// Layouts
	private Layout layoutContactTab;
	private Layout layoutContactTabInputs1;
	private Layout layoutContactTabInputs2;
	private Layout layoutContactTabInputs3;
	private Layout layoutContactTabInputs4;

	/// Ahmed add it
	private Layout layoutmainFields;
	private Layout ContactContainer;

	// Buttons
	private Button addContact;

	// Tables
	@PropertyId("contactTable")
	private Table contacts;

	// TextFields
	@PropertyId("country")
	private ComboBox country;
	@PropertyId("city")
	private ComboBox city;
	@PropertyId("contact_type")
	private ComboBox contacttype;
	@PropertyId("postal_code")
	private TextField postalCode;
	@PropertyId("region")
	private TextField region;
	@PropertyId("value")
	private TextField adcontact;

	// Text Area
	@PropertyId("address")
	private TextArea address;

	private List<CountryEntity> countryList;
	private List<CityEntity> City;
	private List<ContactTypeEntity> Type;
	private RegisterationService Service;
	private RegisterationScreenListener eventsListener;

	private BeanFieldGroup<Address_Entity> AddressfieldGroup;
	private BeanFieldGroup<Contact_Entity> ContactfieldGroup;

	public RegisterationContactSubScreen(BeanItem<Address_Entity> AddressItem, BeanItem<Contact_Entity> ContactItem,
			RegisterationScreenListener listener) {
		Service = new RegisterationService();
		countryList = Service.findAllCountries();
		City = Service.findAllCity();
		Type = Service.findAlltype();
		this.eventsListener = listener;

		addLayouts();
		addAddressFieldGroup(AddressItem);
		addContactFieldGroup(ContactItem);

	}

	private void addLayouts() {

		layoutmainFields = new VerticalLayout();
		layoutmainFields.setSizeUndefined();
		layoutmainFields.setStyleName("SubScreen-style");

		layoutContactTab = new VerticalLayout();
		layoutContactTab.setSizeUndefined();
		layoutContactTab.setStyleName("SubScreen-tab");

		layoutContactTabInputs1 = new HorizontalLayout();
		layoutContactTabInputs1.setSizeUndefined();
		layoutContactTabInputs1.setStyleName("padding-style");

		ContactContainer = new HorizontalLayout();
		ContactContainer.setSizeUndefined();

		layoutContactTabInputs2 = new HorizontalLayout();
		layoutContactTabInputs2.setSizeUndefined();
		layoutContactTabInputs2.setStyleName("padding-style");

		layoutContactTabInputs3 = new HorizontalLayout();
		layoutContactTabInputs3.setSizeUndefined();
		layoutContactTabInputs3.setStyleName("padding-style");

		layoutContactTabInputs4 = new HorizontalLayout();
		layoutContactTabInputs4.setSizeUndefined();
		layoutContactTabInputs4.setStyleName("padding-style");

		fillFields(layoutmainFields);
		addComponent(layoutmainFields);
	}

	private void fillFields(Layout mainLayout) {
		contacttitle = createContactTitle();
		address = createAddress();
		postalCode = createPostalCode();
		region = createRegion();

		city = createCity();
		country = createCountry();
		adcontact = createcontactvalue();
		contacttype = createtype();
		addContact = createContactButton();

		layoutmainFields.addComponent(contacttitle);
		layoutContactTab.addComponent(layoutContactTabInputs1);
		ContactContainer.addComponent(layoutContactTabInputs2);
		ContactContainer.addComponent(layoutContactTabInputs3);
		layoutContactTab.addComponent(ContactContainer);
		layoutContactTab.addComponent(layoutContactTabInputs4);

		mainLayout.addComponent(layoutContactTab);

		layoutContactTabInputs1.addComponent(address);
		VerticalLayout postalCodeandregion = new VerticalLayout();
		postalCodeandregion.addComponents(postalCode,region);
		layoutContactTabInputs1.addComponent(postalCodeandregion);
		layoutContactTabInputs2.addComponent(country);
		layoutContactTabInputs2.addComponent(city);
		country.addValueChangeListener(new Property.ValueChangeListener() {
			public void valueChange(ValueChangeEvent event) {
				String x = event.getProperty().getValue().toString();

				if (x.equals("Egypt")) {

					city.setVisible(true);

				}
			}
		});
		layoutContactTabInputs3.addComponent(contacttype);
		layoutContactTabInputs3.addComponent(adcontact);
		layoutContactTabInputs3.addComponent(addContact);
		contacts = fillTable();

		layoutContactTabInputs4.addComponent(contacts);
		((AbstractOrderedLayout) layoutContactTabInputs1).setSpacing(true);
		((AbstractOrderedLayout) layoutContactTabInputs2).setSpacing(true);
		((AbstractOrderedLayout) layoutContactTabInputs3).setSpacing(true);
	}

	private Table fillTable() {
		Table contact = new Table();
		contact.setEditable(true);
		contact.setPageLength(3);
		return contact;
	}

	private void addAddressFieldGroup(BeanItem<Address_Entity> addressItem) {
		AddressfieldGroup = new BeanFieldGroup<Address_Entity>(Address_Entity.class);
		AddressfieldGroup.setBuffered(false);// not to depend on commitss
		AddressfieldGroup.setItemDataSource(addressItem);
		AddressfieldGroup.bindMemberFields(this);
	}

	private void addContactFieldGroup(BeanItem<Contact_Entity> contactItem) {
		ContactfieldGroup = new BeanFieldGroup<Contact_Entity>(Contact_Entity.class);
		ContactfieldGroup.setBuffered(false);// not to depend on commitss
		ContactfieldGroup.setItemDataSource(contactItem);
		ContactfieldGroup.bindMemberFields(this);
	}
	public void updateAddressFieldGroup(BeanItem<Address_Entity>  addressItem){
		AddressfieldGroup.setItemDataSource(addressItem);
	}

	private Label createContactTitle() {
		contacttitle = new Label("Contact Information");
		contacttitle.setStyleName(ValoTheme.LABEL_H2);

		return contacttitle;
	}

	private TextField createcontactvalue() {
		adcontact = new TextField();
		adcontact.setStyleName(ValoTheme.TEXTFIELD_LARGE);
		adcontact.setCaption(getBundleValue(CAPTIONS, CONTACT));
		adcontact.setId(CONTACT);
		adcontact.setDescription(getBundleValue(MSGS, CONTACT));
		adcontact.setNullRepresentation("");

		return adcontact;
	}

	private TextField createRegion() {
		region = new TextField();
		region.setStyleName(ValoTheme.TEXTFIELD_LARGE);
		region.setCaption(getBundleValue(CAPTIONS, REGION));
		region.setId(REGION);
		region.setDescription(getBundleValue(MSGS, REGION));
		region.setNullRepresentation("");

		return region;
	}

	private TextArea createAddress() {
		address = new TextArea();
		address.setStyleName(ValoTheme.TEXTFIELD_LARGE);
		address.setCaption(getBundleValue(CAPTIONS, ADDRESS));
		address.setId(ADDRESS);
		address.setNullRepresentation("");
		address.setWidth("50%");

		return address;
	}

	private TextField createPostalCode() {
		postalCode = new TextField();
		postalCode.setStyleName(ValoTheme.TEXTFIELD_LARGE);
		postalCode.setCaption(getBundleValue(CAPTIONS, POSTALCODE));
		postalCode.setId(POSTALCODE);
		postalCode.setNullRepresentation("");

		return postalCode;
	}

	private Button createContactButton() {
		addContact = new Button(getBundleValue(CAPTIONS, ADD));
		addContact.setStyleName(ValoTheme.BUTTON_PRIMARY);
		// addContact.setClickShortcut(KeyCode.ENTER);
		addContact.setId(ADD);

		// assign the listener class that handles events
		addContact.addClickListener(eventsListener);
		return addContact;
	}

	private ComboBox createCity() {
		ComboBox city = new ComboBox();
		city.setStyleName(ValoTheme.TEXTFIELD_LARGE);
		city.setCaption(getBundleValue(CAPTIONS, CITY));
		city.setId(CITY);
		city.setVisible(false);
		city.setNullSelectionItemId(getBundleValue(MSGS, CITY));
		city.setInputPrompt(getBundleValue(MSGS, CITY));
		city.setDescription(getBundleValue(MSGS, CITY));
		for (int i = 0; i < City.size(); i++) {
			city.addItem(City.get(i));
		}
		return city;
	}

	private ComboBox createCountry() {
		ComboBox country = new ComboBox();
		country.setStyleName(ValoTheme.TEXTFIELD_LARGE);
		country.setCaption(getBundleValue(CAPTIONS, COUNTRY));
		country.setId(COUNTRY);
		country.setNullSelectionItemId(getBundleValue(MSGS, COUNTRY));
		country.setInputPrompt(getBundleValue(MSGS, COUNTRY));
		country.setDescription(getBundleValue(MSGS, COUNTRY));

		for (int i = 0; i < countryList.size(); i++) {
			country.addItem(countryList.get(i));
		}

		return country;
	}

	private ComboBox createtype() {
		ComboBox type = new ComboBox();
		type.setStyleName(ValoTheme.TEXTFIELD_LARGE);
		type.setCaption(getBundleValue(CAPTIONS, CONTACT_TYPE));
		type.setId(CONTACT_TYPE);
		type.setNullSelectionItemId(getBundleValue(MSGS, CONTACT_TYPE));
		type.setInputPrompt(getBundleValue(MSGS, CONTACT_TYPE));
		type.setDescription(getBundleValue(MSGS, CONTACT_TYPE));

		for (int i = 0; i < Type.size(); i++) {
			type.addItem(Type.get(i));
		}

		return type;
	}

	public Table getContacts() {
		return contacts;
	}

	public void setContacts(Table contacts) {
		this.contacts = contacts;
	}

	public ComboBox getCountry() {
		return country;
	}

	public void setCountry(ComboBox country) {
		this.country = country;
	}

	public ComboBox getCity() {
		return city;
	}

	public void setCity(ComboBox city) {
		this.city = city;
	}

	public TextField getAdcontact() {
		return adcontact;
	}

	public void setAdcontact(TextField adcontact) {
		this.adcontact = adcontact;
	}

	public ComboBox getContacttype() {
		return contacttype;
	}

	public void setContacttype(ComboBox contacttype) {
		this.contacttype = contacttype;
	}

	public TextField getPostalCode() {
		return postalCode;
	}

	public void setPostalCode(TextField postalCode) {
		this.postalCode = postalCode;
	}

	public TextField getRegion() {
		return region;
	}

	public void setRegion(TextField region) {
		this.region = region;
	}

	public TextArea getAddress() {
		return address;
	}

	public void setAddress(TextArea address) {
		this.address = address;
	}

	public BeanFieldGroup<Address_Entity> getAddressfieldGroup() {
		return AddressfieldGroup;
	}

	public void setAddressfieldGroup(BeanFieldGroup<Address_Entity> addressfieldGroup) {
		AddressfieldGroup = addressfieldGroup;
	}

	public BeanFieldGroup<Contact_Entity> getContactfieldGroup() {
		return ContactfieldGroup;
	}

	public void setContactfieldGroup(BeanFieldGroup<Contact_Entity> contactfieldGroup) {
		ContactfieldGroup = contactfieldGroup;
	}
}
