package com.smartera3s.nasec.controllers;

import com.smartera3s.nasec.listeners.InvestigationListener;
import com.smartera3s.nasec.screens.Investigation.InvestigationScreen;
import com.vaadin.ui.CustomComponent;

public class InvestigationController implements UIController {
    public static final String VIEW_NAME = "Investigation Service";
    private InvestigationScreen screen;
    private InvestigationListener eventListener;
    public InvestigationController() {
        eventListener = new InvestigationListener(this);
       screen = new InvestigationScreen(eventListener);
    }
    @Override
    public CustomComponent getView() {
        // TODO Auto-generated method stub
        return screen;
    }
    @Override
    public void setNotification(String msg) {
        // TODO Auto-generated method stub
        
    }

}
