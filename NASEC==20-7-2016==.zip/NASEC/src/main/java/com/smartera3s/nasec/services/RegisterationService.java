package com.smartera3s.nasec.services;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

import com.smartera3s.nasec.model.Company_Contanier;
import com.smartera3s.nasec.model.Relation_Container;
import com.smartera3s.nasec.model.entities.Address_Entity;
import com.smartera3s.nasec.model.entities.CityEntity;
import com.smartera3s.nasec.model.entities.Company_Entity;
import com.smartera3s.nasec.model.entities.Companyrelationtype;
import com.smartera3s.nasec.model.entities.ContactTypeEntity;
import com.smartera3s.nasec.model.entities.Contact_Entity;
import com.smartera3s.nasec.model.entities.CountryEntity;
import com.smartera3s.nasec.model.entities.MstatusEntity;
import com.smartera3s.nasec.model.entities.PatientCompany;
import com.smartera3s.nasec.model.entities.PatientCompanyPK;
import com.smartera3s.nasec.model.entities.PatientRelation;
import com.smartera3s.nasec.model.entities.PatientRelationPK;
import com.smartera3s.nasec.model.entities.Patient_Entity;
import com.smartera3s.nasec.model.entities.Patientidtype;
import com.smartera3s.nasec.model.entities.Relation;
import com.smartera3s.nasec.screens.reg.RegisterationScreen;
import com.vaadin.addon.jpacontainer.JPAContainer;
import com.vaadin.addon.jpacontainer.JPAContainerFactory;
import com.vaadin.data.Container.Filter;
import com.vaadin.data.util.BeanItem;
import com.vaadin.data.util.filter.Compare;





public class RegisterationService {
    EntityManagerFactory emf = Persistence.createEntityManagerFactory("NASEC");
    public EntityManager EntityManager = emf.createEntityManager();
    
    
    public Patient_Entity createPatient(BeanItem<Patient_Entity> patientItem,RegisterationScreen screen) {
        JPAContainer<Patient_Entity> PatientContainer =  JPAContainerFactory.make(Patient_Entity.class, "NASEC");
        
        Patient_Entity Patient = new Patient_Entity();
        Object  PatientItem= PatientContainer.addEntity(patientItem.getBean());
        Patient=PatientContainer.getItem(PatientItem).getEntity();

        
        System.out.println(Patient.getId()+"=========");
        System.out.println("Patient Done");
        
        return Patient;
            
    }
    public Patient_Entity createPatient2(RegisterationScreen screen ,BeanItem<Relation_Container> relationBeanItem) {
        JPAContainer<Patient_Entity> PatientContainer =  JPAContainerFactory.make(Patient_Entity.class, "NASEC");
        Relation_Container Container = relationBeanItem.getBean();
        Patient_Entity Patient = new Patient_Entity();
        Patient.setFirst_name(Container.getFirst());
        Patient.setSecond_name(Container.getSecond());
        Patient.setLast_name(Container.getLast());
       

        Object  PatientItem= PatientContainer.addEntity(Patient);
        Patient=PatientContainer.getItem(PatientItem).getEntity();
        
        System.out.println(Patient.getId()+"=========");
        System.out.println("Patient2 Done");
        
        return Patient;
            
    }
    public Contact_Entity createContact(Patient_Entity Patient, BeanItem<Contact_Entity> ContactBeanItem) {
        JPAContainer<Contact_Entity> ContactContainer =  JPAContainerFactory.make(Contact_Entity.class, "NASEC");
        Contact_Entity Contact = ContactBeanItem.getBean();

        Contact.setPatientId(Patient.getId());
        
        Object  ContactItem= ContactContainer.addEntity(Contact);
        Contact=ContactContainer.getItem(ContactItem).getEntity();
        
        return Contact;
    }
    public Address_Entity createAddress(Patient_Entity Patient,BeanItem<Address_Entity> addressItem) {
        JPAContainer<Address_Entity> AddressContainer =  JPAContainerFactory.make(Address_Entity.class, "NASEC");
        
        Address_Entity Address = new Address_Entity();
        Address.setAddress(addressItem.getBean().getAddress());
        if (addressItem.getBean().getCity() != null) {
        Address.setCity(addressItem.getBean().getCity().toString());}
        if (addressItem.getBean().getCountry() != null) {
        Address.setCountry(addressItem.getBean().getCountry().toString());}
        Address.setPostal_code(addressItem.getBean().getPostal_code());
        Address.setRegion(addressItem.getBean().getRegion());
        Address.setPatient_id(Patient.getId());
        
        Object  AddressItem= AddressContainer.addEntity(Address);
        Address=AddressContainer.getItem(AddressItem).getEntity();
        
        return Address;
    }
    public PatientRelation createPatientRelation(Patient_Entity Patient1,Patient_Entity Patient2,Relation Relation) {
        JPAContainer<PatientRelation> PatientRelationContainer =  JPAContainerFactory.make(PatientRelation.class, "NASEC");
        
        PatientRelation PatientRelation=new PatientRelation();
        PatientRelationPK id=new PatientRelationPK();
        id.setPatient1_id(Patient1.getId());
        id.setPatient2_id(Patient2.getId());
        id.setRelation_id(Relation.getId());
        PatientRelation.setId(id);
        
        PatientRelationContainer.addEntity(PatientRelation);
        
        return PatientRelation;
    }
    public Company_Entity createCompany(RegisterationScreen screen,BeanItem<Company_Contanier> companyBeanItem) {
        JPAContainer<Company_Entity> CompanyContainer =  JPAContainerFactory.make(Company_Entity.class, "NASEC");
        Company_Contanier contanier = companyBeanItem.getBean();
        Company_Entity Company=new Company_Entity();
        Company.setContact(contanier.getContact());
        Company.setName(contanier.getName());
        
        Object  CompanyItem= CompanyContainer.addEntity(Company);
        Company=CompanyContainer.getItem(CompanyItem).getEntity();
        
        return Company;
    }  
    public PatientCompany createPatientCompany(Patient_Entity Patient,Company_Entity Company,BeanItem<Company_Contanier> companyBeanItem) {
        JPAContainer<PatientCompany> PatientCompanyContainer =  JPAContainerFactory.make(PatientCompany.class, "NASEC");
        Company_Contanier contanier = companyBeanItem.getBean();
        PatientCompany PatientCompany=new PatientCompany();
        PatientCompanyPK id = new PatientCompanyPK();
        id.setCompany_id(Company.getId());
        id.setPatient_id(Patient.getId());
        PatientCompany.setId(id);
        PatientCompany.setInsurance_number(contanier.getInsurance_number());
        PatientCompany.setRelation_type(contanier.getRelation_type());
        
        PatientCompanyContainer.addEntity(PatientCompany);
        
        return PatientCompany;
    }
//====================Update=================================//
  
    public Patient_Entity updatePatient(Patient_Entity Patient,BeanItem<Patient_Entity> patientItem ,RegisterationScreen screen) {
        JPAContainer<Patient_Entity> PatientContainer =  JPAContainerFactory.make(Patient_Entity.class, "NASEC");
        Filter filter = new Compare.Equal("id", Patient.getId());

        PatientContainer.addContainerFilter(filter);
        
        Patient.setFirst_name(patientItem.getBean().getFirst_name());
        Patient.setSecond_name(patientItem.getBean().getSecond_name());
        Patient.setLast_name(patientItem.getBean().getLast_name());
        Patient.setDob(patientItem.getBean().getDob());
        Patient.setId_type(patientItem.getBean().getId_type());
        Patient.setIdNumber(patientItem.getBean().getIdNumber());
        if (patientItem.getBean().getGender() != null
                && patientItem.getBean().getGender().equals("Male")) {
            Patient.setGender("Male");
        } else if (patientItem.getBean().getGender() != null
                && patientItem.getBean().getGender().equals("Female")) {
            Patient.setGender("Female");
        }
        if (patientItem.getBean().getPayment_method() != null
                && patientItem.getBean().getPayment_method().equals("Cash")) {
            Patient.setPayment_method("Cash");
        } else if (patientItem.getBean().getPayment_method() != null
                && patientItem.getBean().getPayment_method().equals("Credit")) {
            Patient.setPayment_method("Credit");
        }
        if (patientItem.getBean().getNationality() != null) {
        Patient.setNationality(patientItem.getBean().getNationality().toString());}
        if (patientItem.getBean().getMartial_status() != null) {
        Patient.setMartial_status(patientItem.getBean().getMartial_status().toString());}
        
            Patient.setProfile_pic(patientItem.getBean().getProfile_pic());
        
        
        System.out.println(Patient.getId()+"=========");
        System.out.println("Patient Edit Done");
        PatientContainer.addEntity(Patient);
        
        return Patient;

    }
    public Contact_Entity updateContact(Patient_Entity Patient, BeanItem<Contact_Entity> ContactBeanItem) {
        JPAContainer<Contact_Entity> ContactContainer =  JPAContainerFactory.make(Contact_Entity.class, "NASEC");

        Contact_Entity Contact = ContactBeanItem.getBean();

        Contact.setPatientId(Patient.getId());
         
         ContactContainer.addEntity(ContactBeanItem.getBean());
         return ContactBeanItem.getBean();
     }

    public Address_Entity updateAddress(Patient_Entity Patient,  Address_Entity Address, BeanItem<Address_Entity> addressItem) {
        JPAContainer<Address_Entity> AddressContainer =  JPAContainerFactory.make(Address_Entity.class, "NASEC");
        
        Filter filter = new Compare.Equal("patient_id", Patient.getId());
        
        AddressContainer.addContainerFilter(filter);
        Address.setAddress(addressItem.getBean().getAddress());
        if (addressItem.getBean().getCity() != null) {
        Address.setCity(addressItem.getBean().getCity().toString());}
        if (addressItem.getBean().getCountry() != null) {
        Address.setCountry(addressItem.getBean().getCountry().toString());}
        Address.setPostal_code(addressItem.getBean().getPostal_code());
        Address.setRegion(addressItem.getBean().getRegion());

        AddressContainer.addEntity(Address);

        return Address;
 
    }  
    @SuppressWarnings("unchecked")
    public List<Patientidtype> findAllIDTypes() {
       
        Query query = EntityManager.createQuery("SELECT p FROM Patientidtype p");
       
        return (List<Patientidtype>) query.getResultList();
      }
    
    @SuppressWarnings("unchecked")
    public List<CountryEntity> findAllCountries() {
       
        Query query = EntityManager.createQuery("SELECT c.countries FROM CountryEntity c");
       
        return (List<CountryEntity>) query.getResultList();
      }
    @SuppressWarnings("unchecked")
      public List<MstatusEntity> findAllStatus() {
          
          Query query = EntityManager.createQuery("SELECT m.status FROM MstatusEntity m");
          return (List<MstatusEntity>) query.getResultList();
        }
    @SuppressWarnings("unchecked")
    public List<CityEntity> findAllCity() {
        
        Query query = EntityManager.createQuery("SELECT c.city FROM CityEntity c");
        return (List<CityEntity>) query.getResultList();
      }
    @SuppressWarnings("unchecked")
    public List<ContactTypeEntity> findAlltype() {
        
        Query query = EntityManager.createQuery("SELECT c.contactType FROM ContactTypeEntity c");
        return (List<ContactTypeEntity>) query.getResultList();
      }
    @SuppressWarnings("unchecked")
    public List<Relation> findAllRtype() {
        
        Query query = EntityManager.createQuery("SELECT r.relation_type FROM Relation r");
        return (List<Relation>) query.getResultList();
      }
    
    @SuppressWarnings("unchecked")
    public List<Companyrelationtype> findAllCompanyTypes() {
       
        Query query = EntityManager.createQuery("SELECT c FROM Companyrelationtype c");
       
        return (List<Companyrelationtype>) query.getResultList();
      }
    
    public int findRtypeid(String type) {
        
        Query query = EntityManager.createQuery("SELECT r.id FROM Relation r WHERE r.relation_type=:type").setParameter("type", type);
        return (int) query.getSingleResult();
      }
    public List<Integer> Search_contact(int ID){
        
        List<Integer> results = EntityManager.createNativeQuery("select c.id from contact c join patient p on p.id=c.patient_id where p.id = ?").setParameter(1, ID).getResultList();
          return results;
 }
    public List<Object[]> findPatient_Relation(int patientId) {
        Query q=EntityManager.createNativeQuery("SELECT * FROM Patient_Relation WHERE Patient1_id= ?" );
        q.setParameter(1,patientId);
        List<Object[]> results = q.getResultList();
        
              return results;
    }
    
    public void removeContact(int id) {
        Contact_Entity c = findContact(id);
        if (c != null) {
            EntityManager.remove(c);
        }
      }
    public void removePatientCompany(int patientid,int companyid) {
        PatientCompany c = findPatientCompanybyid(patientid,companyid);
        if (c != null) {
            EntityManager.remove(c);
        }
      }
    public Contact_Entity findContact(int id) {
        
              return EntityManager.find(Contact_Entity.class, id);
   }
    public List<Object[]> findPatient_Company(int patientId) {
        List<Object[]> results = EntityManager.createNativeQuery("SELECT * FROM Patient_Company WHERE Patient_id=?" ).setParameter(1, patientId).getResultList();
        
              return results;
    }
    public PatientCompany findPatientCompanybyid(int patientid,int companyid) {
        PatientCompanyPK PatientCompany=new PatientCompanyPK();
        PatientCompany.setPatient_id(patientid);
        PatientCompany.setCompany_id(companyid);
              return EntityManager.find(PatientCompany.class, PatientCompany);
    }
    public void removeRelation(int patientID) {
        
        List<Object[]> c = findPatient_Relation(patientID);
        for(int i = 0;i<c.size();i++){
            
            PatientRelation PatientRelation= findPatientRelationbyid(Integer.parseInt(c.get(i)[0].toString()),Integer.parseInt(c.get(i)[1].toString()),Integer.parseInt(c.get(i)[2].toString()));
            if (PatientRelation != null) {
                EntityManager.remove(PatientRelation);
            }
            List<Integer> l=Search_contact(Integer.parseInt(c.get(i)[1].toString()));
            for(int j=0;j<l.size();j++){
                removeContact(l.get(j));
                
            }
            removePatient(Integer.parseInt(c.get(i)[1].toString()));

         }
    }
    public PatientRelation findPatientRelationbyid(int p1,int p2,int r) {
        PatientRelationPK pr=new PatientRelationPK();
        pr.setPatient1_id(p1);
        pr.setPatient2_id(p2);
        pr.setRelation_id(r);
              return EntityManager.find(PatientRelation.class, pr);
    }
    public void removePatient(int patientID) {
        Patient_Entity Patient = findPatient(patientID);
        if (Patient != null) {
            EntityManager.remove(Patient);
        }
      }
    public Patient_Entity findPatient(int id) {
        return EntityManager.find(Patient_Entity.class, id);
      }
    
    

}
