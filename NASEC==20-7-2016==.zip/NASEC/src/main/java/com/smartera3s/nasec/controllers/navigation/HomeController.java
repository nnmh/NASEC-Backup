package com.smartera3s.nasec.controllers.navigation;

import com.smartera3s.nasec.controllers.PatientSearchController;
import com.smartera3s.nasec.controllers.RegisterationController;
import com.smartera3s.nasec.controllers.UIController;
import com.smartera3s.nasec.screens.templateLayouts.HomeScreen;
import com.vaadin.ui.CustomComponent;

public class HomeController implements UIController {
	private PatientSearchController patientSearchController;
	private RegisterationController registerationController;

	private HomeScreen screen; // View

	public HomeController() {
		screen = new HomeScreen();
		patientSearchController = new PatientSearchController(this);
		registerationController = new RegisterationController();
		init();
	}

	public void init(){
		screen.getBody().removeAllComponents();
		screen.getBody().addComponent(patientSearchController.getView());
	}
	private void refreshBody() {
		
	}

	private void refreshMenu() {

	}

	// Controllers Common function
	@Override
	public CustomComponent getView() {
		return screen;
	}

	@Override
	public void setNotification(String msg) {
		// TODO Auto-generated method stub

	}
}
