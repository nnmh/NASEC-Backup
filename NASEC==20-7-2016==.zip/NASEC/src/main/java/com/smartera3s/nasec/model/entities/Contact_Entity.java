package com.smartera3s.nasec.model.entities;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the contact database table.
 * 
 */
@Entity
@Table(name="contact")
@NamedQuery(name="Contact_Entity.findAll", query="SELECT c FROM Contact_Entity c")
public class Contact_Entity implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int id;

	private String contact_type;

	@Column(name="patient_id")
	private int patientId;

	@Column(name="PRIMARY_CONTACT")
	private boolean primaryContact;

	private String value;

	public Contact_Entity() {
	}
	public Contact_Entity(String contact_type,String value,boolean primaryContact) {
	    this.value = value;
	    this.contact_type = contact_type;
	    this.primaryContact = primaryContact;
        }

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getContact_type() {
		return this.contact_type;
	}

	public void setContact_type(String contact_type) {
		this.contact_type = contact_type;
	}

	public int getPatientId() {
		return this.patientId;
	}

	public void setPatientId(int patientId) {
		this.patientId = patientId;
	}

	public boolean getPrimaryContact() {
		return this.primaryContact;
	}

	public void setPrimaryContact(boolean primaryContact) {
		this.primaryContact = primaryContact;
	}

	public String getValue() {
		return this.value;
	}

	public void setValue(String value) {
		this.value = value;
	}
    @Override
    public String toString() {
        return this.contact_type+"::"+this.value;
    }

}