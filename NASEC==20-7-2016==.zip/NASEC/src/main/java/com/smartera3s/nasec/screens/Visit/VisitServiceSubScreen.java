package com.smartera3s.nasec.screens.Visit;

import static com.smartera3s.nasec.controllers.VisitController.VISITTYPE;
import static com.smartera3s.nasec.controllers.PatientSearchController.PATIENT_NAME;
import static com.smartera3s.nasec.controllers.VisitController.VISITDATE;
import static com.smartera3s.nasec.controllers.RegisterationController.PRIMARY_CONTACT;
import static com.smartera3s.nasec.controllers.PatientSearchController.PATIENT_ID;
import static com.smartera3s.nasec.controllers.VisitController.DESCRIPTION;
import static com.smartera3s.nasec.controllers.VisitController.VISITPAYMENT;
import static com.smartera3s.utils.InternationalizationFileBundle.CAPTIONS;
import static com.smartera3s.utils.InternationalizationFileBundle.MSGS;
import static com.smartera3s.utils.InternationalizationFileBundle.getBundleValue;

import java.io.File;
import java.util.List;

import com.smartera3s.nasec.listeners.VisitScreenListener;
import com.smartera3s.nasec.model.entities.Device;
import com.smartera3s.nasec.model.entities.Operationlist;
import com.smartera3s.nasec.model.entities.Payment_Entity;
import com.smartera3s.nasec.model.entities.Staff_Entity;
import com.smartera3s.nasec.model.entities.VisitType_Entity;
import com.smartera3s.nasec.model.entities.VisitEntity;
import com.smartera3s.nasec.services.VisitServices;

import com.vaadin.data.fieldgroup.BeanFieldGroup;
import com.vaadin.data.fieldgroup.PropertyId;
import com.vaadin.data.util.BeanItem;
import com.vaadin.data.util.BeanItemContainer;
import com.vaadin.server.FileResource;
import com.vaadin.server.Responsive;
import com.vaadin.server.ThemeResource;
import com.vaadin.ui.ComboBox;
import com.vaadin.ui.CssLayout;
import com.vaadin.ui.DateField;
import com.vaadin.ui.HorizontalLayout;
import com.vaadin.ui.Image;
import com.vaadin.ui.Label;
import com.vaadin.ui.Layout;
import com.vaadin.ui.TextArea;
import com.vaadin.ui.VerticalLayout;
import com.vaadin.ui.themes.ValoTheme;

@SuppressWarnings("serial")
public class VisitServiceSubScreen extends CssLayout {
	@PropertyId("fullname")
	private Label patientName;
	@PropertyId("patientID")
	private Label patientID;

	// Image
	private File file; // File to write to.
	private Image myLocalImage;
	private FileResource resource;
	// ComboBoxs
	@PropertyId("linkedVisitType")
	private ComboBox visitType;
	@PropertyId("linkedResource")
	private ComboBox visitTo;
	@PropertyId("linkedPayment")
	private ComboBox payment;

	// Labels
	private Label visittitle;

	// TextArea
	@PropertyId("description")
	private TextArea description;

	// date Fields
	@PropertyId("vistsDateTime")
	private DateField dob;

	// Layouts
	private Layout layoutFields;
	private Layout layoutVisit;
	private Layout layoutVisitInputs1;
	private Layout layoutVisitInputs2;
	private Layout layoutNameInputs;
	private Layout layoutInputs;
	private Layout layoutNameInputsandID;

	//Service Lists
	private List<VisitType_Entity> VisitList;
	private List<Staff_Entity> DoctorList;
	private List<Device> DevicesList;
	private List<Operationlist> operationtList;
	private List<Payment_Entity> PaymenttList;
	
	//Binding Group
	private BeanFieldGroup<VisitEntity> VisitfieldGroup;
	
	private VisitScreenListener eventsListener;
	private VisitServices Service;

	public VisitServiceSubScreen(BeanItem<VisitEntity> visitItem, VisitScreenListener listener) {
		Service = new VisitServices();
		this.eventsListener = listener;
		VisitList = Service.findAlltype();
		DoctorList = Service.findName(1);
		DevicesList = Service.findAllDevices();
		operationtList = Service.findAllOperationList();
		PaymenttList = Service.findAllPayment();

		addLayouts();
		addVisitFieldGroup(visitItem);
	}

	private void addLayouts() {

		layoutFields = new CssLayout();
		layoutFields.setSizeFull();
		Responsive.makeResponsive(layoutFields);

		layoutNameInputsandID = new CssLayout();
		layoutNameInputsandID.setSizeUndefined();
		layoutNameInputsandID.setStyleName("Patient-name-and-id-style");

		/// Image,Patient Name and ID.
		layoutNameInputs = new CssLayout();
		layoutNameInputs.setSizeUndefined();

		// Visit Header
		layoutVisit = new HorizontalLayout();
		layoutVisit.setSizeFull();

		layoutVisitInputs1 = new CssLayout();
		layoutVisitInputs1.setSizeUndefined();

		layoutVisitInputs2 = new HorizontalLayout();
		layoutVisitInputs2.setSizeUndefined();

		layoutInputs = new VerticalLayout();
		layoutInputs.setSizeUndefined();
		layoutInputs.setStyleName("visit-and-payment-type-style");

		addComponent(layoutFields);
		fillFields(layoutFields);
	}

	private void fillFields(Layout mainLayout) {
		patientName = createPatientName();
		patientID = createID();
		myLocalImage = createImage();

		visitType = createvisitType();
		visitType.setItemCaptionPropertyId("displayName");

		HorizontalLayout visitTypeLayout = new HorizontalLayout();
		HorizontalLayout visitToLayout = new HorizontalLayout();
		HorizontalLayout descriptionLayout = new HorizontalLayout();
		HorizontalLayout dobLayout = new HorizontalLayout();

		HorizontalLayout paymentLayout = new HorizontalLayout();

		visittitle = createVisitTitle();
		visitTo = createvisitTO();
		payment = createPayment();
		description = createDescription();
		dob = createDOB();
		layoutNameInputs.addComponent(patientName);
		layoutNameInputs.addComponent(patientID);

		layoutNameInputsandID.addComponent(myLocalImage);
		layoutNameInputsandID.addComponent(layoutNameInputs);

		layoutNameInputsandID.setStyleName("Patient-name-and-id-style");
		layoutVisit.addComponent(visittitle);

		visitTypeLayout.addComponent(visitType);
		visitToLayout.addComponent(visitTo);
		paymentLayout.addComponent(payment);
		dobLayout.addComponent(dob);
		descriptionLayout.addComponent(description);

		layoutVisitInputs1.addComponent(visitTypeLayout);
		layoutVisitInputs1.addComponent(visitToLayout);
		layoutVisitInputs1.addComponent(paymentLayout);
		layoutVisitInputs1.addComponent(dobLayout);
		layoutVisitInputs1.addComponent(descriptionLayout);

		layoutInputs.addComponent(layoutVisitInputs1);
		layoutInputs.addComponent(layoutVisitInputs2);
		layoutInputs.setStyleName("visit-and-payment-type-style");
		mainLayout.addComponent(layoutNameInputsandID);
		// mainLayout.addComponent(layoutVisit);
		mainLayout.addComponent(layoutInputs);
	}

	private Label createVisitTitle() {
		visittitle = new Label("Visit Services");
		visittitle.setStyleName(ValoTheme.LABEL_H2);

		return visittitle;
	}

	private Image createImage() {

		myLocalImage = new Image("", new ThemeResource("img/profileimage.PNG"));
		myLocalImage.setStyleName("user-menu-visit");
		return myLocalImage;

	}

	private Label createPatientName() {
		patientName = new Label();
		patientName.setStyleName(ValoTheme.TEXTFIELD_LARGE);
		patientName.setId(PATIENT_NAME);
		patientName.setDescription(getBundleValue(MSGS, PATIENT_NAME));
		patientName.setValue(getBundleValue(CAPTIONS, PATIENT_NAME));

		return patientName;
	}

	private Label createID() {
		patientID = new Label();
		patientID.setStyleName(ValoTheme.LABEL_H2);
		patientID.setStyleName(ValoTheme.TEXTFIELD_LARGE);
		patientID.setId(PATIENT_ID);
		patientID.setValue(getBundleValue(CAPTIONS, PATIENT_ID));
		patientID.setDescription(getBundleValue(MSGS, PATIENT_ID));
		patientID.setEnabled(false);
		patientID.setReadOnly(true);

		return patientID;
	}

	public Label getPatientName() {
		return patientName;
	}

	public void setPatientName(Label patientName) {
		this.patientName = patientName;
	}

	private ComboBox createvisitType() {
		ComboBox Type = new ComboBox();
		Type.setStyleName(ValoTheme.TEXTFIELD_LARGE);
		Type.setCaption(getBundleValue(CAPTIONS, VISITTYPE));
		Type.setId(VISITTYPE);
		Type.setNullSelectionItemId(getBundleValue(MSGS, VISITTYPE));
		Type.setInputPrompt(getBundleValue(MSGS, VISITTYPE));
		Type.setDescription(getBundleValue(MSGS, VISITTYPE));
		Type.setContainerDataSource(new BeanItemContainer<VisitType_Entity>(VisitType_Entity.class, VisitList));
		Type.addValueChangeListener(eventsListener);
		return Type;
	}

	private ComboBox createvisitTO() {
		ComboBox visitTO = new ComboBox();
		visitTO.setStyleName(ValoTheme.TEXTFIELD_LARGE);
		visitTO.setCaption(getBundleValue(CAPTIONS, VISITTYPE));
		visitTO.setId(VISITTYPE);
		visitTO.setNullSelectionItemId(getBundleValue(MSGS, VISITTYPE));
		visitTO.setInputPrompt(getBundleValue(MSGS, VISITTYPE));
		visitTO.setDescription(getBundleValue(MSGS, VISITTYPE));
		visitTO.setItemCaptionPropertyId("displayName");
		// visitTO.setVisible(false);

		return visitTO;
	}

	private ComboBox createPayment() {
		ComboBox payment = new ComboBox();
		payment.setStyleName(ValoTheme.TEXTFIELD_LARGE);
		payment.setCaption(getBundleValue(CAPTIONS, VISITPAYMENT));
		payment.setId(VISITPAYMENT);
		payment.setNullSelectionItemId(getBundleValue(MSGS, VISITPAYMENT));
		payment.setInputPrompt(getBundleValue(MSGS, VISITPAYMENT));
		payment.setDescription(getBundleValue(MSGS, VISITPAYMENT));
		payment.setContainerDataSource(new BeanItemContainer<Payment_Entity>(Payment_Entity.class, PaymenttList));
		payment.setItemCaptionPropertyId("displayName");

		return payment;
	}

	private DateField createDOB() {
		dob = new DateField();
		dob.setStyleName(ValoTheme.DATEFIELD_LARGE);
		dob.setCaption(getBundleValue(CAPTIONS, VISITDATE));
		dob.setId(PRIMARY_CONTACT);

		return dob;
	}

	private TextArea createDescription() {
		description = new TextArea();
		description.setStyleName(ValoTheme.TEXTFIELD_LARGE);
		description.setId(DESCRIPTION);
		description.setCaption(getBundleValue(CAPTIONS, DESCRIPTION));
		description.setInputPrompt(getBundleValue(CAPTIONS, DESCRIPTION));
		description.setNullRepresentation("");

		return description;
	}

	private void addVisitFieldGroup(BeanItem<VisitEntity> visitItem) {
		VisitfieldGroup = new BeanFieldGroup<VisitEntity>(VisitEntity.class);
		VisitfieldGroup.setBuffered(false);// not to depend on commitss
		VisitfieldGroup.setItemDataSource(visitItem);
		VisitfieldGroup.bindMemberFields(this);
	}

	public BeanFieldGroup<VisitEntity> getVisitfieldGroup() {
		return VisitfieldGroup;
	}

	public void setVisitfieldGroup(BeanFieldGroup<VisitEntity> visitfieldGroup) {
		VisitfieldGroup = visitfieldGroup;
	}

	public Label getPatientID() {
		return patientID;
	}

	public void setPatientID(Label patientID) {
		this.patientID = patientID;
	}

	public FileResource getResource() {
		return resource;
	}

	public void setResource(FileResource resource) {
		this.resource = resource;
	}

    public List<VisitType_Entity> getVisitList() {
        return VisitList;
    }

    public void setVisitList(List<VisitType_Entity> visitList) {
        VisitList = visitList;
    }

    public List<Staff_Entity> getDoctorList() {
        return DoctorList;
    }

    public void setDoctorList(List<Staff_Entity> doctorList) {
        DoctorList = doctorList;
    }

    public List<Device> getDevicesList() {
        return DevicesList;
    }

    public void setDevicesList(List<Device> devicesList) {
        DevicesList = devicesList;
    }

    public List<Payment_Entity> getPaymenttList() {
        return PaymenttList;
    }

    public void setPaymenttList(List<Payment_Entity> paymenttList) {
        PaymenttList = paymenttList;
    }

    public List<Operationlist> getOperationtList() {
        return operationtList;
    }

    public void setOperationtList(List<Operationlist> operationtList) {
        this.operationtList = operationtList;
    }

    public File getFile() {
        return file;
    }

    public void setFile(File file) {
        this.file = file;
    }

    public Image getMyLocalImage() {
        return myLocalImage;
    }

    public void setMyLocalImage(Image myLocalImage) {
        this.myLocalImage = myLocalImage;
    }

    public ComboBox getVisitType() {
        return visitType;
    }

    public void setVisitType(ComboBox visitType) {
        this.visitType = visitType;
    }

    public ComboBox getVisitTo() {
        return visitTo;
    }

    public void setVisitTo(ComboBox visitTo) {
        this.visitTo = visitTo;
    }

    public ComboBox getPayment() {
        return payment;
    }

    public void setPayment(ComboBox payment) {
        this.payment = payment;
    }

}
