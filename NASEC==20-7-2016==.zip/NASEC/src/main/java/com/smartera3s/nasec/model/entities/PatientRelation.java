package com.smartera3s.nasec.model.entities;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the patient_relation database table.
 * 
 */
@Entity
@Table(name="patient_relation")
@NamedQuery(name="PatientRelation.findAll", query="SELECT p FROM PatientRelation p")
public class PatientRelation implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private PatientRelationPK id;

	public PatientRelation() {
	}

	public PatientRelationPK getId() {
		return this.id;
	}

	public void setId(PatientRelationPK id) {
		this.id = id;
	}

}