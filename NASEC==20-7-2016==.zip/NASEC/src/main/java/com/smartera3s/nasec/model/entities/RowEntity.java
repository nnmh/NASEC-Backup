package com.smartera3s.nasec.model.entities;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the rows database table.
 * 
 */
@Entity
@Table(name="rows")
@NamedQuery(name="RowEntity.findAll", query="SELECT r FROM RowEntity r")
public class RowEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int rowid;

	private String formId;

	private String name;

	public RowEntity() {
	}

	public int getRowid() {
		return this.rowid;
	}

	public void setRowid(int rowid) {
		this.rowid = rowid;
	}

	public String getFormId() {
		return this.formId;
	}

	public void setFormId(String formId) {
		this.formId = formId;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

}