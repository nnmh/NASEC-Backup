package com.smartera3s.nasec.screens.reg;

import static com.smartera3s.nasec.controllers.RegisterationController.ADDCCCC;
import static com.smartera3s.nasec.controllers.RegisterationController.COMPANYR;
import static com.smartera3s.nasec.controllers.RegisterationController.COMPANY_NAME;
import static com.smartera3s.nasec.controllers.RegisterationController.CONTACT;
import static com.smartera3s.nasec.controllers.RegisterationController.INSURANCE_NUMBER;
import static com.smartera3s.utils.InternationalizationFileBundle.CAPTIONS;
import static com.smartera3s.utils.InternationalizationFileBundle.MSGS;
import static com.smartera3s.utils.InternationalizationFileBundle.getBundleValue;

import java.util.List;

import com.smartera3s.nasec.listeners.RegisterationScreenListener;
import com.smartera3s.nasec.model.Company_Contanier;
import com.smartera3s.nasec.model.entities.Address_Entity;
import com.smartera3s.nasec.model.entities.Company_Entity;
import com.smartera3s.nasec.model.entities.Companyrelationtype;
import com.smartera3s.nasec.model.entities.Contact_Entity;
import com.smartera3s.nasec.model.entities.PatientCompany;
import com.smartera3s.nasec.services.RegisterationService;
import com.vaadin.data.fieldgroup.BeanFieldGroup;
import com.vaadin.data.fieldgroup.PropertyId;
import com.vaadin.data.util.BeanItem;
import com.vaadin.data.util.BeanItemContainer;
import com.vaadin.ui.AbstractOrderedLayout;
import com.vaadin.ui.Button;
import com.vaadin.ui.ComboBox;
import com.vaadin.ui.CssLayout;
import com.vaadin.ui.HorizontalLayout;
import com.vaadin.ui.Label;
import com.vaadin.ui.Layout;
import com.vaadin.ui.Table;
import com.vaadin.ui.TextField;
import com.vaadin.ui.VerticalLayout;
import com.vaadin.ui.Button.ClickEvent;
import com.vaadin.ui.themes.ValoTheme;

public class RegisterationCompanySubScreen extends CssLayout {



	// Labels
	private Label Company;

	// TextFields
	@PropertyId("name")
	private TextField companyName;
	@PropertyId("insurance_number")
	private TextField insuranceNumber;
	@PropertyId("contact")
	private TextField companyContact;

	// Layouts
	private Layout layoutRelationTabInputs5;
	private Layout layoutRelationTabInputs6;
	private Layout layoutRelationTabInputs7;
	private Layout layoutRelationTabInputs8;
	private Layout layoutmainFields;
        private Layout Container;
        
	// ComboBox
	@PropertyId("linkedType")
	private ComboBox companyRType;

	

	// Buttons
	private Button addCompany2;

	// Tables
	private Table companies;
	
	//Service Lists
	private List<Companyrelationtype> TypetList;

	private BeanFieldGroup<Company_Entity> CompanyfieldGroup;
	private BeanFieldGroup<PatientCompany> PatientCompanyfieldGroup;

	private RegisterationScreenListener eventsListener;
	private RegisterationService Service;

	public RegisterationCompanySubScreen(BeanItem<Company_Entity> CompanyItem,
			BeanItem<PatientCompany> PatientCompanyItem, RegisterationScreenListener listener) {
		Service = new RegisterationService();

		TypetList = Service.findAllCompanyTypes();

		this.eventsListener = listener;

		addLayouts();
		addCompanyFieldGroup(CompanyItem);
		addPatientCompanyFieldGroup(PatientCompanyItem);
	}

	public void addLayouts() {
		layoutmainFields = new VerticalLayout();
		layoutmainFields.setSizeUndefined();
		layoutmainFields.setStyleName("SubScreen-style");

		Container = new VerticalLayout();
		Container.setSizeUndefined();
		Container.setStyleName("SubScreen-tab");
		
		layoutRelationTabInputs5 = new HorizontalLayout();
		layoutRelationTabInputs5.setSizeUndefined();
		layoutRelationTabInputs5.setStyleName("padding-style");

		layoutRelationTabInputs6 = new HorizontalLayout();
		layoutRelationTabInputs6.setSizeUndefined();
		layoutRelationTabInputs6.setStyleName("padding-style");

		layoutRelationTabInputs7 = new HorizontalLayout();
		layoutRelationTabInputs7.setSizeUndefined();
		layoutRelationTabInputs7.setStyleName("padding-style");

		layoutRelationTabInputs8 = new HorizontalLayout();
		layoutRelationTabInputs8.setSizeUndefined();

		fillFields(layoutmainFields);
		addComponent(layoutmainFields);
	}

	private void fillFields(Layout mainLayout) {

		Company = createCompany();
		companyRType = createCompanyR();
		insuranceNumber = createInsurance();
		companyName = createCompanyName();
		companyContact = createCompanyContact();
		addCompany2 = createCompanyButton();

		layoutmainFields.addComponent(Company);
		Container.addComponent(layoutRelationTabInputs5);
		Container.addComponent(layoutRelationTabInputs6);
		Container.addComponent(layoutRelationTabInputs7);
		Container.addComponent(layoutRelationTabInputs8);
		mainLayout.addComponent(Container);

		layoutRelationTabInputs6.addComponent(companyName);
		layoutRelationTabInputs6.addComponent(insuranceNumber);
		layoutRelationTabInputs6.addComponent(companyContact);
		layoutRelationTabInputs7.addComponent(companyRType);
		layoutRelationTabInputs7.addComponent(addCompany2);
		companies = fillCompanyTable(companies);
		layoutRelationTabInputs8.addComponent(companies);

		((AbstractOrderedLayout) layoutRelationTabInputs5).setSpacing(true);
		((AbstractOrderedLayout) layoutRelationTabInputs6).setSpacing(true);
		((AbstractOrderedLayout) layoutRelationTabInputs7).setSpacing(true);
	}

	private Table fillCompanyTable(Table company) {
		company = new Table();
		company.setEditable(true);
		company.setPageLength(3);
		return company;
	}

	private Label createCompany() {
		Company = new Label("Companies Relations");
		Company.setStyleName(ValoTheme.LABEL_H2);

		return Company;
	}

	private Button createCompanyButton() {
		addCompany2 = new Button(getBundleValue(CAPTIONS, ADDCCCC));
		addCompany2.setStyleName(ValoTheme.BUTTON_PRIMARY);
		// addCompany2.setClickShortcut(KeyCode.ENTER);
		addCompany2.setId(ADDCCCC);

		// assign the listener class that handles events
		addCompany2.addClickListener(eventsListener);
		return addCompany2;
	}

	private TextField createCompanyName() {
		companyName = new TextField();
		companyName.setStyleName(ValoTheme.TEXTFIELD_LARGE);
		companyName.setCaption(getBundleValue(CAPTIONS, COMPANY_NAME));
		companyName.setId(COMPANY_NAME);
		companyName.setNullRepresentation("");

		return companyName;
	}

	private TextField createInsurance() {
		insuranceNumber = new TextField();
		insuranceNumber.setStyleName(ValoTheme.TEXTFIELD_LARGE);
		insuranceNumber.setCaption(getBundleValue(CAPTIONS, INSURANCE_NUMBER));
		insuranceNumber.setId(INSURANCE_NUMBER);
		insuranceNumber.setNullRepresentation("");

		return insuranceNumber;
	}

	private TextField createCompanyContact() {
		companyContact = new TextField();
		companyContact.setStyleName(ValoTheme.TEXTFIELD_LARGE);
		companyContact.setCaption(getBundleValue(CAPTIONS, CONTACT));
		companyContact.setId(CONTACT);
		companyContact.setNullRepresentation("");

		return companyContact;
	}

	private ComboBox createCompanyR() {
		ComboBox Type = new ComboBox();
		Type.setStyleName(ValoTheme.TEXTFIELD_LARGE);
		Type.setCaption(getBundleValue(CAPTIONS, COMPANYR));
		Type.setId(COMPANYR);
		Type.setNullSelectionItemId(getBundleValue(MSGS, COMPANYR));
		Type.setInputPrompt(getBundleValue(MSGS, COMPANYR));
		Type.setDescription(getBundleValue(MSGS, COMPANYR));
		Type.setContainerDataSource(new BeanItemContainer<Companyrelationtype>(Companyrelationtype.class, TypetList));
		Type.setItemCaptionPropertyId("displayName");

		return Type;
	}

	public TextField getCompanyName() {
		return companyName;
	}

	public void setCompanyName(TextField companyName) {
		this.companyName = companyName;
	}

	public ComboBox getCompanyRType() {
		return companyRType;
	}

	public void setCompanyRType(ComboBox companyRType) {
		this.companyRType = companyRType;
	}

	public TextField getCompanyContact() {
		return companyContact;
	}

	public void setCompanyContact(TextField companyContact) {
		this.companyContact = companyContact;
	}

	public TextField getInsuranceNumber() {
		return insuranceNumber;
	}

	public void setInsuranceNumber(TextField insuranceNumber) {
		this.insuranceNumber = insuranceNumber;
	}
	
	public Table getCompanies() {
	        return companies;
	}

	public void setCompanies(Table companies) {
	        this.companies = companies;
	}

	private void addCompanyFieldGroup(BeanItem<Company_Entity> companyItem) {
		CompanyfieldGroup = new BeanFieldGroup<Company_Entity>(Company_Entity.class);
		CompanyfieldGroup.setBuffered(false);// not to depend on commitss
		CompanyfieldGroup.setItemDataSource(companyItem);
		CompanyfieldGroup.bindMemberFields(this);
	}

	private void addPatientCompanyFieldGroup(BeanItem<PatientCompany> patientCompanyItem) {
		PatientCompanyfieldGroup = new BeanFieldGroup<PatientCompany>(PatientCompany.class);
		PatientCompanyfieldGroup.setBuffered(false);// not to depend on commitss
		PatientCompanyfieldGroup.setItemDataSource(patientCompanyItem);
		PatientCompanyfieldGroup.bindMemberFields(this);
	}
}
