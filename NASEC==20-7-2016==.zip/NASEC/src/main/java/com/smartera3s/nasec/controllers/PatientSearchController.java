package com.smartera3s.nasec.controllers;

import static com.smartera3s.utils.InternationalizationFileBundle.MSGS;
import static com.smartera3s.utils.InternationalizationFileBundle.getBundleValue;

import java.io.File;
import java.util.List;
import java.util.Set;

import com.smartera3s.nasec.listeners.LoginListener;
import com.smartera3s.nasec.listeners.PatientSearchListener;
import com.smartera3s.nasec.model.Company_Contanier;
import com.smartera3s.nasec.model.Relation_Container;
import com.smartera3s.nasec.model.SysContext;
import com.smartera3s.nasec.model.entities.Address_Entity;
import com.smartera3s.nasec.model.entities.Company_Entity;
import com.smartera3s.nasec.model.entities.Companyrelationtype;
import com.smartera3s.nasec.model.entities.Contact_Entity;
import com.smartera3s.nasec.model.entities.PatientCompany;
import com.smartera3s.nasec.model.entities.PatientRelation;
import com.smartera3s.nasec.model.entities.Patient_Entity;
import com.smartera3s.nasec.model.entities.Relation;
import com.smartera3s.nasec.model.entities.UserEntity;
import com.smartera3s.nasec.screens.LoginScreen;
import com.smartera3s.nasec.screens.patientSearch.PatientSearchScreen;
import com.smartera3s.nasec.screens.reg.RegisterationScreen;
import com.smartera3s.nasec.services.LoginService;
import com.smartera3s.nasec.services.PatientSearchService;
import com.smartera3s.utils.ControllersSelector;
import com.vaadin.data.Container;
import com.vaadin.data.Property;
import com.vaadin.data.Property.ValueChangeEvent;
import com.vaadin.data.fieldgroup.BeanFieldGroup;
import com.vaadin.data.util.BeanItem;
import com.vaadin.data.util.BeanItemContainer;
import com.vaadin.event.ContextClickEvent;
import com.vaadin.server.FileResource;
import com.vaadin.server.VaadinService;
import com.vaadin.server.Sizeable.Unit;
import com.vaadin.ui.Button;
import com.vaadin.ui.CustomComponent;
import com.vaadin.ui.HorizontalLayout;
import com.vaadin.ui.Notification;
import com.vaadin.ui.Notification.Type;
import com.vaadin.ui.OptionGroup;
import com.vaadin.ui.Table;
import com.vaadin.ui.UI;
import com.vaadin.ui.Window;
import com.vaadin.ui.Button.ClickEvent;

public class PatientSearchController implements UIController {
    // constants
    public static final String VIEW_NAME = "Simple Search";
    public static final String PATIENT_NAME = "patient.fullName";
    public static final String GENDER = "patient.gender";
    public static final String PAYMENT = "patient.payment";
    public static final String AGE = "patient.age";

    public static final String CONTACT_VALUE = "contact.value";
    public static final String CONTACT_TYPE = "contact.type";
    public static final String COMPANY = "company.name";

    public static final String SUBMIT = "patient.search";

    public static final String NO_PATIENT = "patient.search.srvs.notExist";
    public static final String SEARCH_SUCCESS = "patient.search.srvs.successfulLogin";
    public static final String PATIENT_ID_IDENTIFICATION = "patient.id";
    public static final String RESULT = "search.result";
    public static final String PATIENTSELECTED = "search.srvs.successfulSelection";
    public static final String PATIENT_ID = "patient.Patientid";

    public static final String EDIT = "patient.edit";
    
    //Edit Mode of Registeration Filling Tables
    private BeanItemContainer<Contact_Entity> contactContainer;
    private BeanItemContainer<Relation_Container> relationContainer;
    private BeanItemContainer<Company_Contanier> companyContainer;
    
    // Model
    private Patient_Entity patientSample; 
    private Contact_Entity contactSample; 
    private Company_Entity companySample; 
    
    // View
    private PatientSearchScreen screen; 
    private RegisterationScreen Registeration;
    private Window window;

    private PatientSearchListener listener; // Actions & Events listener
    //Service
    private PatientSearchService patientSearchService;
    private Object SelectedPatient;
    
    //BeanItem For update
    private BeanItem<Patient_Entity> tempPatient;
    private BeanItem<Address_Entity> tempAddress;
    
    //Controllers
    private UIController callerController;
    private ControllersSelector Selector;

    public PatientSearchController() {
        Selector = new ControllersSelector();
        contactContainer = new BeanItemContainer<Contact_Entity>(
                Contact_Entity.class);
        relationContainer = new BeanItemContainer<Relation_Container>(
                Relation_Container.class);
        companyContainer = new BeanItemContainer<Company_Contanier>(
                Company_Contanier.class);
        patientSample = new Patient_Entity();
        contactSample = new Contact_Entity();
        companySample = new Company_Entity();
        Registeration = (RegisterationScreen) new RegisterationController(this)
                .getView();
        listener = new PatientSearchListener(this);
        screen = new PatientSearchScreen(
                new BeanItem<Patient_Entity>(patientSample),
                new BeanItem<Contact_Entity>(contactSample),
                new BeanItem<Company_Entity>(companySample), listener);
        patientSearchService = new PatientSearchService();

    }

    public PatientSearchController(UIController caller) {

        this.callerController = caller;
        Selector = new ControllersSelector();
        contactContainer = new BeanItemContainer<Contact_Entity>(
                Contact_Entity.class);
        relationContainer = new BeanItemContainer<Relation_Container>(
                Relation_Container.class);
        companyContainer = new BeanItemContainer<Company_Contanier>(
                Company_Contanier.class);
        patientSample = new Patient_Entity();
        contactSample = new Contact_Entity();
        companySample = new Company_Entity();
        listener = new PatientSearchListener(this);
        screen = new PatientSearchScreen(
                new BeanItem<Patient_Entity>(patientSample),
                new BeanItem<Contact_Entity>(contactSample),
                new BeanItem<Company_Entity>(companySample), listener);
        patientSearchService = new PatientSearchService();
        if (caller.equals("VisitController")) {
            screen.patientList.removeGeneratedColumn("Edit");
        }
    }

    public void search() {
        // TODO hit DB for
        BeanItem<Patient_Entity> patientItem = (BeanItem<Patient_Entity>) screen
                .getFieldGroupPatient().getItemDataSource();
        BeanItem<Contact_Entity> contactItem = (BeanItem<Contact_Entity>) screen
                .getFieldGroupContact().getItemDataSource();
        BeanItem<Company_Entity> companyItem = (BeanItem<Company_Entity>) screen
                .getFieldGroupCompany().getItemDataSource();
        try {
            Container result = patientSearchService.search(
                    patientItem.getBean(), contactItem.getBean(),
                    companyItem.getBean());
            screen.setResultContainer(result);

            // TODO handle result
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            Notification.show("Exceptions: " + e.getMessage(),
                    Type.WARNING_MESSAGE);
        }
    }

    public void selectPatient(Object value) {
        SysContext context = (SysContext) VaadinService.getCurrentRequest()
                .getWrappedSession().getAttribute(SysContext.class.getName());

        SelectedPatient = value;
        context.setSelectedPatient((Patient_Entity) SelectedPatient);
        if (callerController != null) {
            callerController.setNotification("Selection Susuccessfully");
            Notification.show(getBundleValue(MSGS, PATIENTSELECTED),
                    Type.TRAY_NOTIFICATION);
        }

    }

    public void edit() {
        if (SelectedPatient != null && Registeration != null) {
            window = new Window("Patient Edit");
            window.setWidth(1024.0f, Unit.PIXELS);
            window.setHeight(600.0f, Unit.PIXELS);
            window.setModal(true);
            window.setContent(Registeration);
            UI.getCurrent().addWindow(window);

            tempPatient = new BeanItem<Patient_Entity>(
                    (Patient_Entity) SelectedPatient);
            Registeration.getBasic().updateFieldGroup(tempPatient);
            Registeration.getBasicInformaton()
                    .updatePatientFieldGroup(tempPatient);
            Registeration.getBasic().getPatientID()
                    .setValue(String.valueOf(tempPatient.getBean().getId()));
            if (tempPatient.getBean().getProfile_pic() != null) {
                Registeration.getBasic().getMyLocalImage()
                        .setSource(new FileResource(new File(
                                tempPatient.getBean().getProfile_pic())));
            }
            List<Address_Entity> Address = patientSearchService
                    .getAddress(tempPatient.getBean().getId());
            for (int i = 0; i < Address.size(); i++) {
                tempAddress = new BeanItem<Address_Entity>(
                        (Address_Entity) Address.get(i));
            }
            Registeration.getContactInformation()
                    .updateAddressFieldGroup(tempAddress);
            List<Contact_Entity> Contacts = patientSearchService
                    .getContact(tempPatient.getBean().getId());
            for (int i = 0; i < Contacts.size(); i++) {
                contactContainer.addBean(Contacts.get(i));
            }

            Registeration.getContactInformation().getContacts()
                    .removeGeneratedColumn("Remove");
            Registeration.getContactInformation().getContacts()
                    .setContainerDataSource(contactContainer);
            Registeration.getContactInformation().getContacts().setVisibleColumns(
                    "contact_type", "value", "primaryContact");
            Registeration.getContactInformation().getContacts()
                    .addGeneratedColumn("Remove", new Table.ColumnGenerator() {
                        public Object generateCell(Table source,
                                final Object itemId, Object columnId) {
                            HorizontalLayout Contact_Table_Horizontal_Layout = new HorizontalLayout();
                            Button removeButton = new Button("-");
                            removeButton.addClickListener(
                                    new Button.ClickListener() {
                                        public void buttonClick(
                                                ClickEvent event) {
                                            contactContainer.removeItem(itemId);
                                        }
                                    });
                            Contact_Table_Horizontal_Layout
                                    .addComponent(removeButton);
                            return Contact_Table_Horizontal_Layout;
                        }
                    });
            Registeration.getBasic().getPrimaryContact()
                    .addValueChangeListener(new Property.ValueChangeListener() {
                        public void valueChange(ValueChangeEvent event) {

                            Object x = event.getProperty().getValue();
                            if (x != null) {
                                Contact_Entity primary = new Contact_Entity(
                                        "Mobile", x.toString(), true);
                                contactContainer.addBean(primary);
                            }
                        }
                    });

            List<Company_Entity> compnay = patientSearchService
                    .getCompany(tempPatient.getBean().getId());
            List<PatientCompany> PatientCompany = patientSearchService
                    .getCPatient(tempPatient.getBean().getId());

            Registeration.getCompanyInformation().getCompanies()
                    .removeGeneratedColumn("Remove");
            Registeration.getCompanyInformation().getCompanies()
                    .setContainerDataSource(companyContainer);
            Registeration.getCompanyInformation().getCompanies()
                    .setVisibleColumns("name", "type", "insurance_number");
            Registeration.getCompanyInformation().getCompanies()
                    .addGeneratedColumn("Remove", new Table.ColumnGenerator() {
                        public Object generateCell(Table source,
                                final Object itemId, Object columnId) {
                            HorizontalLayout Company_Table_Horizontal_Layout = new HorizontalLayout();
                            Button removeButton = new Button("-");
                            removeButton.addClickListener(
                                    new Button.ClickListener() {
                                        public void buttonClick(
                                                ClickEvent event) {
                                            companyContainer.removeItem(itemId);
                                        }
                                    });
                            Company_Table_Horizontal_Layout
                                    .addComponent(removeButton);
                            return Company_Table_Horizontal_Layout;
                        }
                    });
            for (int i = 0; i < compnay.size(); i++) {
                if (PatientCompany.size() != 0) {
                    List<Companyrelationtype> Companyrelation = patientSearchService
                            .getCRelation(
                                    PatientCompany.get(i).getRelation_type());
                    Company_Contanier temp = new Company_Contanier(
                            compnay.get(i).getName(),
                            PatientCompany.get(i).getInsurance_number(),
                            compnay.get(i).getContact(),
                            PatientCompany.get(i).getRelation_type(),
                            Companyrelation.get(i).getDisplayName());
                    companyContainer.addBean(temp);
                }
            }

            Registeration.getRelationInformation().getRelations()
                    .removeGeneratedColumn("Remove");
            Registeration.getRelationInformation().getRelations()
                    .setContainerDataSource(relationContainer);
            Registeration.getRelationInformation().getRelations()
                    .setVisibleColumns("fullName", "relation", "mobile");
            Registeration.getRelationInformation().getRelations()
                    .addGeneratedColumn("Remove", new Table.ColumnGenerator() {
                        public Object generateCell(Table source,
                                final Object itemId, Object columnId) {
                            HorizontalLayout Relation_Table_Horizontal_Layout = new HorizontalLayout();
                            Button removeButton = new Button("-");
                            removeButton.addClickListener(
                                    new Button.ClickListener() {
                                        public void buttonClick(
                                                ClickEvent event) {
                                            relationContainer
                                                    .removeItem(itemId);
                                        }
                                    });
                            Relation_Table_Horizontal_Layout
                                    .addComponent(removeButton);
                            return Relation_Table_Horizontal_Layout;
                        }
                    });

            List<PatientRelation> PatientRelation = patientSearchService
                    .getRelation(tempPatient.getBean().getId());
            for (int i = 0; i < compnay.size(); i++) {
                if (PatientRelation.size() != 0) {
                    List<Relation> relation = patientSearchService.getPRelation(
                            PatientRelation.get(i).getId().getRelation_id());
                    List<Patient_Entity> Patient2 = patientSearchService
                            .getRelativePatient(PatientRelation.get(i).getId()
                                    .getPatient2_id());

                    Relation_Container temp = new Relation_Container(
                            Patient2.get(i).getFirst_name(),
                            Patient2.get(i).getSecond_name(),
                            Patient2.get(i).getLast_name(), "",
                            relation.get(i).getRelation_type());

                    relationContainer.addBean(temp);
                }
            }
        }

    }

    // Controllers Common function

    @Override
    public CustomComponent getView() {
        // TODO Auto-generated method stub
        return screen;
    }

    @Override
    public void setNotification(String msg) {

    }
}
