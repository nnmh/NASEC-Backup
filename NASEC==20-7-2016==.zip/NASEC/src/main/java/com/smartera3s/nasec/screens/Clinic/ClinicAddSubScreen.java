package com.smartera3s.nasec.screens.Clinic;

import static com.smartera3s.nasec.controllers.ClinicController.SAVECLINICVISIT;
import static com.smartera3s.nasec.controllers.ClinicController.SAVEPOPUP;
import static com.smartera3s.utils.InternationalizationFileBundle.CAPTIONS;
import static com.smartera3s.utils.InternationalizationFileBundle.getBundleValue;

import java.util.HashMap;
import java.util.List;

import com.smartera3s.nasec.listeners.ClinicListener;
import com.smartera3s.nasec.model.entities.ColumnEntity;
import com.smartera3s.nasec.model.entities.RowEntity;
import com.smartera3s.nasec.model.entities.Scattered_fieldEntity;
import com.vaadin.server.ThemeResource;
import com.vaadin.ui.Alignment;
import com.vaadin.ui.Button;
import com.vaadin.ui.Component;
import com.vaadin.ui.GridLayout;
import com.vaadin.ui.HorizontalLayout;
import com.vaadin.ui.Label;
import com.vaadin.ui.Layout;
import com.vaadin.ui.TextArea;
import com.vaadin.ui.TextField;
import com.vaadin.ui.VerticalLayout;
import com.vaadin.ui.Window;
import com.vaadin.ui.themes.ValoTheme;

@SuppressWarnings("serial")
public class ClinicAddSubScreen extends Window {

	private Component TestComponent;
	private GridLayout sample;
	private String ComponentName;
	String ComponentType;
	private Layout subContent;
	private Layout subContent2;
	private Layout mainLayout;
	private Button Save;
	private ClinicListener eventListener;
	private HashMap Components;
	private HashMap ComponentsBindingObjects;

	public ClinicAddSubScreen(ClinicListener listener) {
		// Center it in the browser window
		center();
		this.eventListener = listener;
		new Window("Clinic Requirments");
		setWidth(900.0f, Unit.PIXELS);
		setHeight(600.0f, Unit.PIXELS);
		setModal(true);

		Save = createbutton();

		Components = new HashMap<String, Component>();
		ComponentsBindingObjects = new HashMap<String, Object>();
		subContent = new VerticalLayout();
		
		subContent.setSizeUndefined();
		subContent.addStyleName("test");

		subContent2 = new VerticalLayout();
		subContent2.setSizeUndefined();

		mainLayout = new VerticalLayout();
		mainLayout.addStyleName("Popps-Layout");
		mainLayout.removeAllComponents();
		
		mainLayout.addComponent(subContent);
		
		mainLayout.addComponent(subContent2);
		mainLayout.addComponent(Save);

		setContent(mainLayout);
	}

	public Component createComponent(String ComponentName, String ComponentType) {
		Component field = null;
		if (ComponentType == "Label") {
			field = new Label(ComponentName);
		} else if (ComponentType.equals("TextField")) {
			field = new TextField();
			((TextField) field).setInputPrompt(ComponentName);
			field.setId(ComponentName);

		} else if (ComponentType.equals("TextArea")) {
			field = new TextArea();
			field.setCaption(ComponentName);
//			field.setSizeFull();

		}

		Components.put(ComponentName, field);
		/*
		 * if(! (field instanceof Label)){ ObjectProperty<Object>
		 * ComponentsBinding= new ObjectProperty<Object>(null);
		 * ((AbstractField)field).setPropertyDataSource(ComponentsBinding);
		 * ComponentsBindingObjects.put(ComponentName,ComponentsBinding); }
		 */
		return field;
	}

	public void createGride(List<RowEntity> RowList, List<ColumnEntity> ColumnList) {
		// Create a grid layout
		subContent.removeAllComponents();
		subContent2.removeAllComponents();
		Components.clear();
		sample = new GridLayout();
		sample.removeAllComponents();
		sample.addStyleName("outlined");
		sample.setSizeFull();
		sample.removeAllComponents();
		sample.setRows(RowList.size() + 1);
		sample.setColumns(ColumnList.size() + 1);
		for (int rows = 1; rows < sample.getRows(); rows++) {
			sample.addComponent(createComponent(RowList.get(rows - 1).getName(), "Label"), 0, rows);
			sample.setRowExpandRatio(rows, 0.0f);
		}
		if (RowList.get(0).getFormId().equals("1") || RowList.get(0).getFormId().equals("3")) {
			for (int col = 1; col < 3; col++) {

				sample.addComponent(createComponent(ColumnList.get(col - 1).getName(), "Label"), col, 0);
				sample.setColumnExpandRatio(col, 0.0f);
			}

			for (int rows = 1; rows < sample.getRows(); rows++) {
				for (int col = 1; col < 3; col++) {

					sample.addComponent(
							createComponent(RowList.get(rows - 1).getName() + "-" + ColumnList.get(col - 1).getName(),
									ColumnList.get(col - 1).getType()),
							col, rows);

					sample.setRowExpandRatio(rows, 0.0f);
					sample.setColumnExpandRatio(col, 0.0f);

				}
			}
		} else {
			for (int col = 1; col < 4; col++) {

				sample.addComponent(createComponent(ColumnList.get(col - 1).getName(), "Label"), col, 0);
				sample.setColumnExpandRatio(col, 0.0f);
			}

			for (int rows = 1; rows < sample.getRows(); rows++) {
				for (int col = 1; col < 4; col++) {

					sample.addComponent(
							createComponent(RowList.get(rows - 1).getName() + "-" + ColumnList.get(col - 1).getName(),
									ColumnList.get(col - 1).getType()),
							col, rows);

					sample.setRowExpandRatio(rows, 0.0f);
					sample.setColumnExpandRatio(col, 0.0f);

				}
			}
		}
		subContent.addComponent(sample);
		// return sample;
	}

	public void createGridewithScattered(List<RowEntity> RowList, List<ColumnEntity> ColumnList,
			List<Scattered_fieldEntity> ScatteredList) {
		// Create a grid layout
		subContent.removeAllComponents();
		subContent2.removeAllComponents();
		Components.clear();
		sample = new GridLayout();
		sample.removeAllComponents();
		sample.addStyleName("outlined");
		sample.setSizeFull();

		sample.setRows(RowList.size() + 1);
		sample.setColumns(ColumnList.size() + 1);
		for (int rows = 1; rows < sample.getRows(); rows++) {
			sample.addComponent(createComponent(RowList.get(rows - 1).getName(), "Label"), 0, rows);
			sample.setRowExpandRatio(rows, 0.0f);
		}

		if (RowList.get(0).getFormId().equals("1") || RowList.get(0).getFormId().equals("3")) {
			for (int col = 1; col < 3; col++) {

				sample.addComponent(createComponent(ColumnList.get(col - 1).getName(), "Label"), col, 0);
				sample.setColumnExpandRatio(col, 0.0f);
			}

			for (int rows = 1; rows < sample.getRows(); rows++) {
				for (int col = 1; col < 3; col++) {

					sample.addComponent(
							createComponent(RowList.get(rows - 1).getName() + "-" + ColumnList.get(col - 1).getName(),
									ColumnList.get(col - 1).getType()),
							col, rows);

					sample.setRowExpandRatio(rows, 0.0f);
					sample.setColumnExpandRatio(col, 0.0f);

				}
			}
		} else {
			for (int col = 1; col < 4; col++) {

				sample.addComponent(createComponent(ColumnList.get(col - 1).getName(), "Label"), col, 0);
				sample.setColumnExpandRatio(col, 0.0f);
			}

			for (int rows = 1; rows < sample.getRows(); rows++) {
				for (int col = 1; col < 4; col++) {

					sample.addComponent(
							createComponent(RowList.get(rows - 1).getName() + "-" + ColumnList.get(col - 1).getName(),
									ColumnList.get(col - 1).getType()),
							col, rows);

					sample.setRowExpandRatio(rows, 0.0f);
					sample.setColumnExpandRatio(col, 0.0f);

				}
			}
		}
		subContent.addComponent(sample);
		for (int h = 0; h < ScatteredList.size(); h++) {
			subContent2.addComponent(createComponent(ScatteredList.get(h).getName(), ScatteredList.get(h).getType()));
		}

		// return sample;
	}

	private Button createbutton() {
		Save = new Button(getBundleValue(CAPTIONS, SAVEPOPUP));
		Save.setId(SAVEPOPUP);
		Save.addClickListener(eventListener);
		Save.setIcon(new ThemeResource("img/save.png"));
		return Save;
	}

	public HashMap getComponents() {
		return Components;
	}

	public void setComponents(HashMap components) {
		Components = components;
	}
}