package com.smartera3s.nasec.services;

import java.util.Collection;

import com.smartera3s.nasec.model.entities.UserEntity;
import com.smartera3s.utils.InternationalizationFileBundle;
import com.vaadin.addon.jpacontainer.JPAContainer;
import com.vaadin.addon.jpacontainer.JPAContainerFactory;
import com.vaadin.addon.jpacontainer.JPAContainerItem;
import com.vaadin.data.Container.Filter;
import com.vaadin.data.util.filter.Compare;
import com.vaadin.ui.Notification;
import com.vaadin.ui.Notification.Type;
import static com.smartera3s.nasec.controllers.LoginController.*;
import static com.smartera3s.utils.InternationalizationFileBundle.*;


public class LoginService {
	private JPAContainer<UserEntity> usersCheck;
	
	public LoginService(){
		usersCheck = JPAContainerFactory.makeNonCachedReadOnly(UserEntity.class, "NASEC");
		
	}
	public boolean login(UserEntity user){
		usersCheck.removeAllContainerFilters();// clear filters	
		Filter filter = new Compare.Equal("username", user.getUsername());
		usersCheck.addContainerFilter(filter);
		Collection<Object> items = usersCheck.getItemIds();
		if(items == null || items.size()==0){
			Notification.show(getBundleValue(MSGS,WRONG_USER), Type.WARNING_MESSAGE);	
			return false;
		}
		for(Object itemId: items){//here is itemId is String <<as>> @Id of the UserEntity
			JPAContainerItem<UserEntity> temp = (JPAContainerItem<UserEntity>) usersCheck.getItem(itemId);
			if(temp.getEntity().getPassword().equals(user.getPassword())){
				return true;
			}
		}
		Notification.show(getBundleValue(MSGS,WRONG_PASSWORD), Type.WARNING_MESSAGE);
		return false;//not valid
	}
}
