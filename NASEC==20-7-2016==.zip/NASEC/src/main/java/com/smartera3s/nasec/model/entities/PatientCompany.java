package com.smartera3s.nasec.model.entities;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the patient_company database table.
 * 
 */
@Entity
@Table(name="patient_company")
@NamedQuery(name="PatientCompany.findAll", query="SELECT p FROM PatientCompany p")
public class PatientCompany implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private PatientCompanyPK id;

	private String insurance_number;

	private int relation_type;
	@Transient
        private Companyrelationtype linkedType;

	public PatientCompany() {
	}

	public PatientCompanyPK getId() {
		return this.id;
	}

	public void setId(PatientCompanyPK id) {
		this.id = id;
	}

	public String getInsurance_number() {
		return this.insurance_number;
	}

	public void setInsurance_number(String insurance_number) {
		this.insurance_number = insurance_number;
	}

	public int getRelation_type() {
		return this.relation_type;
	}

	public void setRelation_type(int relation_type) {
		this.relation_type = relation_type;
	}
	 public Companyrelationtype getLinkedIDType() {
	            if(linkedType == null){
	                linkedType = new Companyrelationtype();
	            }
	            linkedType.setId(relation_type);
	            
	            return linkedType;
	        }

	        public void setLinkedIDType(Companyrelationtype linkedType) {
	            relation_type = linkedType.getId();
	            this.linkedType = linkedType;
	        }

}