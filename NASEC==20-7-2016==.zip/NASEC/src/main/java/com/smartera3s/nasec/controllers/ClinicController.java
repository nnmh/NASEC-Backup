package com.smartera3s.nasec.controllers;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;

import com.smartera3s.nasec.listeners.ClinicListener;
import com.smartera3s.nasec.model.ClinicDescriptionContainer;
import com.smartera3s.nasec.model.SysContext;
import com.smartera3s.nasec.model.entities.BodypartEntity;
import com.smartera3s.nasec.model.entities.Categories_listEntity;
import com.smartera3s.nasec.model.entities.ClinicvisitEntity;
import com.smartera3s.nasec.model.entities.ColumnEntity;
import com.smartera3s.nasec.model.entities.Columnsdata;
import com.smartera3s.nasec.model.entities.FormEntity;
import com.smartera3s.nasec.model.entities.Icd10Entity;
import com.smartera3s.nasec.model.entities.Patient_Entity;
import com.smartera3s.nasec.model.entities.PatientsymptomEntity;
import com.smartera3s.nasec.model.entities.RowEntity;
import com.smartera3s.nasec.model.entities.Scattered_fieldEntity;
import com.smartera3s.nasec.model.entities.Scattered_fields_dataEntity;
import com.smartera3s.nasec.model.entities.Symeptoms_badypartEntity;
import com.smartera3s.nasec.model.entities.VisitEntity;
import com.smartera3s.nasec.screens.Clinic.ClinicAddSubScreen;
import com.smartera3s.nasec.screens.Clinic.ClinicDescriptionScreen;
import com.smartera3s.nasec.screens.Clinic.ClinicPatientSubscreen;
import com.smartera3s.nasec.screens.Clinic.ClinicScreen;
import com.smartera3s.nasec.screens.patientSearch.PatientSearchScreen;
import com.smartera3s.nasec.services.ClinicServices;
import com.vaadin.data.Property.ValueChangeEvent;
import com.vaadin.data.Property.ValueChangeListener;
import com.vaadin.data.util.BeanItem;
import com.vaadin.data.util.BeanItemContainer;
import com.vaadin.server.FileResource;
import com.vaadin.server.Sizeable.Unit;
import com.vaadin.server.VaadinService;
import com.vaadin.ui.AbstractField;
import com.vaadin.ui.Button;
import com.vaadin.ui.CustomComponent;
import com.vaadin.ui.Layout;
import com.vaadin.ui.ListSelect;
import com.vaadin.ui.Table;
import com.vaadin.ui.TextArea;
import com.vaadin.ui.TextField;
import com.vaadin.ui.UI;
import com.vaadin.ui.VerticalLayout;
import com.vaadin.ui.Window;
import com.vaadin.ui.Button.ClickEvent;
import com.vaadin.ui.Button.ClickListener;
import com.vaadin.ui.themes.ValoTheme;

public class ClinicController implements UIController {

    public static final String LOADPATIENT = "clinic.loadbutton";
    public static final String SAVECLINICVISIT = "clinic.save";
    public static final String ADDDESCRIPSION = "clinic.addbutton";
    public static final String ADDDESCRIPSIONDETAILS = "clinic.adddetails";
    public static final String ADDCOMBOBOX = "clinic.addcombo";
    public static final String ADDGLASSES = "clinic.galss";
    public static final String ADDREQUIREMENT = "clinic.requirement";
    public static final String ADDEXAINATION = "clinic.addbutton";
    public static final String ADDI_OP = "clinic.addi-op";
    public static final String DATE = "clinic.dsecriptionDate";
    public static final String NOTES = "clinic.note";
    public static final String ICD10 = "clinic.icd10";
    public static final String BODYPARTS = "clinic.body";
    public static final String SAVEPOPUP = "clinic.popup";

    //Form Button
    private Button Form;

    
    private SysContext sysContext;  
    private ClinicListener listener; // Actions & Events listener
    private ClinicServices Services; // Services
    
    
    // View
    private ClinicScreen screen; 
    private PatientSearchScreen patientSubscreen;
    private ClinicDescriptionScreen DescriptionScreen;
    private ClinicAddSubScreen AddSubScreen;
    private Window window;
    
    // Model
    private ClinicvisitEntity clinicSample; 
    private Columnsdata ColumnsData; 
    private Scattered_fields_dataEntity ScatteredData; 
   
    
    //BeanItems
    private BeanItem<ClinicvisitEntity> tempClinic;
    private BeanItem<Columnsdata> DataBeanItem;
    private BeanItem<Scattered_fields_dataEntity> ScatteredDataBeanItem;
    private BeanItem<ClinicvisitEntity> clinicItem;
    
    
    //Services List
    private List<Icd10Entity> ICD10List;
    private List<List<BodypartEntity>> BodyPartList;
    
    
   //Forms Filling 
    private List<Categories_listEntity> CategoryList;
    private List<FormEntity> FormList;
    private List<RowEntity> RowList;
    private List<ColumnEntity> ColumnList;
    private List<ColumnEntity> ColumnListTemp;
    private List<Scattered_fieldEntity> ScatteredList;
    
    
    //Button Checking HashMap
    private HashMap<String, String> CheckingTable;
    
    //Form Filling HashMap
    private HashMap<String, List> RowTable;
    private HashMap<String, List> ColumnTable;
    private HashMap<String, List> ScatteredTable;

    public ClinicController() {
        clinicSample = new ClinicvisitEntity();
        
        ColumnsData = new Columnsdata();
        ScatteredData = new Scattered_fields_dataEntity();
        DataBeanItem = new BeanItem<Columnsdata>(ColumnsData);
        ScatteredDataBeanItem = new BeanItem<Scattered_fields_dataEntity>(
                ScatteredData);
        
        patientSubscreen = (PatientSearchScreen) new PatientSearchController(
                this).getView();
        listener = new ClinicListener(this);
        screen = new ClinicScreen(new BeanItem<ClinicvisitEntity>(clinicSample),listener);
        AddSubScreen = new ClinicAddSubScreen(listener);
        
        Services = new ClinicServices();
        CategoryList = Services.findAllCategories();
        
        ICD10List = new ArrayList<Icd10Entity>();
        BodyPartList = new ArrayList<List<BodypartEntity>>();
        
        CheckingTable = new HashMap<>();
        RowTable = new HashMap<>();
        ColumnTable = new HashMap<>();
        ScatteredTable = new HashMap<>();
        ColumnList = new ArrayList<ColumnEntity>();
        ColumnListTemp = new ArrayList<ColumnEntity>();
        sysContext = (SysContext) VaadinService.getCurrentRequest()
                .getWrappedSession().getAttribute(SysContext.class.getName());
        screen.getPatientObjectives().setContainerDataSource(
                new BeanItemContainer<Categories_listEntity>(
                        Categories_listEntity.class, CategoryList));

    }

    public void load() {
        window = new Window("Patient Search");
        window.setWidth(900.0f, Unit.PIXELS);
        window.setHeight(600.0f, Unit.PIXELS);
        screen.getWindowLayout().addComponent(patientSubscreen);
        window.setContent(screen.getWindowLayout());
        window.setModal(true);
        UI.getCurrent().addWindow(window);
    }

    public void addDescription() {
        window = new Window("Add Description");
        
        window.setWidth(600.0f, Unit.PIXELS);
        window.setHeight(600.0f, Unit.PIXELS);
        DescriptionScreen = new ClinicDescriptionScreen(listener);
        screen.getWindowLayout2().addComponent(DescriptionScreen);
        window.setContent(screen.getWindowLayout2());
        window.setModal(true);
        UI.getCurrent().addWindow(window);
    }

    public void addFromCombo() {
        // Hash Table Check

        Categories_listEntity Name = (Categories_listEntity) screen
                .getPatientObjectives().getValue();
        if (!CheckingTable.containsValue(Name.getCategory())) {
            Form = new Button();
            screen.getToolbarLayout().addComponent(Form);
            Form.setCaption(Name.getCategory());
            CheckingTable.put(Name.getCategory(), Name.getCategory());
            Form.setStyleName(ValoTheme.BUTTON_PRIMARY);
            fillGrid(Name.getCategory());
        }
    }

    void fillGrid(String Name) {
        FormList = Services.findAllforms(Name);

        RowList = Services
                .findAllrows(String.valueOf(FormList.get(0).getFormId()));
        ColumnList.clear();
        for (int i = 0; i < RowList.size(); i++) {
            ColumnListTemp = Services.findAllcolumns(
                    String.valueOf(FormList.get(0).getFormId()),
                    (String.valueOf(RowList.get(i).getRowid())));
            for (int j = 0; j < ColumnListTemp.size(); j++) {
                ColumnListTemp.get(j).setRowName(RowList.get(i).getName());
            }
            ColumnList.addAll(ColumnListTemp);
        }
        ScatteredList = Services
                .findAllScattered(String.valueOf(FormList.get(0).getFormId()));
        RowTable.put(Name, RowList);
        ColumnTable.put(Name, ColumnList);
        ScatteredTable.put(Name, ScatteredList);
        Form.addClickListener(new ClickListener() {
            @Override
            public void buttonClick(ClickEvent event) {
                // Form.getCaption()
                if (ScatteredTable.get(Name).size() != 0) {
                    AddSubScreen.createGridewithScattered(RowTable.get(Name),
                            ColumnTable.get(Name), ScatteredTable.get(Name));
                    screen.getUI().addWindow(AddSubScreen);

                } else {
                    AddSubScreen.createGride(RowTable.get(Name),
                            ColumnTable.get(Name));
                    screen.getUI().addWindow(AddSubScreen);
                }
            }
        });
    }

    public void addDescriptionDetails() {
        screen.getDescriptionTable().getContainerDataSource()
                .addItem(DescriptionScreen.getSymptomsItems().getBean());
        screen.getDescriptionTable()
        .removeGeneratedColumn("ICD");
        screen.getDescriptionTable().addGeneratedColumn("ICD",
                new Table.ColumnGenerator() {
                    public Object generateCell(Table source,
                            final Object itemId,
                            Object columnId) {
                        Layout ICD10Layout = new VerticalLayout();
                        ICD10Layout.setSizeUndefined();

                        if (((PatientsymptomEntity)itemId).getICD10List().size() > 0) {
                            ListSelect ICD10 = new ListSelect(
                                    "ICD10 List");
                            ICD10.setNullSelectionAllowed(
                                    false);
                            ICD10.setSizeUndefined();
                            ICD10.setRows(((PatientsymptomEntity)itemId).getICD10List().size());
                            ICD10.setContainerDataSource(
                                    new BeanItemContainer<Icd10Entity>(
                                            Icd10Entity.class,
                                            ((PatientsymptomEntity)itemId).getICD10List()));
                            ICD10Layout.addComponent(ICD10);
                        }
                        return ICD10Layout;
                    }
                });
        
        ICD10List .addAll((Collection<Icd10Entity>)(DescriptionScreen.getSymptomsItems().getBean().getICD10List()));
        screen.getDescriptionTable().removeGeneratedColumn("bodyparts");
            screen.getDescriptionTable().addGeneratedColumn("bodyparts",
                new Table.ColumnGenerator() {
                    public Object generateCell(Table source,
                            final Object itemId,
                            Object columnId) {
                        Layout BodyPartLayout = new VerticalLayout();
                        BodyPartLayout.setSizeUndefined();
                        if (((PatientsymptomEntity)itemId).getBodyPartsList().size() > 0) {
                            ListSelect Body = new ListSelect(
                                    "Body List");
                            Body.setNullSelectionAllowed(false);
                            Body.setSizeUndefined();
                            Body.setRows(((PatientsymptomEntity)itemId).getBodyPartsList().size());
                            Body.setContainerDataSource(
                                    new BeanItemContainer<BodypartEntity>(
                                            BodypartEntity.class,
                                            ((PatientsymptomEntity)itemId).getBodyPartsList()));
                            BodyPartLayout.addComponent(Body);
                        }
                        return BodyPartLayout;
                    }
                });
        
        BodyPartList .add(new ArrayList(  ((Collection<? extends List<BodypartEntity>>) (DescriptionScreen.getSymptomsItems().getBean().getBodyPartsList()))  ) );    
        window.close();
    }

    public void changeListener(ValueChangeEvent event) {
        screen.getAddCombobox().setEnabled(event.getProperty().getValue() != null);
    }
    
    public void createclinic(BeanItem<ClinicvisitEntity> clinicItem){
        Patient_Entity SelectedPatient = sysContext.getSelectedPatient();
        VisitEntity currentVisit = sysContext.getCurrentVisit();
        clinicItem  = new BeanItem<ClinicvisitEntity>(clinicSample);
        clinicItem.getBean().setAssessments(screen.getObjectiveFieldGroup().getItemDataSource().getBean().getAssessments());
        clinicItem.getBean().setNotes(screen.getObjectiveFieldGroup().getItemDataSource().getBean().getNotes());

        clinicItem.getBean().setPlans(screen.getObjectiveFieldGroup().getItemDataSource().getBean().getPlans());

        clinicItem.getBean()
                .setPatient_id(String.valueOf(SelectedPatient.getId()));
        clinicItem.getBean().setVisitID(String.valueOf(currentVisit.getId()));
        clinicItem.getBean()
                .setClinicVisitDate(currentVisit.getVistsDateTime());
        clinicSample = Services.createClinic(clinicItem);

    }
    public void savePopUp() {
        
        createclinic(clinicItem);
        clinicItem  = new BeanItem<ClinicvisitEntity>(clinicSample);
        Patient_Entity SelectedPatient = sysContext.getSelectedPatient();
        DataBeanItem.getBean()
                .setFormId(String.valueOf(FormList.get(0).getFormId()));

        for (int j = 0; j < ColumnList.size(); j++) {
            DataBeanItem.getBean()
                    .setPatientId(String.valueOf(SelectedPatient.getId()));
            DataBeanItem.getBean()
                    .setClinicId(String.valueOf(clinicSample.getId()));
            DataBeanItem.getBean().setColumnId(
                    String.valueOf(ColumnList.get(j).getColumnId()));
            DataBeanItem.getBean()
                    .setRowid(String.valueOf(ColumnList.get(j).getRowid()));

            Object Components = AddSubScreen.getComponents()
                    .get(ColumnList.get(j).getRowName() + "-"
                            + ColumnList.get(j).getName());
            DataBeanItem.getBean()
                    .setValue(((TextField) Components).getValue());
            ColumnsData = Services.createPopup(DataBeanItem, clinicItem);
        }
        if (!ScatteredList.isEmpty()) {
            ScatteredDataBeanItem.getBean()
                    .setFormId(String.valueOf(FormList.get(0).getFormId()));
            for (int j = 0; j < ScatteredList.size(); j++) {
                ScatteredDataBeanItem.getBean()
                        .setPatientId(String.valueOf(SelectedPatient.getId()));
                ScatteredDataBeanItem.getBean()
                        .setClinicId(String.valueOf(clinicSample.getId()));
                ScatteredDataBeanItem.getBean().setScatteredId(
                        String.valueOf(ScatteredList.get(j).getId()));
                Object Components = AddSubScreen.getComponents()
                        .get(ScatteredList.get(j).getName());
                ScatteredDataBeanItem.getBean()
                        .setValue(((TextArea) Components).getValue());
                ScatteredData = Services.createScattered(ScatteredDataBeanItem,
                        clinicItem);
            }
        }
    }

    public void saveRequest() {
        Patient_Entity SelectedPatient = sysContext.getSelectedPatient();
        
        clinicItem  = new BeanItem<ClinicvisitEntity>(clinicSample);
        createclinic(clinicItem);
        
        
        PatientsymptomEntity PatientsymptomSample = new PatientsymptomEntity();
        Symeptoms_badypartEntity SymptomBodyParts = new Symeptoms_badypartEntity();
        
        BeanItem<Symeptoms_badypartEntity> BodyPartsBeanItem = new BeanItem<Symeptoms_badypartEntity>(SymptomBodyParts);
        BeanItem<PatientsymptomEntity> symptom;

        
        List<Symeptoms_badypartEntity>tempSymptomList = new ArrayList<Symeptoms_badypartEntity>();
        List<PatientsymptomEntity>tempPatientSymptomList = new ArrayList<PatientsymptomEntity>();
        
        int symptomID=0;
        for (Object itemId : screen.getDescriptionTable()
                .getContainerDataSource().getItemIds()) {
            symptom = (BeanItem<PatientsymptomEntity>)screen.getDescriptionTable()
                    .getContainerDataSource().getItem(itemId);
                symptom.getBean()
                    .setICD10Codes(String.valueOf(ICD10List.get(symptomID).getId()));
                
                PatientsymptomSample = Services.createSymptoms(symptom,clinicSample);
            
                ((BeanItem<PatientsymptomEntity>)screen.getDescriptionTable()
                        .getContainerDataSource().getItem(itemId)).getBean().setId(PatientsymptomSample.getId());
                
                tempPatientSymptomList.add(PatientsymptomSample);
                
            
            for (int i = 0; i < BodyPartList.get(symptomID).size(); i++) {
                if (clinicItem.getBean().getPatientSymptomList() !=null){
                    if(clinicItem.getBean().getPatientSymptomList().size() == symptomID+1){
                        BodyPartsBeanItem = new BeanItem<Symeptoms_badypartEntity>(clinicItem.getBean().getPatientSymptomList().get(symptomID).getSymeptoms().get(i));
                    }else{
                        BodyPartsBeanItem = new BeanItem<Symeptoms_badypartEntity>(new Symeptoms_badypartEntity());
                    }
                }
                
                BodyPartsBeanItem.getBean()
                        .setBodyPatID(String.valueOf(BodyPartList.get(symptomID).get(i).getId()));
                BodyPartsBeanItem.getBean().setPatientSymptomsID(
                        String.valueOf(PatientsymptomSample.getId()));
                SymptomBodyParts = Services.createBodyParts(BodyPartsBeanItem);
                
                tempSymptomList.add(SymptomBodyParts);
            }
            PatientsymptomSample.setSymeptoms(tempSymptomList);
            
            symptomID++;
        }
        clinicSample.setPatientSymptomList(tempPatientSymptomList);
        sysContext.setCurrentClinic(clinicSample);
        
    }

    void refreshClinic() {
        Patient_Entity SelectedPatient = sysContext.getSelectedPatient();
        VisitEntity currentVisit = sysContext.getCurrentVisit();
        if (SelectedPatient == null && currentVisit == null) {

        } else {

            // Fill Screen Labels with Saved Data
            if (SelectedPatient.getId() != null) {
                screen.getPatientbasicInfo().getPatientID()
                        .setValue(String.valueOf(SelectedPatient.getId()));
                
            }
            if (SelectedPatient.getFirst_name() == null) {
                SelectedPatient.setFirst_name("");
            }
            if (SelectedPatient.getSecond_name() == null) {
                SelectedPatient.setSecond_name("");
            }
            if (SelectedPatient.getLast_name() == null) {
                SelectedPatient.setLast_name("");
            }
            screen.getPatientbasicInfo().getNameLabel()
                    .setValue(SelectedPatient.getFirst_name() + " "
                            + SelectedPatient.getSecond_name() + " "
                            + SelectedPatient.getLast_name());
            
            screen.getPatientbasicInfo().getPatientname().setCaption("");
            if (SelectedPatient.getProfile_pic() != null) {
                screen.getPatientbasicInfo().getMyLocalImage()
                        .setSource(new FileResource(
                                new File(SelectedPatient.getProfile_pic())));
            }
            if (SelectedPatient.getDob() != null) {
                screen.getPatientbasicInfo().getAgeLabel()
                        .setValue(SelectedPatient.getDob().toString());
            }
            if (String.valueOf(currentVisit.getId()) != null) {
                screen.getPatientbasicInfo().getVisitLabel()
                        .setValue(String.valueOf(currentVisit.getId()));
            }
            if (currentVisit.getVistsDateTime() != null) {
                screen.getPatientbasicInfo().getDateLabel()
                        .setValue(currentVisit.getVistsDateTime());
            }
        }
    }

    void refreshClinicContents() {
        
        Patient_Entity SelectedPatient = sysContext.getSelectedPatient();
        VisitEntity currentVisit = sysContext.getCurrentVisit();
        List<BodypartEntity> tempPatientBodyParts = null ;
        List<BodypartEntity> PatientBodyParts = null;
        List<Symeptoms_badypartEntity> PatientBodyList  = null;
        List<Icd10Entity> PatientICD10List=null;
        List<ClinicvisitEntity> ClinicsList=null;
        List<PatientsymptomEntity> PatientsymptomList=null;


        PatientsymptomEntity PatientsymptonTemp= new PatientsymptomEntity();
        ClinicsList = Services.findClinic(String.valueOf(currentVisit.getId()),
                currentVisit.getPatientID());
        if(ClinicsList.size() == 1){clinicSample = ClinicsList.get(0);}
        else{}
        sysContext.setCurrentClinic(clinicSample);
        PatientsymptomList = Services.findPatientsymptomClinicID(
                String.valueOf(clinicSample.getId()));
        for (int i = 0; i < PatientsymptomList.size(); i++) {
            PatientsymptonTemp = PatientsymptomList.get(i);
            
            PatientICD10List = Services.findICD10ID(
                    Integer.parseInt(PatientsymptonTemp.getICD10Codes()));
            PatientsymptonTemp.setICD10List(PatientICD10List);
            
            PatientBodyList = Services.findSymeptomsBodyPartID(
                    String.valueOf(PatientsymptonTemp.getId()));
            PatientBodyParts = new ArrayList<>();
            for(int j=0 ; j<PatientBodyList.size();j++){
                tempPatientBodyParts = Services.findBodyPartID(Integer.parseInt(PatientBodyList.get(j).getBodyPatID()));
                PatientBodyParts.add(tempPatientBodyParts.get(0));
                PatientsymptonTemp.setBodyPartsList(PatientBodyParts);
            }
            PatientsymptonTemp.setSymeptoms(PatientBodyList);
            screen.getDescriptionTable().getContainerDataSource()
            .addItem(PatientsymptonTemp);
        }
        tempClinic = new BeanItem<ClinicvisitEntity>(clinicSample);
        screen.getObjectiveScreen().updateClinicFieldGroup(tempClinic);
        
        screen.getDescriptionTable().addGeneratedColumn("ICD",
            new Table.ColumnGenerator() {
                public Object generateCell(Table source,
                        final Object itemId,
                        Object columnId) {
                    Layout ICD10Layout = new VerticalLayout();
                    ICD10Layout.setSizeUndefined();

                    if (((PatientsymptomEntity)itemId).getICD10List().size() > 0) {
                        ListSelect ICD10 = new ListSelect(
                                "ICD10 List");
                        ICD10.setNullSelectionAllowed(
                                false);
                        ICD10.setSizeUndefined();
                        ICD10.setRows(((PatientsymptomEntity)itemId).getICD10List().size());
                        ICD10.setContainerDataSource(
                                new BeanItemContainer<Icd10Entity>(
                                        Icd10Entity.class,
                                        ((PatientsymptomEntity)itemId).getICD10List()));
                        ICD10Layout.addComponent(ICD10);
                    }
                    return ICD10Layout;
                }
            });
        
        screen.getDescriptionTable().addGeneratedColumn("bodyparts",
            new Table.ColumnGenerator() {
                public Object generateCell(Table source,
                        final Object itemId,
                        Object columnId) {
                    Layout BodyPartLayout = new VerticalLayout();
                    BodyPartLayout.setSizeUndefined();
                    if (((PatientsymptomEntity)itemId).getBodyPartsList().size() > 0) {
                        ListSelect Body = new ListSelect(
                                "Body List");
                        Body.setNullSelectionAllowed(false);
                        Body.setSizeUndefined();
                        Body.setRows(((PatientsymptomEntity)itemId).getBodyPartsList().size());
                        Body.setContainerDataSource(
                                new BeanItemContainer<BodypartEntity>(
                                        BodypartEntity.class,
                                        ((PatientsymptomEntity)itemId).getBodyPartsList()));
                        BodyPartLayout.addComponent(Body);
                    }
                    return BodyPartLayout;
                }
            });
        clinicSample.setPatientSymptomList(PatientsymptomList);
    }
   

    @Override
    public CustomComponent getView() {

        return screen;
    }

    @Override
    public void setNotification(String msg) {
        if (msg != null && msg.equals("Selection Susuccessfully")) {
            window.close();
            refreshClinic();
        }
        if (msg != null && msg.equals("Visit Registeration Susuccessfully")) {
            refreshClinic();
        }
    }
}
