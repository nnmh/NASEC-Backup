package com.smartera3s.nasec.model.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;
import java.util.List;


/**
 * The persistent class for the clinicvisit database table.
 * 
 */
@Entity
@Table(name="clinicvisit")
@NamedQuery(name="ClinicvisitEntity.findAll", query="SELECT c FROM ClinicvisitEntity c")
public class ClinicvisitEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer id;

	@Lob
	private String assessments;

	@Temporal(TemporalType.DATE)
	private Date clinicVisitDate;

	@Lob
	private String notes;

	private String patient_id;

	@Lob
	private String plans;

	private String visitID;
	
	@Transient
	private List<PatientsymptomEntity> patientSymptomList;
	
	public ClinicvisitEntity() {
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getAssessments() {
		return this.assessments;
	}

	public void setAssessments(String assessments) {
		this.assessments = assessments;
	}

	public Date getClinicVisitDate() {
		return this.clinicVisitDate;
	}

	public void setClinicVisitDate(Date clinicVisitDate) {
		this.clinicVisitDate = clinicVisitDate;
	}

	public String getNotes() {
		return this.notes;
	}

	public void setNotes(String notes) {
		this.notes = notes;
	}

	public String getPatient_id() {
		return this.patient_id;
	}

	public void setPatient_id(String patient_id) {
		this.patient_id = patient_id;
	}

	public String getPlans() {
		return this.plans;
	}

	public void setPlans(String plans) {
		this.plans = plans;
	}

	public String getVisitID() {
		return this.visitID;
	}

	public void setVisitID(String visitID) {
		this.visitID = visitID;
	}

    public List<PatientsymptomEntity> getPatientSymptomList() {
        return patientSymptomList;
    }

    public void setPatientSymptomList(
            List<PatientsymptomEntity> patientSymptomList) {
        this.patientSymptomList = patientSymptomList;
    }

}