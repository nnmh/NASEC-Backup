package com.smartera3s.nasec.controllers;

import com.smartera3s.nasec.listeners.NurseListener;
import com.smartera3s.nasec.listeners.VisitScreenListener;
import com.smartera3s.nasec.screens.Nurse.NurseScreen;
import com.vaadin.ui.CustomComponent;

import static com.smartera3s.utils.InternationalizationFileBundle.MSGS;
import static com.smartera3s.utils.InternationalizationFileBundle.getBundleValue;

public class NurseController implements UIController {
    public static final String VIEW_NAME = "Nursing Service";
    private NurseScreen screen;
    private NurseListener eventListener;
    public NurseController() {
        eventListener = new NurseListener(this);
        screen = new NurseScreen(eventListener);
    }

    @Override
    public CustomComponent getView() {
        // TODO Auto-generated method stub
        return screen;
    }

    @Override
    public void setNotification(String msg) {
        // TODO Auto-generated method stub
        
    }

}
