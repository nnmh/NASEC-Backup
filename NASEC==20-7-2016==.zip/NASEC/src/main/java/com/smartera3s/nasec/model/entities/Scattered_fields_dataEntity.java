package com.smartera3s.nasec.model.entities;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the `scattered fields data` database table.
 * 
 */
@Entity
@Table(name="`scattered fields data`")
@NamedQuery(name="Scattered_fields_dataEntity.findAll", query="SELECT s FROM Scattered_fields_dataEntity s")
public class Scattered_fields_dataEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int id;

	private String clinicId;

	private String formId;

	private String patientId;

	private String scatteredId;

	private String value;

	public Scattered_fields_dataEntity() {
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getClinicId() {
		return this.clinicId;
	}

	public void setClinicId(String clinicId) {
		this.clinicId = clinicId;
	}

	public String getFormId() {
		return this.formId;
	}

	public void setFormId(String formId) {
		this.formId = formId;
	}

	public String getPatientId() {
		return this.patientId;
	}

	public void setPatientId(String patientId) {
		this.patientId = patientId;
	}

	public String getScatteredId() {
		return this.scatteredId;
	}

	public void setScatteredId(String scatteredId) {
		this.scatteredId = scatteredId;
	}

	public String getValue() {
		return this.value;
	}

	public void setValue(String value) {
		this.value = value;
	}

}