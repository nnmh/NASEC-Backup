package com.smartera3s.nasec.model;

public enum Gender {
	Male,
	Female,
	ALL;
}
