package com.smartera3s.nasec.model.entities;

import java.io.Serializable;
import javax.persistence.*;

import java.util.Calendar;
import java.util.Date;
import java.sql.Timestamp;


/**
 * The persistent class for the visits database table.
 * 
 */
@Entity
@Table(name="visits")
@NamedQuery(name="VisitEntity.findAll", query="SELECT v FROM VisitEntity v")

public class VisitEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	
	private int id;

	@Lob
	private String description;

	private String patientID;

	private int payment;

	private int resourceID;

	private int visitTypeID;

	@Transient
	private VisitType_Entity linkedVisitType;
	@Transient
        private Staff_Entity linkedResourceStaff;
	@Transient
        private Device linkedResourceDevice;
	@Transient
        private Operationlist linkedResourceOperation;
	@Transient
        private Object linkedResource;
	@Transient
	private Payment_Entity linkedPayment;
	@Transient
	private Patient_Entity patient;
	@Transient
	private Date fromDate;
	@Transient
	private Date toDate;
	
	@Temporal(TemporalType.DATE)
	private Date vistsDateTime;

	public VisitEntity() {
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getDescription() {
		return this.description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getPatientID() {
		return this.patientID;
	}

	public void setPatientID(String patientID) {
		this.patientID = patientID;
	}

	public int getPayment() {
		return this.payment;
	}

	public void setPayment(int payment) {
		this.payment = payment;
	}

	public int getResourceID() {
		return this.resourceID;
	}

	public void setResourceID(int resourceID) {
		this.resourceID = resourceID;
	}

	public int getVisitTypeID() {
		return this.visitTypeID;
	}

	public void setVisitTypeID(int visitTypeID) {
		this.visitTypeID = visitTypeID;
	}
	public Date getVistsDateTime() {
		return this.vistsDateTime;
	}

	public void setVistsDateTime(Date vistsDateTime) {
		this.vistsDateTime = vistsDateTime;
	}

    public VisitType_Entity getLinkedVisitType() {
        if(linkedVisitType == null){
            linkedVisitType = new VisitType_Entity();
        }
        linkedVisitType.setId(visitTypeID);
        return linkedVisitType;
    }

    public void setLinkedVisitType(VisitType_Entity linkedVisitType) {
        visitTypeID = linkedVisitType.getId();
        this.linkedVisitType = linkedVisitType;
    }

    public Payment_Entity getLinkedPayment() {
        if(linkedPayment == null){
            linkedPayment = new Payment_Entity();
        }
        linkedPayment.setId(payment);
        return linkedPayment;
    }

    public void setLinkedPayment(Payment_Entity linkedPayment) {
        payment = linkedPayment.getId();
        this.linkedPayment = linkedPayment;
    }

    public Object getLinkedResource() {
        if(linkedResourceStaff == null && linkedResourceDevice == null && linkedResourceOperation == null  ){
            linkedResourceStaff = new Staff_Entity();
            linkedResourceDevice = new Device();
            linkedResourceOperation = new Operationlist();
        }
        else if (linkedResourceStaff != null){
        linkedResourceStaff.setId(resourceID);}
        else if (linkedResourceDevice != null){
            linkedResourceDevice.setId(resourceID);}
        else if (linkedResourceOperation != null){
            linkedResourceOperation.setId(resourceID);}
        return linkedResource;
    }

    public void setLinkedResource(Object linkedResource) {
        if(linkedResource.getClass().getName().equals("com.smartera3s.nasec.model.entities.Staff_Entity")  ){
        linkedResourceStaff = (Staff_Entity)linkedResource;
        resourceID = linkedResourceStaff.getId();}
        if(linkedResource.getClass().getName().equals("com.smartera3s.nasec.model.entities.Device")  ){
            linkedResourceDevice = (Device)linkedResource;
        resourceID = linkedResourceDevice.getId();}
        if(linkedResource.getClass().getName().equals("com.smartera3s.nasec.model.entities.Operationlist")  ){
            linkedResourceOperation = (Operationlist)linkedResource;
        resourceID = linkedResourceOperation.getId();}
        this.linkedResource = linkedResource;
    }
    
    
    public String toString() {
        // TODO Auto-generated method stub
        getLinkedVisitType();
        return String.valueOf(this.linkedVisitType.getType());
    }

    public Date getFromDate() {
        return fromDate;
    }

    public void setFromDate(Date fromDate) {
        this.fromDate = fromDate;
    }

    public Date getToDate() {
        return toDate;
    }

    public void setToDate(Date toDate) {
        this.toDate = toDate;
    }

    public Patient_Entity getPatient() {
        return patient;
    }

    public void setPatient(Patient_Entity patient) {
        this.patient = patient;
    }
}