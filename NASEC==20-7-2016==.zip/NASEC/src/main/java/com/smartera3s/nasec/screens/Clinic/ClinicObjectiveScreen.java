package com.smartera3s.nasec.screens.Clinic;

import com.smartera3s.nasec.model.entities.ClinicvisitEntity;
import com.vaadin.data.fieldgroup.BeanFieldGroup;
import com.vaadin.data.fieldgroup.PropertyId;
import com.vaadin.data.util.BeanItem;
import com.vaadin.server.Responsive;
import com.vaadin.ui.Accordion;
import com.vaadin.ui.Component;
import com.vaadin.ui.CssLayout;
import com.vaadin.ui.CustomComponent;
import com.vaadin.ui.Layout;
import com.vaadin.ui.TextArea;
import com.vaadin.ui.VerticalLayout;

public class ClinicObjectiveScreen extends CustomComponent {
    private Accordion sample;
    // TextArea
    @PropertyId("notes")
    private TextArea Notesarea;
    @PropertyId("plans")
    private TextArea Planarea;
    @PropertyId("assessments")
    private TextArea objectivearea;
    
    private Layout ContainerLayout;
    private BeanFieldGroup<ClinicvisitEntity> ClinicfieldGroup;

    public ClinicObjectiveScreen(BeanItem<ClinicvisitEntity> clinicItem) {

        addLayout();
        fillLayout(ContainerLayout);
        addClinicFieldGroup(clinicItem);
    }


    private void addLayout() {
        ContainerLayout = new CssLayout();
        ContainerLayout.setWidth("100%");
        Responsive.makeResponsive(ContainerLayout);
        setCompositionRoot(ContainerLayout);

    }
    private void fillLayout(Layout containerLayout2) {
        containerLayout2.addComponent(buildTextarea());
    }
    private Component buildTextarea() {
        // TODO Auto-generated method stub
        sample = new Accordion();
        objectivearea = createObjective();
        Planarea = createPlan();
        Notesarea = createNotes();

        objectivearea.setValue("Hello Accordion I'm Objective textfield");
        VerticalLayout layout2 = new VerticalLayout(objectivearea);
        layout2.setMargin(true);
        sample.addTab(layout2, "Subjective ");

        Planarea.setValue("Hello Accordion I'm plan textfield");
        VerticalLayout layout3 = new VerticalLayout(Planarea);
        layout3.setMargin(true);
        sample.addTab(layout3, "Plan ");

        Notesarea.setValue("Hello Accordion I'm Note textfield");
        VerticalLayout layout1 = new VerticalLayout(Notesarea);
        layout1.setMargin(true);
        sample.addTab(layout1, "Notes ");

        return sample;
    }

    private void addClinicFieldGroup(BeanItem<ClinicvisitEntity> clinicItem) {
        ClinicfieldGroup = new BeanFieldGroup<ClinicvisitEntity>(
                ClinicvisitEntity.class);
        ClinicfieldGroup.setBuffered(false);// not to depend on commitss
        ClinicfieldGroup.setItemDataSource(clinicItem);
        ClinicfieldGroup.bindMemberFields(this);

    }

    public void updateClinicFieldGroup(BeanItem<ClinicvisitEntity> clinicItem) {
        ClinicfieldGroup.setItemDataSource(clinicItem);
        ClinicfieldGroup.bindMemberFields(this);

    }

    private TextArea createNotes() {
        Notesarea = new TextArea();
        Notesarea.setNullRepresentation("");

        return Notesarea;
    }

    private TextArea createObjective() {
        objectivearea = new TextArea();
        objectivearea.setNullRepresentation("");

        return objectivearea;
    }

    private TextArea createPlan() {
        Planarea = new TextArea();
        Planarea.setNullRepresentation("");

        return Planarea;
    }

    public BeanFieldGroup<ClinicvisitEntity> getClinicfieldGroup() {
        return ClinicfieldGroup;
    }


    public TextArea getNotesarea() {
        return Notesarea;
    }


    public void setNotesarea(TextArea notesarea) {
        Notesarea = notesarea;
    }


    public TextArea getPlanarea() {
        return Planarea;
    }


    public void setPlanarea(TextArea planarea) {
        Planarea = planarea;
    }


    public TextArea getObjectivearea() {
        return objectivearea;
    }


    public void setObjectivearea(TextArea objectivearea) {
        this.objectivearea = objectivearea;
    }
}
