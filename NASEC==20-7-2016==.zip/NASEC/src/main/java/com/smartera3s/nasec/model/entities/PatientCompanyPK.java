package com.smartera3s.nasec.model.entities;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the patient_company database table.
 * 
 */
@Embeddable
public class PatientCompanyPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(insertable=true, updatable=true)
	private int patient_id;
	@Column(insertable=true, updatable=true)
	private int company_id;

	public PatientCompanyPK() {
	}
	public int getPatient_id() {
		return this.patient_id;
	}
	public void setPatient_id(int patient_id) {
		this.patient_id = patient_id;
	}
	public int getCompany_id() {
		return this.company_id;
	}
	public void setCompany_id(int company_id) {
		this.company_id = company_id;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof PatientCompanyPK)) {
			return false;
		}
		PatientCompanyPK castOther = (PatientCompanyPK)other;
		return 
			(this.patient_id == castOther.patient_id)
			&& (this.company_id == castOther.company_id);
	}

	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.patient_id;
		hash = hash * prime + this.company_id;
		
		return hash;
	}
}