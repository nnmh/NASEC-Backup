package com.smartera3s.nasec.screens.templateLayouts;

import com.vaadin.ui.CustomComponent;

public class MainScreen extends CustomComponent{
	private CustomComponent currentView;
	
	public MainScreen(){

	}
	
	public void setCurrentView(CustomComponent view){
		this.currentView = view;
		setCompositionRoot(currentView);
	}
}
