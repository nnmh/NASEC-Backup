package com.smartera3s.nasec.services;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

import com.smartera3s.nasec.model.entities.Address_Entity;
import com.smartera3s.nasec.model.entities.ClinicvisitEntity;
import com.smartera3s.nasec.model.entities.Company_Entity;
import com.smartera3s.nasec.model.entities.Companyrelationtype;
import com.smartera3s.nasec.model.entities.Contact_Entity;
import com.smartera3s.nasec.model.entities.PatientCompany;
import com.smartera3s.nasec.model.entities.PatientRelation;
import com.smartera3s.nasec.model.entities.Patient_Entity;
import com.smartera3s.nasec.model.entities.Relation;
import com.vaadin.data.util.BeanItemContainer;



public class PatientSearchService {
	private  BeanItemContainer<Patient_Entity> PatientBean; // or ContactEntity
	private  BeanItemContainer<Contact_Entity> ContactBean; // or ContactEntity
	
	//Database Linking
	 protected EntityManagerFactory emf = Persistence.createEntityManagerFactory("NASEC");
	 protected EntityManager EntityManager = emf.createEntityManager();
	
	 private HashMap <String,String>  ParamHash;            // Query Parameter Container
	 private Map.Entry MappingEntry;                       // Mapper For HashMap Elements
	 
	 private Query query;   
	 private Query contactQuery;//Query Function
	 private Query relatonQuery;//Query Function
	 private Query companyQuery;//Query Function
	 
	 
	
	public PatientSearchService(){
	    
	}
	public BeanItemContainer<Patient_Entity> search(Patient_Entity patient , Contact_Entity contact, Company_Entity company){
	   
        	    List<Patient_Entity> result=findPatient(patient,contact,company);
        	   
        	    PatientBean = new BeanItemContainer<Patient_Entity> (Patient_Entity.class,result);
        	    return PatientBean;
	}
	@SuppressWarnings("unchecked")
	public List<Patient_Entity> findPatient(Patient_Entity patient,Contact_Entity contact,Company_Entity company){
	    List<Patient_Entity> finalResult = new ArrayList<Patient_Entity>();
            String where = "";
            String SELECT = "SELECT p ";
            String FROM= " FROM Patient_Entity p ";
            boolean ContactFlag=false; 
            boolean CompanyFlag=false;
          
           ParamHash = new HashMap <String,String> ();
            if (patient.getFullName() != null && !patient.getFullName().equals("")) {
               where += ((where == "") ? " " :" AND ")
                     +  "CONCAT(p.first_name,' ',p.second_name,' ',p.last_name) LIKE :fullname"; 
               ParamHash.put("fullname", '%' +patient.getFullName().trim()+ '%');         
            }
            
            if (patient.getGender() != null && !patient.getGender().equals("") && patient.getGender() != "ALL") {
               where += ((where == "") ? " " :" AND ")+  "p.gender = :gender";
               ParamHash.put("gender", patient.getGender());
            }
            if (patient.getIdNumber() != null && !patient.getIdNumber().equals("")) {
                where += ((where == "") ? " " :" AND ")+  "p.idNumber = :idNumber";
                ParamHash.put("idNumber", patient.getIdNumber());
             }
            
            if (patient.getPayment_method() != null && !patient.getPayment_method().equals("")&& patient.getPayment_method() != "ALL") {
               where += ((where == "") ? " " :" AND ")+  "p.payment_method = :payment_method";
               ParamHash.put("payment_method", patient.getPayment_method());
            }
            
            if (contact.getValue() != null && !contact.getValue().equals("")) {
                where += ((where == "") ? " " :" AND ") +  "c.value LIKE :Contact AND p.id=c.patientId";
                FROM += ", Contact_Entity c "; 
                SELECT+= " ,c ";
                ContactFlag=true;
                ParamHash.put("Contact", '%' +contact.getValue()+ '%');
             }
            if (company.getName() != null && !company.getName().equals("")) {
                where += ((where == "") ? " " :" AND ") +  "co.name LIKE :company AND co.id = pc.id.company_id AND p.id=pc.id.patient_id";
                FROM += ", Company_Entity co,PatientCompany pc "; 
                SELECT+= " ,co ";
                CompanyFlag=true;
                ParamHash.put("company", '%' +company.getName()+ '%');
             }
            
            SELECT+=   FROM+(where.equals("")? " ":(" WHERE " +where));
            query = EntityManager
                    .createQuery(SELECT);
            Set set = ParamHash.entrySet();
            // Get an iterator
            Iterator i = set.iterator();
            // Display elements
            while(i.hasNext()) {
                 MappingEntry = (Map.Entry)i.next();
                 query.setParameter(MappingEntry.getKey().toString(),MappingEntry.getValue());
            }
             List result = query.getResultList();
             if(ContactFlag==false)
             {
                 for(int j=0;j<result.size();j++){
                     Patient_Entity tempP=null;
                     if (result.get(j) instanceof Patient_Entity){
                         tempP = (Patient_Entity) result.get(j);
                     }else{
                         tempP = (Patient_Entity)(((Object[])result.get(j))[0]);
                     }
                     contactQuery = EntityManager
                         .createQuery("SELECT c FROM Contact_Entity c WHERE c.patientId=:id").setParameter("id", tempP.getId());
                     List<Contact_Entity> result2 = (List<Contact_Entity>) contactQuery.getResultList();
                     tempP.setContacts(result2);
                     finalResult.add(tempP);
                 }                  
             }
             if(CompanyFlag == false){
                 for(int j=0;j<result.size();j++){
                     Patient_Entity tempP=null;
                     if (result.get(j) instanceof Patient_Entity){
                         tempP = (Patient_Entity) result.get(j);
                     }else{
                         tempP = (Patient_Entity)(((Object[])result.get(j))[0]);
                     }
                 relatonQuery = EntityManager
                         .createNativeQuery("SELECT company_id FROM patient_company p where p.patient_id=?").setParameter(1, tempP.getId());
                 List<Integer> result4 =  relatonQuery.getResultList();
                 List<Company_Entity> temp = new ArrayList();          
                  
                 for(int k=0;k<result4.size();k++){
                     companyQuery = EntityManager
                             .createQuery("SELECT c FROM Company_Entity c where c.id=:id").setParameter("id", (result4.get(k)));
                     List<Company_Entity> companies =  (List<Company_Entity>) companyQuery.getResultList();
                     temp.add(companies.get(0));
                     }
                 tempP.setCompany(temp);
                 finalResult.add(tempP);
                 }
             
             }if(ContactFlag == true) {
                 
                 for(int j=0;j<result.size();j++){
                     Patient_Entity tempP = (Patient_Entity)(((Object[])result.get(j))[0]);
                     Contact_Entity tempC = null;
                     Object secondItem = (((Object[])result.get(j))[1]);
                     if(secondItem instanceof Contact_Entity){
                         tempC= (Contact_Entity) secondItem;
                     }else
                     {
                     
                         Object thirdItem = (((Object[])result.get(j))[2]);
                         if(thirdItem instanceof Contact_Entity){
                             tempC= (Contact_Entity) thirdItem;
                         }
                     }
                     List<Contact_Entity> tempList=new ArrayList<Contact_Entity>();
                     if(tempC != null){
                         tempList.add(tempC);
                     }

                     tempP.setContacts(tempList);
                     finalResult.add(tempP);
                 }
                 
             }
             if(CompanyFlag == true) {
                 
                 for(int j=0;j<result.size();j++){
                     Company_Entity tempC = null;
                     Patient_Entity tempP = (Patient_Entity)(((Object[])result.get(j))[0]);
                     Object secondItem = (((Object[])result.get(j))[1]);
                     if(secondItem instanceof Company_Entity){
                         tempC= (Company_Entity) secondItem;
                     }
                     else{
                         Object thirdItem = (((Object[])result.get(j))[2]);
                         if(thirdItem instanceof Company_Entity){
                             tempC= (Company_Entity) thirdItem;
                         }
                     }
                     List<Company_Entity> tempList=new ArrayList<Company_Entity>();
                     if(tempC != null){
                         tempList.add(tempC);
                     }
                    
                     tempP.setCompany(tempList);
                     finalResult.add(tempP);
                 }
                 
             }
            return finalResult; 
	}
	public List<Address_Entity> getAddress(int id){
	    Query query = EntityManager.createQuery("SELECT a FROM Address_Entity a WHERE a.patient_id =:ID").setParameter("ID", id);
	        return (List<Address_Entity>) query.getResultList();
	}
	public List<Contact_Entity> getContact(int id){
            Query query = EntityManager.createQuery("SELECT c FROM Contact_Entity c WHERE c.patientId =:ID").setParameter("ID", id);
                return (List<Contact_Entity>) query.getResultList();
        }
	public List<Company_Entity> getCompany(int id){
            Query query = EntityManager.createQuery("SELECT co FROM Company_Entity co,PatientCompany pc WHERE co.id = pc.id.company_id AND pc.id.patient_id=:id").setParameter("id", id);
                return (List<Company_Entity>) query.getResultList();
        }
	public List<PatientCompany> getCPatient(int id){
            Query query = EntityManager.createQuery("SELECT pc FROM Company_Entity co,PatientCompany pc WHERE co.id = pc.id.company_id AND pc.id.patient_id=:id").setParameter("id", id);
                return (List<PatientCompany>) query.getResultList();
        }
	public List<Companyrelationtype> getCRelation(int id){
            Query query = EntityManager.createQuery("SELECT c FROM Companyrelationtype c WHERE c.id=:id").setParameter("id", id);
                return (List<Companyrelationtype>) query.getResultList();
        }
	public List<PatientRelation> getRelation(int id){
            Query query = EntityManager.createQuery("SELECT p FROM PatientRelation p WHERE p.id.patient1_id=:id").setParameter("id", id);
                return (List<PatientRelation>) query.getResultList();
        }
	public List<Relation> getPRelation(int id){
            Query query = EntityManager.createQuery("SELECT r FROM Relation r WHERE r.id=:id").setParameter("id", id);
                return (List<Relation>) query.getResultList();
        }
	public List<Patient_Entity> getRelativePatient(int id){
            Query query = EntityManager.createQuery("SELECT p FROM Patient_Entity p WHERE p.id=:id").setParameter("id", id);
                return (List<Patient_Entity>) query.getResultList();
        }
}
