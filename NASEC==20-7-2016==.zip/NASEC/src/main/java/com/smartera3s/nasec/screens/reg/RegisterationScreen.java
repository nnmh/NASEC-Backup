package com.smartera3s.nasec.screens.reg;

import static com.smartera3s.nasec.controllers.PatientSearchController.CONTACT_TYPE;
import static com.smartera3s.nasec.controllers.PatientSearchController.PATIENT_NAME;
import static com.smartera3s.nasec.controllers.RegisterationController.*;
import static com.smartera3s.utils.InternationalizationFileBundle.*;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.smartera3s.nasec.listeners.RegisterationScreenListener;
import com.smartera3s.nasec.controllers.RegisterationController;
import com.smartera3s.nasec.model.Gender;
import com.smartera3s.nasec.model.PaymentType;
import com.smartera3s.nasec.model.Relation_Container;
import com.smartera3s.nasec.model.Company_Contanier;
import com.smartera3s.nasec.model.entities.Address_Entity;
import com.smartera3s.nasec.model.entities.CityEntity;
import com.smartera3s.nasec.model.entities.Company_Entity;
import com.smartera3s.nasec.model.entities.ContactTypeEntity;
import com.smartera3s.nasec.model.entities.Contact_Entity;
import com.smartera3s.nasec.model.entities.CountryEntity;
import com.smartera3s.nasec.model.entities.MstatusEntity;
import com.smartera3s.nasec.model.entities.PatientCompany;
import com.smartera3s.nasec.model.entities.PatientRelation;
import com.smartera3s.nasec.model.entities.Patient_Entity;
import com.smartera3s.nasec.model.entities.Relation;
import com.smartera3s.nasec.services.RegisterationService;
import com.sun.jndi.url.corbaname.corbanameURLContextFactory;
import com.vaadin.data.Item;
import com.vaadin.data.Property;
import com.vaadin.data.Property.ValueChangeEvent;
import com.vaadin.data.fieldgroup.BeanFieldGroup;
import com.vaadin.data.fieldgroup.FieldGroup;
import com.vaadin.data.fieldgroup.PropertyId;
import com.vaadin.data.util.BeanItem;
import com.vaadin.data.util.BeanItemContainer;
import com.vaadin.event.ShortcutAction.KeyCode;
import com.vaadin.navigator.View;
import com.vaadin.navigator.ViewChangeListener.ViewChangeEvent;
import com.vaadin.server.FileResource;
import com.vaadin.server.ThemeResource;
import com.vaadin.ui.AbstractOrderedLayout;
import com.vaadin.ui.Button;
import com.vaadin.ui.ComboBox;
import com.vaadin.ui.CssLayout;
import com.vaadin.ui.CustomComponent;
import com.vaadin.ui.DateField;
import com.vaadin.ui.HorizontalLayout;
import com.vaadin.ui.Image;
import com.vaadin.ui.Label;
import com.vaadin.ui.Layout;
import com.vaadin.ui.OptionGroup;
import com.vaadin.ui.TabSheet;
import com.vaadin.ui.Alignment;

import com.vaadin.ui.VerticalLayout;
import com.vaadin.ui.themes.ValoTheme;

@SuppressWarnings("serial")
public class RegisterationScreen extends CustomComponent implements View {

	public static final String REGISTERATIONVIEW = "RegisterationView";

	/*
	 * mapping the UI fields with the associated properties of the bean that
	 * will be binded
	 */
	// Tabs
	private TabSheet tab;

	// Layouts
	private Layout layoutMainRegistration;

	private Layout layoutTabs;
	private Layout layoutRelationTab;
	private Layout layoutFields;
	private Layout layoutControls;
	private Layout windowLayout;

	// FieldGroup that will link between the ui fields and the binded
	// properties of the bean
	private BeanFieldGroup<Patient_Entity> fieldGroup;

	private Button registerButton;

	private RegisterationScreenListener eventsListener;
	private RegisterationService Service;

	// SubScreens
	private RegisterationSubScreen Basic;
	private RegisterationBasicSubScreen BasicInformaton;
	private RegisterationContactSubScreen ContactInformation;
	private RegisterationReslationSubScreen RelationInformation;
	private RegisterationCompanySubScreen CompanyInformation;

	public RegisterationScreen(BeanItem<Patient_Entity> PatientItem, BeanItem<Contact_Entity> primaryContactItem,
			BeanItem<Contact_Entity> additionalContactItem, BeanItem<Address_Entity> AddressItem,
			BeanItem<PatientRelation> PatientRelationItem, BeanItem<Company_Entity> CompanyItem,
			BeanItem<PatientCompany> PatientCompanyItem, RegisterationScreenListener listener) {

		this.eventsListener = listener;

		Service = new RegisterationService();

		Basic = new RegisterationSubScreen(PatientItem, primaryContactItem, listener);
		BasicInformaton = new RegisterationBasicSubScreen(PatientItem);
		ContactInformation = new RegisterationContactSubScreen(AddressItem, additionalContactItem, listener);
		RelationInformation = new RegisterationReslationSubScreen(PatientRelationItem, listener);
		CompanyInformation = new RegisterationCompanySubScreen(CompanyItem, PatientCompanyItem, listener);

		addLayouts();
		fillLayout(layoutFields);
		// addFieldGroup(PatientItem);
		addControls(layoutControls);
	}

	private void addLayouts() {
		layoutMainRegistration = new VerticalLayout();
		layoutMainRegistration.setSizeUndefined();
		layoutMainRegistration.setStyleName(REGISTERATIONVIEW);

		layoutTabs = new HorizontalLayout();
		layoutTabs.setSizeUndefined();
		layoutTabs.setStyleName("Tabs-style");

		layoutRelationTab = new VerticalLayout();
		layoutRelationTab.setSizeUndefined();

		windowLayout = new VerticalLayout();
		windowLayout.setSizeUndefined();

		layoutFields = new VerticalLayout();
		layoutFields.setSizeUndefined();

		layoutControls = new CssLayout();
		layoutControls.setSizeUndefined();
		layoutControls.setStyleName("layoutControls");

		layoutMainRegistration.addComponent(layoutFields);
		((AbstractOrderedLayout) layoutMainRegistration).setComponentAlignment(layoutFields, Alignment.MIDDLE_CENTER);

		layoutMainRegistration.addComponent(layoutControls);
		setCompositionRoot(layoutMainRegistration);
	}

	public Layout getWindowLayout() {
		return windowLayout;
	}

	public void setWindowLayout(Layout windowLayout) {
		this.windowLayout = windowLayout;
	}

	private void fillLayout(Layout mainLayout) {
		// fill the layout
		mainLayout.addComponent(Basic);
		mainLayout.addComponent(layoutTabs);
		((AbstractOrderedLayout) mainLayout).setSpacing(true);

		tab = new TabSheet();

		fillTabs(tab);
		layoutTabs.addComponent(tab);
		((AbstractOrderedLayout) layoutTabs).setSpacing(true);

	}

	private void fillTabs(TabSheet tab) {

		layoutRelationTab.addComponents(RelationInformation, CompanyInformation);

		tab.addTab(BasicInformaton, "Basic");
		tab.addTab(ContactInformation, "Contacts");
		tab.addTab(layoutRelationTab, "Relations");

		tab.setStyleName(ValoTheme.TABSHEET_CENTERED_TABS);
		tab.setSizeFull();
	}

	/*
	 * private void addFieldGroup(BeanItem<Patient_Entity> Patient) { fieldGroup
	 * = new BeanFieldGroup<Patient_Entity>(Patient_Entity.class);
	 * fieldGroup.setBuffered(false); // you can set any custom factory if you
	 * need to change the display // component for certain property //
	 * fieldGroup.setFieldFactory(DefaultFieldGroupFieldFactory.get());
	 * fieldGroup.setItemDataSource(Patient);
	 * 
	 * this is the core of binding. it takes the class which contains the UI
	 * fields
	 * 
	 * fieldGroup.bindMemberFields(this);
	 * 
	 * }
	 */

	private void addControls(Layout layout) {
		registerButton = createRegisterButton();
		// fill related layout
		layout.addComponent(registerButton);
	}

	private Button createRegisterButton() {
		registerButton = new Button(getBundleValue(CAPTIONS, SAVE));
		registerButton.setStyleName(ValoTheme.BUTTON_FRIENDLY);
		registerButton.setClickShortcut(KeyCode.ENTER);
		registerButton.setId(SAVE);
		registerButton.setIcon(new ThemeResource("img/save.png"));

		// assign the listener class that handles events
		registerButton.addClickListener(eventsListener);
		return registerButton;
	}

	public Layout getLayoutMainRegistration() {
		return layoutMainRegistration;
	}

	public FieldGroup getFieldGroup(String string) {
		return fieldGroup;
	}

	public BeanFieldGroup<Patient_Entity> getFieldGroupPatient() {
		return Basic.getPatientfieldGroup();
	}

	public BeanFieldGroup<Contact_Entity> getFieldGroupContact() {
		return ContactInformation.getContactfieldGroup();
	}

	public BeanFieldGroup<Address_Entity> getFieldGroupAddress() {
		return ContactInformation.getAddressfieldGroup();
	}

	public RegisterationSubScreen getBasic() {
		return Basic;
	}

	public RegisterationBasicSubScreen getBasicInformaton() {
		return BasicInformaton;
	}

	public RegisterationContactSubScreen getContactInformation() {
		return ContactInformation;
	}

	public RegisterationReslationSubScreen getRelationInformation() {
		return RelationInformation;
	}

	public RegisterationCompanySubScreen getCompanyInformation() {
		return CompanyInformation;
	}

	public Layout getLayoutControls() {
		return layoutControls;
	}

	@Override
	public void enter(ViewChangeEvent event) {
		// TODO Auto-generated method stub

	}

}
