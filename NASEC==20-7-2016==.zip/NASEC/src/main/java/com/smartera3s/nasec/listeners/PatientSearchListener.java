package com.smartera3s.nasec.listeners;

import static com.smartera3s.nasec.controllers.PatientSearchController.*;

import com.smartera3s.nasec.controllers.LoginController;
import com.smartera3s.nasec.controllers.PatientSearchController;
import com.smartera3s.utils.InternationalizationFileBundle;
import com.vaadin.data.Property;
import com.vaadin.data.Property.ValueChangeEvent;
import com.vaadin.data.Property.ValueChangeListener;
import com.vaadin.data.util.BeanItem;
import com.vaadin.event.ContextClickEvent;
import com.vaadin.event.ContextClickEvent.ContextClickListener;
import com.vaadin.event.ItemClickEvent;
import com.vaadin.event.ItemClickEvent.ItemClickListener;
import com.vaadin.ui.Button.ClickEvent;
import com.vaadin.ui.Button.ClickListener;

public class PatientSearchListener implements ClickListener ,  ItemClickListener {
	
	private PatientSearchController patientSearchController;
	
	
	public PatientSearchListener(PatientSearchController controller){
		this.patientSearchController=controller;
	}
	
	@Override
	public void buttonClick(ClickEvent event) {
		if(event.getButton().getId().equals(SUBMIT)){
			patientSearchController.search();
		}
		if(event.getButton().getId().equals(EDIT)){
                    patientSearchController.edit();
            }

	}
	
    @Override
    public void itemClick(ItemClickEvent event) {
        // TODO Auto-generated method stub
        if(event.isDoubleClick()){
            patientSearchController.selectPatient(((BeanItem)event.getItem()).getBean());
        }
        
    }


    
}
