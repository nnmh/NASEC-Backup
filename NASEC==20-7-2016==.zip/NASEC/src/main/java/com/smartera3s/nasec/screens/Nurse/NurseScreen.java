package com.smartera3s.nasec.screens.Nurse;

import com.smartera3s.nasec.listeners.NurseListener;
import com.vaadin.navigator.View;
import com.vaadin.ui.Alignment;
import com.vaadin.ui.CustomComponent;
import com.vaadin.ui.CustomLayout;
import com.vaadin.ui.Label;
import com.vaadin.ui.VerticalLayout;
import com.vaadin.navigator.ViewChangeListener.ViewChangeEvent;
import com.vaadin.server.FontAwesome;
import com.vaadin.shared.ui.label.ContentMode;

@SuppressWarnings("serial")
public class NurseScreen extends CustomComponent implements View {

	public static final String VIEW_NAME = "Nurse Service";
	private NurseListener eventListener;
	public NurseScreen(NurseListener listener) {
	    this.eventListener = listener;
		setStyleName("NurseView");
		CustomLayout aboutContent = new CustomLayout("aboutview");
		aboutContent.addComponent(
				new Label(FontAwesome.INFO_CIRCLE.getHtml() + " Nurse Service is under construction", ContentMode.HTML),
				"info");

		aboutContent.setStyleName("about-content");
		setSizeFull();
	              VerticalLayout vLayout = new VerticalLayout();
	                vLayout.addComponent(aboutContent);
	                vLayout.setComponentAlignment(aboutContent, Alignment.MIDDLE_CENTER);
	                setCompositionRoot(vLayout);
	}

	@Override
	public void enter(ViewChangeEvent event) {
	}

}