package com.smartera3s.nasec.controllers;

import com.smartera3s.nasec.listeners.NurseListener;
import com.smartera3s.nasec.listeners.OperationListener;
import com.smartera3s.nasec.screens.Nurse.NurseScreen;
import com.smartera3s.nasec.screens.Operation.OperationScreen;
import com.vaadin.ui.CustomComponent;

public class OperationController implements UIController{

    public static final String VIEW_NAME = "Operation Service";
    private OperationScreen screen;
    private OperationListener eventListener;
    
    public OperationController() {
        eventListener = new OperationListener(this);
        screen = new OperationScreen(eventListener);
    }

    @Override
    public CustomComponent getView() {
        // TODO Auto-generated method stub
        return screen;
    }

    @Override
    public void setNotification(String msg) {
        // TODO Auto-generated method stub
        
    }

}
