package com.smartera3s.nasec.screens.Clinic;

import com.vaadin.ui.Layout;
import com.vaadin.ui.Table;
import com.vaadin.ui.AbstractOrderedLayout;
import com.vaadin.ui.Button;
import com.vaadin.ui.ComboBox;
import com.vaadin.ui.Component;
import com.vaadin.ui.CssLayout;
import com.vaadin.navigator.View;
import com.vaadin.server.Responsive;
import com.vaadin.ui.VerticalLayout;
import com.vaadin.ui.CustomComponent;
import com.vaadin.data.util.BeanItem;
import com.vaadin.ui.HorizontalLayout;
import com.vaadin.ui.themes.ValoTheme;
import com.vaadin.server.ThemeResource;
import com.vaadin.event.ShortcutListener;
import com.vaadin.data.util.BeanItemContainer;
import com.vaadin.event.ShortcutAction.KeyCode;
import com.vaadin.data.fieldgroup.BeanFieldGroup;
import com.smartera3s.nasec.listeners.ClinicListener;
import com.smartera3s.nasec.model.ClinicDescriptionContainer;
import com.smartera3s.nasec.model.entities.ClinicvisitEntity;
import com.smartera3s.nasec.model.entities.PatientsymptomEntity;
import com.vaadin.navigator.ViewChangeListener.ViewChangeEvent;
import static com.smartera3s.utils.InternationalizationFileBundle.CAPTIONS;
import static com.smartera3s.nasec.controllers.ClinicController.ADDCOMBOBOX;
import static com.smartera3s.nasec.controllers.ClinicController.ADDDESCRIPSION;
import static com.smartera3s.nasec.controllers.ClinicController.SAVECLINICVISIT;
import static com.smartera3s.utils.InternationalizationFileBundle.getBundleValue;

@SuppressWarnings("serial")
public class ClinicScreen extends CustomComponent implements View {

	public static final String CLINICVIEW = "Clinic-view";
	public static final String VIEW_NAME = "Clinic Services";

	private ComboBox PatientObjectives;
	private Button SaveButton;
	private Layout MainScreen;
	private Layout ContainerLayout;
	private Layout windowLayout;
	private Layout windowLayout2;
	private Layout PatientInfoLayout;
	private Layout PatientDescriptionLayout;
	private Layout PatientObjectiveLayout;

	private VerticalLayout toolbarLayout;
	private ClinicListener eventListener;
	private Table descriptionTable;
	private Button addCombobox;

	/// Object from classes.
	private BeanItemContainer<PatientsymptomEntity> Container;

	private ClinicPatientSubscreen PatientbasicInfo;
	private ClinicDescriptionScreen DescriptionScreen;
	private ClinicObjectiveScreen ObjectiveScreen;

	public ClinicScreen(BeanItem<ClinicvisitEntity> clinicItem, ClinicListener listener) {
		/// Create Object from Classes.
		this.eventListener = listener;
		PatientbasicInfo = new ClinicPatientSubscreen(clinicItem);
		Container = new BeanItemContainer<PatientsymptomEntity>(PatientsymptomEntity.class);
		DescriptionScreen = new ClinicDescriptionScreen(listener);
		ObjectiveScreen = new ClinicObjectiveScreen(clinicItem);
		
		// Calling Methods
		addLayout();
		fillLayout(MainScreen);
		addControls(ContainerLayout);
	}

	// AddLayout Method.
	private void addLayout() {

		// This is the Main Screen Layout
		MainScreen = new CssLayout();
		MainScreen.addStyleName(CLINICVIEW);

		windowLayout = new VerticalLayout();
		windowLayout.setSizeUndefined();

		windowLayout2 = new VerticalLayout();
		windowLayout2.setSizeUndefined();

		ContainerLayout = new CssLayout();
		ContainerLayout.addStyleName("Patient-Description-Layout");

		/// Layout for Patient Info like
		/// Name,Age,Profile_image,Visit_id,Visit_Date,WeitingList,Contact
		PatientInfoLayout = new CssLayout();
		PatientInfoLayout.addStyleName("patient-info");
		Responsive.makeResponsive(PatientInfoLayout);

		/// Layout of the Description button and table.
		PatientDescriptionLayout = new VerticalLayout();
		Responsive.makeResponsive(PatientDescriptionLayout);

		PatientObjectiveLayout = new HorizontalLayout();
		PatientObjectiveLayout.addStyleName("Patient-Objective-Layout");
		Responsive.makeResponsive(PatientObjectiveLayout);

		setCompositionRoot(MainScreen);
	}

	// FillLayout Method
	private void fillLayout(Layout MainLayout) {
		Component panel = buildToolbar();

		descriptionTable = fillTable();
		descriptionTable.setContainerDataSource(Container);
		descriptionTable.setVisibleColumns("date", "notes");
		descriptionTable.setColumnHeader("date", "Date");
//		descriptionTable.setColumnHeader("bodyPartsList", "Body Parts");
//		descriptionTable.setColumnHeader("ICD10List", "ICD10");
		descriptionTable.setColumnHeader("notes", "Notes");
		descriptionTable.setColumnExpandRatio("notes", 1.0f);

		PatientInfoLayout.addComponent(PatientbasicInfo);

		//PatientDescriptionLayout.addComponent(descriptionTable);

		PatientObjectiveLayout.addComponents(panel, ObjectiveScreen);
		((AbstractOrderedLayout) PatientObjectiveLayout).setExpandRatio(ObjectiveScreen, 1.0f);

		MainLayout.addComponent(PatientInfoLayout);
		ContainerLayout.addComponents(buildAddDescriptionButton(), descriptionTable);
		MainLayout.addComponent(PatientObjectiveLayout);

		MainLayout.addComponents(ContainerLayout);

	}

	// window.
	private Component buildAddDescriptionButton() {
		Button addDescription = new Button("Add Description");
		addDescription.setIcon(new ThemeResource("img/add-list.png"));
		addDescription.addStyleName(ValoTheme.BUTTON_PRIMARY);
		addDescription.setId(ADDDESCRIPSION);
		addDescription.addClickListener(eventListener);
		return addDescription;
	}

	private Table fillTable() {
		Table table = new Table();
		table.setPageLength(table.size());
		table.setSizeFull();
		table.setResponsive(true);
		return table;
	}

	private Component buildToolbar() {
		toolbarLayout = new VerticalLayout();
		toolbarLayout.setSizeFull();
		toolbarLayout.setStyleName("toolbarLayout");

		VerticalLayout toolbar = new VerticalLayout();
		toolbar.setSpacing(true);

		PatientObjectives = new ComboBox();
		PatientObjectives.setItemCaptionPropertyId("title");
		PatientObjectives.setItemCaptionPropertyId("displayName");
		PatientObjectives.addShortcutListener(new ShortcutListener("Add", KeyCode.ENTER, null) {
			@Override
			public void handleAction(final Object sender, final Object target) {
			}
		});

		addCombobox = new Button("Add");
		addCombobox.setEnabled(false);
		addCombobox.setId(ADDCOMBOBOX);
		addCombobox.addStyleName(ValoTheme.BUTTON_PRIMARY);

		CssLayout group = new CssLayout(PatientObjectives, addCombobox);
		toolbar.addComponent(group);

		PatientObjectives.addValueChangeListener(eventListener);

		addCombobox.addClickListener(eventListener);
		toolbarLayout.addComponent(toolbar);
		return toolbarLayout;
	}

	///// Save Button.
	private void addControls(Layout layout) {
		SaveButton = createSaveButton();
		SaveButton.addClickListener(eventListener);
		layout.addComponent(SaveButton);
	}

	private Button createSaveButton() {
		SaveButton = new Button(getBundleValue(CAPTIONS, SAVECLINICVISIT));
		SaveButton.setId(SAVECLINICVISIT);
		SaveButton.setClickShortcut(KeyCode.ENTER);
		SaveButton.setIcon(new ThemeResource("img/save.png"));
		return SaveButton;
	}

	public ClinicPatientSubscreen getPatientbasicInfo() {
		return PatientbasicInfo;
	}

	@Override
	public void enter(ViewChangeEvent event) {
		// TODO Auto-generated method stub

	}

	public ClinicDescriptionScreen getDescriptionScreen() {
		return DescriptionScreen;
	}

	public Table getDescriptionTable() {
		return descriptionTable;
	}

	public ComboBox getPatientObjectives() {
		return PatientObjectives;
	}

	public void setPatientObjectives(ComboBox patientObjectives) {
		PatientObjectives = patientObjectives;
	}

	public Layout getPatientObjectiveLayout() {
		return PatientObjectiveLayout;
	}

	public void setPatientObjectiveLayout(Layout patientObjectiveLayout) {
		PatientObjectiveLayout = patientObjectiveLayout;
	}

	public VerticalLayout getToolbarLayout() {
		return toolbarLayout;
	}

	public void setToolbarLayout(VerticalLayout toolbarLayout) {
		this.toolbarLayout = toolbarLayout;
	}

	public BeanFieldGroup<ClinicvisitEntity> getPatientFieldGroup() {
		return PatientbasicInfo.getClinicfieldGroup();
	}

	public ClinicObjectiveScreen getObjectiveScreen() {
		return ObjectiveScreen;
	}

	public BeanFieldGroup<ClinicvisitEntity> getObjectiveFieldGroup() {
		return ObjectiveScreen.getClinicfieldGroup();
	}

	public Layout getWindowLayout() {
		return windowLayout;
	}

	public Layout getWindowLayout2() {
		return windowLayout2;
	}

    public void setDescriptionTable(Table descriptionTable) {
        this.descriptionTable = descriptionTable;
    }

    public Button getAddCombobox() {
        return addCombobox;
    }

    public void setAddCombobox(Button addCombobox) {
        this.addCombobox = addCombobox;
    }

}
