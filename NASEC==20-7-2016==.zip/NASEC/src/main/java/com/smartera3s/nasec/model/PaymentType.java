package com.smartera3s.nasec.model;

public enum PaymentType {
	Cash,
	Credit,
	ALL;
}
