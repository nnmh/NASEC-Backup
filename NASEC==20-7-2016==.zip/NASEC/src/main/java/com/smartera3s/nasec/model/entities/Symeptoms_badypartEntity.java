package com.smartera3s.nasec.model.entities;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the `symeptoms badyparts` database table.
 * 
 */
@Entity
@Table(name="`symeptoms badyparts`")
@NamedQuery(name="Symeptoms_badypartEntity.findAll", query="SELECT s FROM Symeptoms_badypartEntity s")
public class Symeptoms_badypartEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int id;

	private String bodyPatID;

	private String patientSymptomsID;
	
	public Symeptoms_badypartEntity() {
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getBodyPatID() {
		return this.bodyPatID;
	}

	public void setBodyPatID(String bodyPatID) {
		this.bodyPatID = bodyPatID;
	}

	public String getPatientSymptomsID() {
		return this.patientSymptomsID;
	}

	public void setPatientSymptomsID(String patientSymptomsID) {
		this.patientSymptomsID = patientSymptomsID;
	}

}