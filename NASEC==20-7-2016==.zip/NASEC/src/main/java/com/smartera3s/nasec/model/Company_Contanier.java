package com.smartera3s.nasec.model;

import javax.persistence.Transient;

import com.smartera3s.nasec.model.entities.Companyrelationtype;

public class Company_Contanier {

    private String insurance_number;

    private String name;

    private int relation_type;
    @Transient
    private Companyrelationtype linkedType;
    @Transient
    private String type;
    
    private String contact;

    public Company_Contanier(String name,String number,String contact, int type, String RType) {
        
        linkedType = new Companyrelationtype();
        this.name=name;
        this.insurance_number=number;
        this.contact=contact;
        this.relation_type=type;
        this.type=RType;
}
            public String getInsurance_number() {
                    return insurance_number;
            }

            public void setInsurance_number(String insurance_number) {
                    this.insurance_number = insurance_number;
            }

            public String getName() {
                    return name;
            }

            public void setName(String name) {
                    this.name = name;
            }

            public int getRelation_type() {
                    return relation_type;
            }

            public void setRelation_type(int relation_type) {
                    this.relation_type = relation_type;
            }

            public String getContact() {
                return contact;
            }

            public void setContact(String contact) {
                this.contact = contact;
            }
            public Companyrelationtype getLinkedIDType() {
                if(linkedType == null){
                    linkedType = new Companyrelationtype();
                }
                linkedType.setId(relation_type);
                
                return linkedType;
            }

            public void setLinkedIDType(Companyrelationtype linkedType) {
                relation_type = linkedType.getId();
                this.linkedType = linkedType;
            }
            public String getType() {
                return type;
            }
            public void setType(String type) {
                this.type = type;
            }

    }


