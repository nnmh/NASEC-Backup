package com.smartera3s.nasec.model.entities;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the contacttype database table.
 * 
 */
@Entity
@Table(name="contacttype")
@NamedQuery(name="ContactTypeEntity.findAll", query="SELECT c FROM ContactTypeEntity c")
public class ContactTypeEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int id;

	@Column(name="contact_type")
	private String contactType;

	public ContactTypeEntity() {
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getContactType() {
		return this.contactType;
	}

	public void setContactType(String contactType) {
		this.contactType = contactType;
	}

}