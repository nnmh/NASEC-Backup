package com.smartera3s.nasec.listeners;

import com.smartera3s.nasec.controllers.NurseController;

public class NurseListener {

    public NurseListener(NurseController controller) {
        // TODO Auto-generated constructor stub
    }

}
