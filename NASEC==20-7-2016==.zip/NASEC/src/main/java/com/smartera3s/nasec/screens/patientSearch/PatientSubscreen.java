package com.smartera3s.nasec.screens.patientSearch;

import static com.smartera3s.nasec.controllers.PatientSearchController.PATIENT_NAME;
import static com.smartera3s.nasec.controllers.PatientSearchController.GENDER;
import static com.smartera3s.nasec.controllers.PatientSearchController.PAYMENT;
import static com.smartera3s.nasec.controllers.PatientSearchController.PATIENT_ID_IDENTIFICATION;
import static com.smartera3s.utils.InternationalizationFileBundle.CAPTIONS;
import static com.smartera3s.utils.InternationalizationFileBundle.MSGS;
import static com.smartera3s.utils.InternationalizationFileBundle.getBundleValue;

import com.smartera3s.nasec.listeners.PatientSearchListener;
import com.smartera3s.nasec.model.Gender;
import com.smartera3s.nasec.model.PaymentType;
import com.smartera3s.nasec.model.entities.Patient_Entity;
import com.smartera3s.nasec.screens.reg.RegisterationScreen;
import com.smartera3s.nasec.screens.reg.RegisterationSubScreen;
import com.vaadin.data.fieldgroup.BeanFieldGroup;
import com.vaadin.data.fieldgroup.FieldGroup;
import com.vaadin.data.fieldgroup.PropertyId;
import com.vaadin.data.util.BeanItem;
import com.vaadin.data.util.BeanItemContainer;
import com.vaadin.ui.CssLayout;
import com.vaadin.ui.CustomComponent;
import com.vaadin.ui.HorizontalLayout;
import com.vaadin.ui.Layout;
import com.vaadin.ui.OptionGroup;
import com.vaadin.ui.TextField;
import com.vaadin.ui.UI;
import com.vaadin.ui.VerticalLayout;
import com.vaadin.ui.themes.ValoTheme;

public class PatientSubscreen extends CssLayout {
	public static final String PATIENTSUBSCREENLAYOUT = "PatientSubScreenLayout";
	/*
	 * mapping the UI fields with the associated properties of the bean that
	 * will be binded
	 */
	@PropertyId("idNumber")
	private TextField ididentification;
	@PropertyId("fullName")
	private TextField fullName;
	@PropertyId("gender")
	private OptionGroup gender;
	@PropertyId("payment_method")
	private OptionGroup paymentType;

	// Layouts
	private Layout layoutFields;
	// FieldGroup that will link between the ui fields and the binded
	// properties of the bean
	private BeanFieldGroup<Patient_Entity> fieldGroup;
	private PatientSearchListener eventsListener;

	// Constructor
	public PatientSubscreen(BeanItem<Patient_Entity> patientItem, PatientSearchListener listener) {
		this.eventsListener = listener;
		addLayouts();
		addFieldGroup(patientItem);

	}

	private void addLayouts() {
		layoutFields = new CssLayout();
		layoutFields.setSizeUndefined();
		addComponent(layoutFields);
		fillFields(layoutFields);
	}

	private void addFieldGroup(BeanItem<Patient_Entity> patientItem) {
		fieldGroup = new BeanFieldGroup<Patient_Entity>(Patient_Entity.class);
		fieldGroup.setBuffered(false);// not to depend on commitss
		fieldGroup.setItemDataSource(patientItem);
		fieldGroup.bindMemberFields(this);
	}

	public void searchFieldGroup(RegisterationSubScreen screen) {

		fieldGroup.bindMemberFields(screen);
	}

	private void fillFields(Layout layout) {
		fullName = createFullName();
		ididentification = createIdidentification();
		HorizontalLayout Layout = new HorizontalLayout();

		gender = createGender();
		paymentType = createPaymentType();

		HorizontalLayout nameLayout = new HorizontalLayout();
		HorizontalLayout ididentificationLayout = new HorizontalLayout();

		Layout.addComponents(gender, paymentType);
		Layout.setStyleName("group-style");
		
		nameLayout.addComponents(fullName);

		ididentificationLayout.addComponents(ididentification);

		layout.addComponents(nameLayout, ididentificationLayout);
		layout.addComponent(Layout);
	}

	private TextField createIdidentification() {
		TextField ididentification = new TextField();
		// name.setStyleName(ValoTheme.TEXTFIELD_LARGE);
		ididentification.setCaption(getBundleValue(CAPTIONS, PATIENT_ID_IDENTIFICATION));
		ididentification.setId(PATIENT_ID_IDENTIFICATION);
		ididentification.setNullRepresentation("");
		ididentification.setInputPrompt(getBundleValue(MSGS, PATIENT_ID_IDENTIFICATION));
		ididentification.setDescription(getBundleValue(MSGS, PATIENT_ID_IDENTIFICATION));
		return ididentification;
	}

	private TextField createFullName() {
		TextField name = new TextField();
		// name.setStyleName(ValoTheme.TEXTFIELD_LARGE);
		name.setCaption(getBundleValue(CAPTIONS, PATIENT_NAME));
		name.setId(PATIENT_NAME);
		name.setNullRepresentation("");
		name.setInputPrompt(getBundleValue(MSGS, PATIENT_NAME));
		name.setDescription(getBundleValue(MSGS, PATIENT_NAME));
		return name;
	}

	private OptionGroup createGender() {
		OptionGroup sex = new OptionGroup();
		// sex.setStyleName(ValoTheme.TEXTFIELD_LARGE);
		// sex.setCaption(getBundleValue(CAPTIONS, GENDER));
		sex.setId(GENDER);
		sex.setDescription(getBundleValue(MSGS, GENDER));
		BeanItemContainer sexCntr = new BeanItemContainer(String.class);
		sexCntr.addItem(Gender.ALL.name());
		sexCntr.addItem(Gender.Male.name());
		sexCntr.addItem(Gender.Female.name());
		sex.setContainerDataSource(sexCntr);

		return sex;
	}

	private OptionGroup createPaymentType() {
		OptionGroup payment = new OptionGroup();
		// payment.setStyleName(ValoTheme.TEXTFIELD_LARGE);
		// payment.setCaption(getBundleValue(CAPTIONS, PAYMENT));
		payment.setId(PAYMENT);
		payment.setDescription(getBundleValue(MSGS, PAYMENT));
		BeanItemContainer pmtCntr = new BeanItemContainer(String.class);
		pmtCntr.addItem(PaymentType.ALL.name());
		pmtCntr.addItem(PaymentType.Cash.name());
		pmtCntr.addItem(PaymentType.Credit.name());
		payment.setContainerDataSource(pmtCntr);
		return payment;
	}

	public Layout getLayoutFields() {
		return layoutFields;
	}

	public BeanFieldGroup<Patient_Entity> getFieldGroup() {
		return fieldGroup;
	}
}
