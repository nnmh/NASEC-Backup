package com.smartera3s.nasec.listeners;

import com.smartera3s.nasec.controllers.InvestigationController;

public class InvestigationListener {

    public InvestigationListener(InvestigationController controller) {
        // TODO Auto-generated constructor stub
    }

}
