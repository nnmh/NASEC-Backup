package com.smartera3s;

import javax.servlet.annotation.WebServlet;

import com.smartera3s.nasec.controllers.LoginController;
import com.smartera3s.nasec.controllers.PatientSearchController;
import com.smartera3s.nasec.controllers.RegisterationController;
import com.smartera3s.nasec.controllers.UIController;
import com.smartera3s.nasec.controllers.VisitController;
import com.smartera3s.nasec.controllers.navigation.MainController;
import com.smartera3s.nasec.model.SysContext;
import com.smartera3s.nasec.screens.Menu.*;
import com.vaadin.annotations.Theme;
import com.vaadin.annotations.VaadinServletConfiguration;
import com.vaadin.annotations.Viewport;
import com.vaadin.annotations.Widgetset;
import com.vaadin.server.Responsive;
import com.vaadin.server.VaadinRequest;
import com.vaadin.server.VaadinService;
import com.vaadin.server.VaadinServlet;
import com.vaadin.ui.UI;
import com.vaadin.ui.themes.ValoTheme;

/**
 * This UI is the application entry point. A UI may either represent a browser window 
 * (or tab) or some part of a html page where a Vaadin application is embedded.
 * <p>
 * The UI is initialized using {@link #init(VaadinRequest)}. This method is intended to be 
 * overridden to add component to the user interface and initialize non-component functionality.
 * <br/> The @Viewport annotation configures the viewport meta tags appropriately on
 * mobile devices. Instead of device based scaling (default), using responsive
 * layouts.
 */
@Theme("mytheme")
@Widgetset("com.smartera3s.Smartera3SWidgetset")
@Viewport("user-scalable=yes,initial-scale=1.0")
//@PreserveOnRefresh
public class NASECUI extends UI {
	UIController controller;
    /**
	 * 
	 */
	private static final long serialVersionUID = 3614110808584415881L;

	@Override
    protected void init(VaadinRequest vaadinRequest) {
	    setResponsive(true);
            Responsive.makeResponsive(this);
            SysContext sysContext = new SysContext();
            VaadinService.getCurrentRequest().getWrappedSession().setAttribute(SysContext.class.getName(), sysContext);

            setLocale(vaadinRequest.getLocale());
            // This to make the title of the webpage
            getPage().setTitle("NASEC");
            //showMainView();

            
              controller = new MainController(this); setContent(controller.getView());
             
    }

    public void showMainView() {
            addStyleName(ValoTheme.UI_WITH_MENU);
            setContent(new MainScreen());
            getNavigator().navigateTo(getNavigator().getState());
    }

    public static NASECUI get() {
            return (NASECUI) UI.getCurrent();
    }

    @WebServlet(urlPatterns = "/*", name = "NASECUIServlet", asyncSupported = true)
    @VaadinServletConfiguration(ui = NASECUI.class, productionMode = false)
    public static class NASECUIServlet extends VaadinServlet {
    }
}
